import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  /* config options here */
  allowedDevOrigins: ["local-origin.dev", "*.local-origin.dev"],
  // Disable strict mode for production compatibility
  reactStrictMode: true,
  // Ensure images are optimized
  images: {
    unoptimized: false,
  },
  // Production configuration for reverse proxy (Nginx)
  // Trust proxy headers from Nginx
  // Next.js will automatically trust X-Forwarded-* headers when behind a proxy
  // No additional configuration needed for basic reverse proxy setup

  // Optional: Add security headers
  async headers() {
    return [
      {
        source: "/:path*",
        headers: [
          {
            key: "X-Content-Type-Options",
            value: "nosniff",
          },
          {
            key: "X-Frame-Options",
            value: "DENY",
          },
          {
            key: "X-XSS-Protection",
            value: "1; mode=block",
          },
          {
            key: "Referrer-Policy",
            value: "strict-origin-when-cross-origin",
          },
        ],
      },
    ];
  },
  // Ensure Next.js uses relative URLs and respects the Host header from proxy
  // This prevents hardcoded localhost URLs in production
  experimental: {
    // Disable any URL rewriting that might use localhost
    authInterrupts: true,
    serverActions: {
      bodySizeLimit: "5mb",
    },
  },
};

export default nextConfig;
