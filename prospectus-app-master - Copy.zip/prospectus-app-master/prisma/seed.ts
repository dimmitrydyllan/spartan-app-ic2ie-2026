import "dotenv/config"
import bcrypt from "bcryptjs"
import { Pool } from "pg"
import { PrismaPg } from "@prisma/adapter-pg"

import { PrismaClient } from "./generated/client"

const connectionString = process.env.DATABASE_URL
if (!connectionString) {
  throw new Error("DATABASE_URL is not set")
}

const pool = new Pool({ connectionString })
const adapter = new PrismaPg(pool)
const prisma = new PrismaClient({ adapter })

async function main() {
  console.log("Seeding master data (Role, User, Menu, RoleMenu, UserRole)...")

  // --- ROLES ---
  const adminRole = await prisma.role.upsert({
    where: { code: "ADMIN" },
    update: {},
    create: {
      code: "ADMIN",
      name: "Administrator",
    },
  })

  const supervisorRole = await prisma.role.upsert({
    where: { code: "SUPERVISOR" },
    update: {},
    create: {
      code: "SUPERVISOR",
      name: "Supervisor",
    },
  })

  const salesRole = await prisma.role.upsert({
    where: { code: "SALES" },
    update: {},
    create: {
      code: "SALES",
      name: "Sales",
    },
  })

  // --- USERS ---
  const defaultPassword = await bcrypt.hash("password123", 10)

  const adminUser = await prisma.user.upsert({
    where: { email: "admin@example.com" },
    update: {},
    create: {
      email: "admin@example.com",
      password: defaultPassword,
      name: "Admin",
      theme: "system",
      fontSize: "medium",
      compactMode: false,
    },
  })

  const supervisorUser = await prisma.user.upsert({
    where: { email: "supervisor@example.com" },
    update: {},
    create: {
      email: "supervisor@example.com",
      password: defaultPassword,
      name: "Supervisor",
      theme: "system",
      fontSize: "medium",
      compactMode: false,
    },
  })

  const salesUser = await prisma.user.upsert({
    where: { email: "sales@example.com" },
    update: {},
    create: {
      email: "sales@example.com",
      password: defaultPassword,
      name: "Sales",
      theme: "system",
      fontSize: "medium",
      compactMode: false,
    },
  })

  // --- MENUS ---
  // Hanya seed menu-menu utama, path harus sama dengan route yang ada di app
  const menusData = [
    { name: "Dashboard", path: "/dashboard", icon: "home", order: 1 },
    { name: "Prospectus", path: "/prospectus", icon: "filetext", order: 2 },
    { name: "Absensi", path: "/absensi", icon: "clock", order: 3 },
    { name: "Profile", path: "/profile", icon: "user", order: 4 },
    { name: "Pengaturan", path: "/settings", icon: "settings", order: 5 },
    { name: "Role & User", path: "/roles", icon: "shield", order: 6 },
    { name: "Menu Management", path: "/menus", icon: "menu", order: 7 },
    { name: "Supervisor", path: "/supervisor", icon: "usercheck", order: 8 },
  ] as const

  const menus = []
  for (const m of menusData) {
    const menu = await prisma.menu.upsert({
      where: { path: m.path },
      update: {
        name: m.name,
        icon: m.icon,
        order: m.order,
        isActive: true,
      },
      create: {
        name: m.name,
        path: m.path,
        icon: m.icon,
        order: m.order,
        isActive: true,
      },
    })
    menus.push(menu)
  }

  // Helper untuk buat RoleMenu dengan semua izin
  async function ensureRoleMenu(roleId: string, menuId: string, fullAccess = false) {
    const canCreate = fullAccess
    const canUpdate = fullAccess
    const canDelete = fullAccess

    await prisma.roleMenu.upsert({
      where: {
        roleId_menuId: {
          roleId,
          menuId,
        },
      },
      update: {
        canView: true,
        canCreate,
        canUpdate,
        canDelete,
      },
      create: {
        roleId,
        menuId,
        canView: true,
        canCreate,
        canUpdate,
        canDelete,
      },
    })
  }

  // --- ROLE-MENU MAPPING ---
  // Admin: akses penuh ke semua menu
  for (const menu of menus) {
    await ensureRoleMenu(adminRole.id, menu.id, true)
  }

  // Supervisor: akses ke dashboard, prospectus, absensi, supervisor, settings
  for (const menu of menus) {
    if (
      ["/dashboard", "/prospectus", "/absensi", "/supervisor", "/settings"].includes(
        menu.path,
      )
    ) {
      await ensureRoleMenu(supervisorRole.id, menu.id, true)
    }
  }

  // Sales: akses ke dashboard, prospectus, absensi, profile, settings (tanpa role/menu management)
  for (const menu of menus) {
    if (
      ["/dashboard", "/prospectus", "/absensi", "/profile", "/settings"].includes(
        menu.path,
      )
    ) {
      await ensureRoleMenu(salesRole.id, menu.id, false)
    }
  }

  // --- USER-ROLE MAPPING ---
  async function ensureUserRole(userId: string, roleId: string) {
    await prisma.userRole.upsert({
      where: {
        userId_roleId: {
          userId,
          roleId,
        },
      },
      update: {},
      create: {
        userId,
        roleId,
      },
    })
  }

  // Admin user punya role ADMIN
  await ensureUserRole(adminUser.id, adminRole.id)

  // Supervisor user punya role SUPERVISOR
  await ensureUserRole(supervisorUser.id, supervisorRole.id)

  // Sales user punya role SALES
  await ensureUserRole(salesUser.id, salesRole.id)

  console.log("Seeding selesai ✅")
}

main()
  .catch((e) => {
    console.error("Error saat seeding", e)
    process.exit(1)
  })
  .finally(async () => {
    await prisma.$disconnect()
  })


