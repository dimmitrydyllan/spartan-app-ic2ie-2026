"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { Trash2, Loader2, AlertTriangle } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export function DeleteConfirmDialog({
  title,
  description,
  action,
  id,
  variant = "ghost",
  size = "sm",
  successMessage = "Data berhasil dihapus",
  errorMessage = "Gagal menghapus data",
}: {
  title: string;
  description: string;
  action: (formData: FormData) => Promise<{ success: boolean; error?: string } | void>;
  id: string;
  variant?: "ghost" | "destructive";
  size?: "sm" | "default";
  successMessage?: string;
  errorMessage?: string;
}) {
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  const handleDelete = () => {
    const formData = new FormData();
    formData.set("id", id);

    startTransition(async () => {
      try {
        const result = await action(formData);
        if (result && typeof result === "object") {
          if (result.success) {
            toast.success(successMessage);
            router.refresh();
          } else {
            const errorMsg =
              result.error === "invalid" ? "Data tidak valid" :
              result.error === "not_found" ? "Data tidak ditemukan" :
              result.error === "has_children" ? "Tidak dapat menghapus menu yang memiliki submenu" :
              result.error === "delete_failed" ? "Gagal menghapus data" :
              result.error === "remove_failed" ? "Gagal menghapus assign" :
              errorMessage;
            toast.error(errorMsg);
          }
        } else {
          router.refresh();
        }
      } catch (error: any) {
        if (error?.digest?.startsWith("NEXT_REDIRECT") || error?.message?.includes("NEXT_REDIRECT")) {
          return;
        }
        console.error("Error deleting:", error);
        toast.error(errorMessage);
      }
    });
  };

  return (
    <AlertDialog>
      <AlertDialogTrigger asChild>
        <Button
          variant={variant}
          size={size}
          className={
            variant === "ghost"
              ? "text-red-600 hover:text-red-700 hover:bg-red-50"
              : ""
          }
          disabled={isPending}
        >
          {isPending ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : (
            <Trash2 className="h-4 w-4" />
          )}
        </Button>
      </AlertDialogTrigger>
      <AlertDialogContent>
        <AlertDialogHeader>
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-red-100">
              <AlertTriangle className="h-5 w-5 text-red-600" />
            </div>
            <div>
              <AlertDialogTitle>{title}</AlertDialogTitle>
              <AlertDialogDescription className="mt-1">
                {description}
              </AlertDialogDescription>
            </div>
          </div>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel disabled={isPending}>Batal</AlertDialogCancel>
          <AlertDialogAction
            onClick={handleDelete}
            disabled={isPending}
            className="bg-red-600 hover:bg-red-700"
          >
            {isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Menghapus...
              </>
            ) : (
              "Hapus"
            )}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

