"use client"

import { useRef, useState, useTransition } from "react"
import { Camera, Loader2, User, X } from "lucide-react"
import { toast } from "sonner"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"

type Props = {
  user: {
    id: string
    email: string
    name: string
    photoUrl: string | null
  }
  action: (formData: FormData) => Promise<{ success: boolean; error?: string }>
}

export function ProfileForm({ user, action }: Props) {
  const fileInputRef = useRef<HTMLInputElement | null>(null)
  const [name, setName] = useState(user.name)
  const [photoData, setPhotoData] = useState<string | null>(user.photoUrl)
  const [isPending, startTransition] = useTransition()
  const router = useRouter()

  const handleFileChange = (files?: FileList | null) => {
    if (!files?.length) return
    const file = files[0]
    const reader = new FileReader()
    reader.onload = () => {
      const result = reader.result?.toString() ?? ""
      setPhotoData(result)
    }
    reader.onerror = () => {
      toast.error("Gagal membaca file foto")
    }
    reader.readAsDataURL(file)
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (!name.trim()) {
      toast.error("Nama wajib diisi")
      return
    }

    startTransition(async () => {
      try {
        const formData = new FormData()
        formData.set("name", name.trim())
        if (photoData && photoData !== user.photoUrl) {
          formData.set("photo", photoData)
        }

        const result = await action(formData)

        if (result.success) {
          toast.success("Profil berhasil diperbarui")
          router.refresh()
        } else {
          toast.error(result.error || "Gagal memperbarui profil")
        }
      } catch (error) {
        console.error(error)
        toast.error("Gagal memperbarui profil")
      }
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="flex flex-col items-center gap-4">
        <div className="relative">
          <div className="h-24 w-24 rounded-full border-2 border-slate-200 bg-slate-50 overflow-hidden flex items-center justify-center">
            {photoData ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={photoData}
                alt={name}
                className="h-full w-full object-cover"
              />
            ) : (
              <User className="h-12 w-12 text-slate-400" />
            )}
          </div>
          {photoData && photoData !== user.photoUrl && (
            <button
              type="button"
              onClick={() => setPhotoData(user.photoUrl)}
              className="absolute -top-1 -right-1 rounded-full bg-red-500 text-white p-1 hover:bg-red-600 transition-colors"
              aria-label="Hapus foto baru"
            >
              <X className="h-3 w-3" />
            </button>
          )}
        </div>
        <div className="flex flex-col items-center gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => handleFileChange(e.target.files)}
          />
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="gap-2"
            disabled={isPending}
            onClick={() => fileInputRef.current?.click()}
          >
            <Camera className="h-4 w-4" />
            {photoData && photoData !== user.photoUrl ? "Ganti Foto" : "Upload Foto"}
          </Button>
          <p className="text-xs text-slate-500 text-center">
            Format: JPG, PNG. Maksimal 5MB
          </p>
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="email">Email</Label>
        <Input
          id="email"
          type="email"
          value={user.email}
          disabled
          className="bg-slate-50"
        />
        <p className="text-xs text-slate-500">Email tidak dapat diubah</p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="name">Nama</Label>
        <Input
          id="name"
          name="name"
          value={name}
          onChange={(e) => setName(e.target.value)}
          placeholder="Masukkan nama lengkap"
          required
          disabled={isPending}
        />
      </div>

      <div className="flex gap-3">
        <Button type="submit" disabled={isPending} className="flex-1 sm:flex-none">
          {isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Menyimpan...
            </>
          ) : (
            "Simpan Perubahan"
          )}
        </Button>
      </div>
    </form>
  )
}

