"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { Loader2 } from "lucide-react"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

type Props = {
  id: string
  currentStatus: string
  currentFollowUpNote?: string | null
  action: (formData: FormData) => Promise<{ success: boolean; error?: string } | void>
}

const STATUS_LABEL: Record<string, string> = {
  PROSPECT: "Prospect",
  FOLLOW_UP: "Follow Up",
  PROJECTION: "Projection",
  REJECTED: "Rejected",
  CANCELED: "Canceled",
}

export function FollowUpForm({ id, currentStatus, currentFollowUpNote, action }: Props) {
  const [status, setStatus] = useState(currentStatus)
  const [followUpNote, setFollowUpNote] = useState(currentFollowUpNote || "")
  const [isPending, startTransition] = useTransition()
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    
    const formData = new FormData()
    formData.set("id", id)
    formData.set("status", status)
    formData.set("followUpNote", followUpNote.trim())

    startTransition(async () => {
      try {
        const result = await action(formData)
        
        // Handle result if action returns a result object
        if (result && typeof result === "object") {
          if (result.success) {
            toast.success("Follow up diperbarui")
            router.refresh()
          } else {
            const errorMsg = 
              result.error === "invalid" ? "Data tidak valid" :
              result.error === "unauthorized" ? "Tidak diizinkan" :
              result.error === "failed" ? "Gagal memproses data" :
              "Terjadi kesalahan"
            toast.error(errorMsg)
          }
        } else {
          // If action doesn't return result (old behavior with redirect)
          router.refresh()
        }
      } catch (error: any) {
        // Next.js redirect throws a special error that we should ignore
        if (error?.digest?.startsWith("NEXT_REDIRECT") || error?.message?.includes("NEXT_REDIRECT")) {
          // Redirect is happening, this is expected behavior
          return
        }
        // For other errors
        console.error("Error updating follow up:", error)
        toast.error("Gagal memproses data")
      }
    })
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-2">
      <Select value={status} onValueChange={setStatus} disabled={isPending}>
        <SelectTrigger>
          <SelectValue placeholder="Status" />
        </SelectTrigger>
        <SelectContent>
          {Object.entries(STATUS_LABEL).map(([value, label]) => (
            <SelectItem key={value} value={value}>
              {label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
      <Textarea
        value={followUpNote}
        onChange={(e) => setFollowUpNote(e.target.value)}
        placeholder="Catatan follow up"
        rows={2}
        disabled={isPending}
      />
      <Button type="submit" size="sm" className="w-full" disabled={isPending}>
        {isPending ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Menyimpan...
          </>
        ) : (
          "Simpan Follow Up"
        )}
      </Button>
    </form>
  )
}

