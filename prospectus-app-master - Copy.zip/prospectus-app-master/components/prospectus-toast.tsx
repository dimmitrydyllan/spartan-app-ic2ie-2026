"use client"

import { useEffect } from "react"
import { toast } from "sonner"

type Props = {
  success?: string
  error?: string
}

export function ProspectusToast({ success, error }: Props) {
  useEffect(() => {
    if (success) {
      toast.success(success, { id: "prospectus-success" })
    }
  }, [success])

  useEffect(() => {
    if (error) {
      toast.error(error, { id: "prospectus-error" })
    }
  }, [error])

  return null
}

