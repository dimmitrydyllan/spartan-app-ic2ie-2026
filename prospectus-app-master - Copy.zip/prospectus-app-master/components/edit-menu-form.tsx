"use client";

import { useState, useTransition, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Edit, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Menu = {
  id: string;
  name: string;
};

type Props = {
  menu: {
    id: string;
    name: string;
    path: string;
    icon?: string | null;
    parentId?: string | null;
    order: number;
  };
  rootMenus: Menu[];
  action: (formData: FormData) => Promise<{ success: boolean; error?: string } | void>;
};

export function EditMenuForm({ menu, rootMenus, action }: Props) {
  const [open, setOpen] = useState(false);
  const [selectedParent, setSelectedParent] = useState<string>(
    menu.parentId || "none"
  );
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);

  // Reset form when dialog opens
  useEffect(() => {
    if (open && formRef.current) {
      setSelectedParent(menu.parentId || "none");
    }
  }, [open, menu.parentId]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    formData.set("id", menu.id);
    if (selectedParent && selectedParent !== "none") {
      formData.set("parentId", selectedParent);
    }

    startTransition(async () => {
      try {
        const result = await action(formData);
        if (result && typeof result === "object") {
          if (result.success) {
            toast.success("Menu berhasil diperbarui");
            setOpen(false);
            router.refresh();
          } else {
            const errorMsg =
              result.error === "invalid" ? "Data tidak valid" :
              result.error === "unauthorized" ? "Tidak diizinkan" :
              result.error === "forbidden" ? "Tidak memiliki izin" :
              result.error === "not_found" ? "Menu tidak ditemukan" :
              result.error === "duplicate" ? "Menu path sudah ada" :
              result.error === "failed" ? "Gagal memproses data" :
              "Terjadi kesalahan";
            toast.error(errorMsg);
          }
        } else {
          router.refresh();
        }
      } catch (error: any) {
        if (error?.digest?.startsWith("NEXT_REDIRECT") || error?.message?.includes("NEXT_REDIRECT")) {
          return;
        }
        console.error("Error updating menu:", error);
        toast.error("Gagal memproses data");
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
          <Edit className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="w-[95vw] sm:max-w-md max-h-[90vh] overflow-y-auto mx-4 sm:mx-auto">
        <form ref={formRef} onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Edit Menu</DialogTitle>
            <DialogDescription>
              Perbarui informasi menu. Path harus unik.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nama Menu</Label>
              <Input
                id="name"
                name="name"
                placeholder="Ringkasan"
                defaultValue={menu.name}
                required
                disabled={isPending}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="path">Path</Label>
              <Input
                id="path"
                name="path"
                placeholder="/dashboard"
                defaultValue={menu.path}
                required
                disabled={isPending}
              />
              <p className="text-xs text-slate-500">
                Contoh: /dashboard, /dashboard/absensi
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="icon">Icon (opsional)</Label>
              <Input
                id="icon"
                name="icon"
                placeholder="home"
                defaultValue={menu.icon || ""}
                disabled={isPending}
              />
              <p className="text-xs text-slate-500">
                Nama icon dari lucide-react (contoh: home, calendar)
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="parentId">Parent Menu (opsional)</Label>
              <Select
                value={selectedParent}
                onValueChange={setSelectedParent}
              >
                <SelectTrigger id="parentId" disabled={isPending}>
                  <SelectValue placeholder="Pilih parent menu" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Tidak ada parent</SelectItem>
                  {rootMenus
                    .filter((m) => m.id !== menu.id)
                    .map((menuItem) => (
                      <SelectItem key={menuItem.id} value={menuItem.id}>
                        {menuItem.name}
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="order">Urutan</Label>
              <Input
                id="order"
                name="order"
                type="number"
                defaultValue={menu.order}
                min="0"
                disabled={isPending}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              disabled={isPending}
              className="w-full sm:w-auto"
            >
              Batal
            </Button>
            <Button type="submit" disabled={isPending} className="w-full sm:w-auto">
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Memproses...
                </>
              ) : (
                "Simpan"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

