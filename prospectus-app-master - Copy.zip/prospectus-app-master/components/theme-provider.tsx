"use client"

import { createContext, useContext, useEffect, useState } from "react"
import { getAppearanceSettings } from "@/app/settings/actions"

type Theme = "light" | "dark" | "system"

type ThemeProviderProps = {
  children: React.ReactNode
  defaultTheme?: Theme
  storageKey?: string
}

type ThemeProviderState = {
  theme: Theme
  setTheme: (theme: Theme) => void
}

const initialState: ThemeProviderState = {
  theme: "system",
  setTheme: () => null,
}

const ThemeProviderContext = createContext<ThemeProviderState>(initialState)

export function ThemeProvider({
  children,
  defaultTheme = "system",
  storageKey = "theme",
  ...props
}: ThemeProviderProps) {
  const [theme, setTheme] = useState<Theme>(defaultTheme)
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
    
    // Priority: database > localStorage > defaultTheme
    if (typeof window !== "undefined") {
      // First, try to get from database
      getAppearanceSettings().then((data) => {
        if (data?.theme) {
          const dbTheme = data.theme as Theme
          setTheme(dbTheme)
          // Sync with localStorage
          localStorage.setItem(storageKey, dbTheme)
          // Apply font size and compact mode
          if (data.fontSize) {
            document.documentElement.setAttribute("data-font-size", data.fontSize)
          }
          if (data.compactMode !== undefined) {
            document.documentElement.setAttribute("data-compact", data.compactMode.toString())
          }
        } else {
          // Fallback to localStorage
          const storedTheme = localStorage.getItem(storageKey) as Theme
          if (storedTheme) {
            setTheme(storedTheme)
          }
        }
      }).catch(() => {
        // If database fetch fails, fallback to localStorage
        const storedTheme = localStorage.getItem(storageKey) as Theme
        if (storedTheme) {
          setTheme(storedTheme)
        }
      })
    }
  }, [storageKey])

  useEffect(() => {
    if (!mounted) return

    const root = window.document.documentElement

    root.classList.remove("light", "dark")

    if (theme === "system") {
      const systemTheme = window.matchMedia("(prefers-color-scheme: dark)")
        .matches
        ? "dark"
        : "light"

      root.classList.add(systemTheme)
      return
    }

    root.classList.add(theme)
  }, [theme, mounted])

  const value = {
    theme,
    setTheme: (newTheme: Theme) => {
      if (typeof window !== "undefined") {
        localStorage.setItem(storageKey, newTheme)
      }
      setTheme(newTheme)
    },
  }

  return (
    <ThemeProviderContext.Provider {...props} value={value}>
      {children}
    </ThemeProviderContext.Provider>
  )
}

export const useTheme = () => {
  const context = useContext(ThemeProviderContext)

  if (context === undefined)
    throw new Error("useTheme must be used within a ThemeProvider")

  return context
}

