"use client"

import { useRef, useState, useTransition, type ChangeEvent } from "react"
import { Camera, ImageOff, ImageUp, Loader2, Upload, X } from "lucide-react"
import { toast } from "sonner"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"

type Props = {
  activity: {
    id: string
    brokerName: string | null
    title: string
    clientPhone: string | null
    description: string | null
    status: string
    photoUrls: string[]
  }
  userId: string
  action: (formData: FormData) => Promise<{ success: boolean; error?: string } | void>
  open: boolean
  onOpenChange: (open: boolean) => void
}

const STATUS_OPTIONS: Array<{ value: string; label: string }> = [
  { value: "PROSPECT", label: "Prospect" },
  { value: "FOLLOW_UP", label: "Follow Up" },
  { value: "PROJECTION", label: "Projection" },
  { value: "REJECTED", label: "Rejected" },
  { value: "CANCELED", label: "Canceled" },
]

export function EditProspectusForm({ activity, userId, action, open, onOpenChange }: Props) {
  const captureInputRef = useRef<HTMLInputElement | null>(null)
  const uploadInputRef = useRef<HTMLInputElement | null>(null)
  const [brokerName, setBrokerName] = useState(activity.brokerName || "")
  const [title, setTitle] = useState(activity.title)
  const [clientPhone, setClientPhone] = useState(activity.clientPhone || "")
  const [description, setDescription] = useState(activity.description || "")
  const [status, setStatus] = useState(activity.status)
  const [photoDatas, setPhotoDatas] = useState<string[]>([])
  const [existingPhotos, setExistingPhotos] = useState<string[]>(activity.photoUrls || [])
  const [isPending, startTransition] = useTransition()
  const router = useRouter()

  // Reset form ketika dialog dibuka/ditutup
  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      // Reset ke nilai awal saat dialog ditutup
      setBrokerName(activity.brokerName || "")
      setTitle(activity.title)
      setClientPhone(activity.clientPhone || "")
      setDescription(activity.description || "")
      setStatus(activity.status)
      setPhotoDatas([])
      setExistingPhotos(activity.photoUrls || [])
    }
    onOpenChange(newOpen)
  }

  const handleFileChange = (files?: FileList | null) => {
    if (!files?.length) return
    
    const list = Array.from(files)
    let loadedCount = 0
    let errorCount = 0
    
    list.forEach((file) => {
      // Validasi tipe file
      if (!file.type.startsWith('image/')) {
        errorCount++
        toast.error(`File ${file.name} bukan gambar`)
        return
      }
      
      const reader = new FileReader()
      reader.onload = () => {
        const result = reader.result?.toString() ?? ""
        if (result) {
          setPhotoDatas((prev) => [...prev, result])
          loadedCount++
          
          // Tampilkan toast setelah semua file selesai
          if (loadedCount + errorCount === list.length) {
            if (loadedCount > 0) {
              toast.success(`${loadedCount} foto terlampir`)
            }
          }
        }
      }
      reader.onerror = () => {
        errorCount++
        toast.error(`Gagal membaca file ${file.name}`)
      }
      reader.readAsDataURL(file)
    })
  }

  const handleRemoveExistingPhoto = (index: number) => {
    setExistingPhotos((prev) => prev.filter((_, i) => i !== index))
  }

  const onSubmit = () => {
    if (!title.trim()) {
      toast.error("Judul wajib diisi")
      return
    }

    startTransition(async () => {
      try {
        const fd = new FormData()
        fd.set("id", activity.id)
        fd.set("userId", userId)
        fd.set("brokerName", brokerName.trim())
        fd.set("title", title.trim())
        fd.set("clientPhone", clientPhone.trim())
        fd.set("description", description.trim())
        fd.set("status", status)
        
        // Kirim foto yang sudah ada (URL) dan foto baru (base64)
        // Format: { existing: [...urls], new: [...base64] }
        // Selalu kirim photos data, bahkan jika kosong, untuk memastikan foto yang dihapus benar-benar dihapus
        const photosData = {
          existing: existingPhotos,
          new: photoDatas,
        }
        fd.set("photos", JSON.stringify(photosData))

        const result = await action(fd)
        if (result && typeof result === "object") {
          if (result.success) {
            toast.success("Aktivitas berhasil diperbarui")
            router.refresh()
            handleOpenChange(false)
          } else {
            const errorMsg =
              result.error === "invalid"
                ? "Data tidak valid"
                : result.error === "unauthorized"
                ? "Tidak diizinkan"
                : "Gagal memperbarui aktivitas"
            toast.error(errorMsg)
          }
        } else {
          toast.success("Aktivitas berhasil diperbarui")
          router.refresh()
          handleOpenChange(false)
        }
      } catch (error: any) {
        if (error?.message === "INVALID") {
          toast.error("Data tidak valid")
          return
        }
        console.error(error)
        toast.error("Gagal memperbarui aktivitas")
      }
    })
  }

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Aktivitas</DialogTitle>
        </DialogHeader>
        <div className="space-y-3">
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-2">
              <label className="text-sm font-medium">Nama Broker (Business Consultant)</label>
              <Input
                value={brokerName}
                onChange={(e) => setBrokerName(e.target.value)}
                placeholder="Contoh: John Doe"
                disabled={isPending}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Nama Client</label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Contoh: Follow up client A"
                disabled={isPending}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Nomor Telepon Client</label>
              <Input
                value={clientPhone}
                onChange={(e) => setClientPhone(e.target.value)}
                placeholder="Contoh: 0812xxxxxxx"
                disabled={isPending}
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium">Status</label>
              <Select value={status} onValueChange={setStatus} disabled={isPending}>
                <SelectTrigger>
                  <SelectValue placeholder="Pilih status" />
                </SelectTrigger>
                <SelectContent>
                  {STATUS_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Deskripsi</label>
            <Textarea
              value={description}
              onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
              placeholder="Detail aktivitas, rencana tindak lanjut, dsb."
              rows={3}
              disabled={isPending}
            />
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Lampirkan foto</label>
            <div className="flex flex-wrap items-center gap-3">
              <input
                ref={captureInputRef}
                type="file"
                accept="image/*"
                capture="environment"
                multiple
                className="hidden"
                onChange={(e) => {
                  const files = e.target.files
                  if (files && files.length > 0) {
                    handleFileChange(files)
                    if (captureInputRef.current) {
                      captureInputRef.current.value = ''
                    }
                  }
                }}
              />
              <input
                ref={uploadInputRef}
                type="file"
                accept="image/*"
                multiple
                className="hidden"
                onChange={(e) => {
                  const files = e.target.files
                  if (files && files.length > 0) {
                    handleFileChange(files)
                    if (uploadInputRef.current) {
                      uploadInputRef.current.value = ''
                    }
                  }
                }}
              />
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="gap-2"
                disabled={isPending}
                onClick={() => captureInputRef.current?.click()}
              >
                <Camera className="h-4 w-4" />
                Ambil Foto
              </Button>
              <Button
                type="button"
                variant="outline"
                size="sm"
                className="gap-2"
                disabled={isPending}
                onClick={() => uploadInputRef.current?.click()}
              >
                <ImageUp className="h-4 w-4" />
                Upload dari Album
              </Button>
              {(existingPhotos.length > 0 || photoDatas.length > 0) && (
                <div className="flex flex-wrap gap-2 w-full">
                  {existingPhotos.map((photo, idx) => (
                    <div key={`existing-${idx}`} className="relative h-14 w-14 overflow-hidden rounded border border-slate-200">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={photo} alt={`Lampiran ${idx + 1}`} className="h-full w-full object-cover" />
                      <button
                        type="button"
                        onClick={() => handleRemoveExistingPhoto(idx)}
                        className="absolute -right-1 -top-1 rounded-full bg-white shadow p-0.5 text-slate-600 hover:text-slate-900"
                        aria-label="Hapus foto"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                  {photoDatas.map((photo, idx) => (
                    <div key={`new-${idx}`} className="relative h-14 w-14 overflow-hidden rounded border border-slate-200">
                      {/* eslint-disable-next-line @next/next/no-img-element */}
                      <img src={photo} alt={`Lampiran baru ${idx + 1}`} className="h-full w-full object-cover" />
                      <button
                        type="button"
                        onClick={() =>
                          setPhotoDatas((prev) => prev.filter((_, i) => i !== idx))
                        }
                        className="absolute -right-1 -top-1 rounded-full bg-white shadow p-0.5 text-slate-600 hover:text-slate-900"
                        aria-label="Hapus foto"
                      >
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ))}
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    className="gap-1 text-slate-700"
                    onClick={() => {
                      setExistingPhotos([])
                      setPhotoDatas([])
                    }}
                  >
                    <ImageOff className="h-4 w-4" />
                    Hapus semua
                  </Button>
                </div>
              )}
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => handleOpenChange(false)}
              disabled={isPending}
            >
              Batal
            </Button>
            <Button type="button" onClick={onSubmit} disabled={isPending}>
              {isPending ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                  Menyimpan...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Simpan Perubahan
                </>
              )}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

