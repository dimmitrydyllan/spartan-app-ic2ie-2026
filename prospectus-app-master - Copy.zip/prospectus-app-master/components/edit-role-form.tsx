"use client";

import { useState, useTransition, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Edit, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

type Props = {
  role: {
    id: string;
    code: string;
    name: string;
  };
  action: (formData: FormData) => Promise<{ success: boolean; error?: string } | void>;
};

export function EditRoleForm({ role, action }: Props) {
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);

  // Reset form when dialog opens
  useEffect(() => {
    if (open && formRef.current) {
      // Form will use defaultValue, so no need to reset
    }
  }, [open]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    formData.set("id", role.id);

    startTransition(async () => {
      try {
        const result = await action(formData);
        if (result && typeof result === "object") {
          if (result.success) {
            toast.success("Role berhasil diperbarui");
            setOpen(false);
            router.refresh();
          } else {
            const errorMsg =
              result.error === "invalid" ? "Data tidak valid" :
              result.error === "unauthorized" ? "Tidak diizinkan" :
              result.error === "forbidden" ? "Tidak memiliki izin" :
              result.error === "not_found" ? "Role tidak ditemukan" :
              result.error === "duplicate" ? "Role code sudah ada" :
              result.error === "failed" ? "Gagal memproses data" :
              "Terjadi kesalahan";
            toast.error(errorMsg);
          }
        } else {
          router.refresh();
        }
      } catch (error: any) {
        if (error?.digest?.startsWith("NEXT_REDIRECT") || error?.message?.includes("NEXT_REDIRECT")) {
          return;
        }
        console.error("Error updating role:", error);
        toast.error("Gagal memproses data");
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
          <Edit className="h-4 w-4" />
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <form ref={formRef} onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Edit Role</DialogTitle>
            <DialogDescription>
              Perbarui informasi role. Code role harus unik.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="code">Code Role</Label>
              <Input
                id="code"
                name="code"
                placeholder="ADMIN"
                defaultValue={role.code}
                required
                pattern="[A-Z0-9_]+"
                title="Hanya huruf besar, angka, dan underscore"
                className="uppercase"
                disabled={isPending}
              />
              <p className="text-xs text-slate-500">
                Format: Huruf besar, angka, underscore (contoh: ADMIN, SALES_01)
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Nama Role</Label>
              <Input
                id="name"
                name="name"
                placeholder="Administrator"
                defaultValue={role.name}
                required
                disabled={isPending}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              disabled={isPending}
              className="w-full sm:w-auto"
            >
              Batal
            </Button>
            <Button type="submit" disabled={isPending} className="w-full sm:w-auto">
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Memproses...
                </>
              ) : (
                "Simpan"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

