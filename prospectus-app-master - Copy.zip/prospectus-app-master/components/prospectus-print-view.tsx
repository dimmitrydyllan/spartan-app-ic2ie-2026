"use client"

import { useEffect } from "react"

type Activity = {
  id: string
  title: string
  brokerName?: string | null
  clientPhone?: string | null
  status: string
  activityDate: string | Date
  description?: string | null
  followUpNote?: string | null
  photoUrls?: string[] | null
}

type Props = {
  activities: Activity[]
  userName?: string | null
}

function formatDate(value: string | Date) {
  try {
    const d = typeof value === "string" ? new Date(value) : value
    return new Intl.DateTimeFormat("id-ID", {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(d)
  } catch {
    return String(value)
  }
}

export function ProspectusPrintView({ activities, userName }: Props) {
  useEffect(() => {
    // Otomatis buka dialog print saat halaman dibuka
    window.print()
  }, [])

  return (
    <div className="min-h-screen bg-white text-black p-6 print:p-2">
      <div className="mb-6 flex items-center justify-between print:hidden">
        <div>
          <h1 className="text-2xl font-bold">Laporan Prospectus</h1>
          {userName ? (
            <p className="text-sm text-slate-600">Sales: {userName}</p>
          ) : null}
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => window.print()}
            className="rounded border border-slate-300 bg-white px-3 py-1 text-sm hover:bg-slate-50"
          >
            Print
          </button>
          <button
            type="button"
            onClick={() => window.close()}
            className="rounded border border-slate-300 bg-white px-3 py-1 text-sm hover:bg-slate-50"
          >
            Tutup
          </button>
        </div>
      </div>

      <div className="mb-4 text-sm text-slate-600 print:text-black">
        <p>
          Tanggal cetak:{" "}
          {new Intl.DateTimeFormat("id-ID", {
            dateStyle: "medium",
            timeStyle: "short",
          }).format(new Date())}
        </p>
        <p>Jumlah aktivitas: {activities.length}</p>
      </div>

      <table className="w-full border-collapse text-xs print:text-[11px]">
        <thead>
          <tr>
            <th className="border border-slate-400 px-2 py-1 text-center">No.</th>
            <th className="border border-slate-400 px-2 py-1 text-left">Nama Broker</th>
            <th className="border border-slate-400 px-2 py-1 text-left">Nama Client</th>
            <th className="border border-slate-400 px-2 py-1 text-left">No. Telepon</th>
            <th className="border border-slate-400 px-2 py-1 text-left">Status</th>
            <th className="border border-slate-400 px-2 py-1 text-left">Tanggal</th>
            <th className="border border-slate-400 px-2 py-1 text-left">Deskripsi</th>
            <th className="border border-slate-400 px-2 py-1 text-left">Follow Up</th>
            <th className="border border-slate-400 px-2 py-1 text-left">Foto</th>
          </tr>
        </thead>
        <tbody>
          {activities.length === 0 ? (
            <tr>
              <td
                colSpan={9}
                className="border border-slate-400 px-2 py-4 text-center text-slate-500"
              >
                Tidak ada data prospectus
              </td>
            </tr>
          ) : (
            activities.map((act, index) => {
              const photos = Array.isArray(act.photoUrls) ? act.photoUrls : []
              return (
                <tr key={act.id}>
                  <td className="border border-slate-300 px-2 py-1 align-top text-center">
                    {index + 1}
                  </td>
                  <td className="border border-slate-300 px-2 py-1 align-top">
                    {act.brokerName || "-"}
                  </td>
                  <td className="border border-slate-300 px-2 py-1 align-top">
                    <span className="font-semibold">{act.title}</span>
                  </td>
                  <td className="border border-slate-300 px-2 py-1 align-top">
                    {act.clientPhone || "-"}
                  </td>
                  <td className="border border-slate-300 px-2 py-1 align-top">
                    {act.status}
                  </td>
                  <td className="border border-slate-300 px-2 py-1 align-top">
                    {formatDate(act.activityDate)}
                  </td>
                  <td className="border border-slate-300 px-2 py-1 align-top">
                    {act.description || "-"}
                  </td>
                  <td className="border border-slate-300 px-2 py-1 align-top">
                    {act.followUpNote || "-"}
                  </td>
                  <td className="border border-slate-300 px-2 py-1 align-top">
                    {photos.length ? (
                      <div className="flex flex-wrap gap-1">
                        {photos.map((url, idx) => (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img
                            key={idx}
                            src={url}
                            alt={`Foto ${idx + 1}`}
                            className="h-16 w-16 rounded object-cover border border-slate-300"
                          />
                        ))}
                      </div>
                    ) : (
                      "-"
                    )}
                  </td>
                </tr>
              )
            })
          )}
        </tbody>
      </table>
    </div>
  )
}


