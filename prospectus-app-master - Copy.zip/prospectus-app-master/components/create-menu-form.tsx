"use client";

import { useState, useTransition, useRef, useEffect } from "react";
import { useRouter } from "next/navigation";
import { Plus, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Menu = {
  id: string;
  name: string;
};

type Props = {
  rootMenus: Menu[];
  action: (formData: FormData) => Promise<{ success: boolean; error?: string } | void>;
};

export function CreateMenuForm({ rootMenus, action }: Props) {
  const [open, setOpen] = useState(false);
  const [selectedParent, setSelectedParent] = useState<string>("none");
  const [isPending, startTransition] = useTransition();
  const router = useRouter();
  const formRef = useRef<HTMLFormElement>(null);

  // Reset form when dialog opens
  useEffect(() => {
    if (open && formRef.current) {
      formRef.current.reset();
      setSelectedParent("none");
    }
  }, [open]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    if (selectedParent && selectedParent !== "none") {
      formData.set("parentId", selectedParent);
    }

    startTransition(async () => {
      try {
        const result = await action(formData);
        if (result && typeof result === "object") {
          if (result.success) {
            toast.success("Menu berhasil dibuat");
            setOpen(false);
            router.refresh();
          } else {
            const errorMsg =
              result.error === "invalid" ? "Data tidak valid" :
              result.error === "duplicate" ? "Menu path sudah ada" :
              result.error === "failed" ? "Gagal memproses data" :
              "Terjadi kesalahan";
            toast.error(errorMsg);
          }
        } else {
          router.refresh();
        }
      } catch (error: any) {
        if (error?.digest?.startsWith("NEXT_REDIRECT") || error?.message?.includes("NEXT_REDIRECT")) {
          return;
        }
        console.error("Error creating menu:", error);
        toast.error("Gagal memproses data");
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" className="w-full sm:w-auto">
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">Tambah Menu</span>
          <span className="sm:hidden">Tambah</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="w-[95vw] sm:max-w-md max-h-[90vh] overflow-y-auto mx-4 sm:mx-auto">
        <form ref={formRef} onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Tambah Menu Baru</DialogTitle>
            <DialogDescription>
              Buat menu baru untuk sistem. Path harus unik.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nama Menu</Label>
              <Input
                id="name"
                name="name"
                placeholder="Ringkasan"
                required
                disabled={isPending}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="path">Path</Label>
              <Input
                id="path"
                name="path"
                placeholder="/dashboard"
                required
                disabled={isPending}
              />
              <p className="text-xs text-slate-500">
                Contoh: /dashboard, /dashboard/absensi
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="icon">Icon (opsional)</Label>
              <Input
                id="icon"
                name="icon"
                placeholder="home"
                disabled={isPending}
              />
              <p className="text-xs text-slate-500">
                Nama icon dari lucide-react (contoh: home, calendar)
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="parentId">Parent Menu (opsional)</Label>
              <Select
                value={selectedParent}
                onValueChange={setSelectedParent}
              >
                <SelectTrigger id="parentId" disabled={isPending}>
                  <SelectValue placeholder="Pilih parent menu" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Tidak ada parent</SelectItem>
                  {rootMenus.map((menu) => (
                    <SelectItem key={menu.id} value={menu.id}>
                      {menu.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="order">Urutan</Label>
              <Input
                id="order"
                name="order"
                type="number"
                defaultValue="0"
                min="0"
                disabled={isPending}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              disabled={isPending}
              className="w-full sm:w-auto"
            >
              Batal
            </Button>
            <Button type="submit" disabled={isPending} className="w-full sm:w-auto">
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Memproses...
                </>
              ) : (
                "Simpan"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

