"use client"

import { useEffect } from "react"

import { toast } from "sonner"

type Props = {
  success?: string
  error?: string
}

export function AbsensiToast({ success, error }: Props) {
  useEffect(() => {
    if (success) {
      toast.success(success, { id: "absensi-success" })
    }
    if (error) {
      toast.error(error, { id: "absensi-error" })
    }
  }, [success, error])

  return null
}

