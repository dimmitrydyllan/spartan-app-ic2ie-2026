"use client"

import { useEffect, useRef, useState, useTransition } from "react"
import { Camera, CheckCircle2, Loader2, RefreshCw } from "lucide-react"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

type Props = {
  userId: string
  type: "IN" | "OUT"
  action: (formData: FormData) => Promise<void>
}

export function AttendanceCapture({ userId, type, action }: Props) {
  const videoRef = useRef<HTMLVideoElement | null>(null)
  const canvasRef = useRef<HTMLCanvasElement | null>(null)
  const [stream, setStream] = useState<MediaStream | null>(null)
  const [photoData, setPhotoData] = useState<string>("")
  const [note, setNote] = useState("")
  const [isPending, startTransition] = useTransition()
  const [error, setError] = useState<string>("")

  useEffect(() => {
    return () => {
      stopCamera()
    }
  }, [])

  const startCamera = async () => {
    try {
      setError("")
      const media = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: "user" },
        audio: false,
      })
      setStream(media)
      if (videoRef.current) {
        videoRef.current.srcObject = media
        await videoRef.current.play()
      }
    } catch (e) {
      const message =
        "Tidak dapat mengakses kamera. Izinkan akses kamera di browser Anda."
      setError(message)
      toast.error(message)
    }
  }

  const stopCamera = () => {
    stream?.getTracks().forEach((t) => t.stop())
    setStream(null)
  }

  const capture = () => {
    if (!videoRef.current || !canvasRef.current) return
    const video = videoRef.current
    const canvas = canvasRef.current
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    const ctx = canvas.getContext("2d")
    if (!ctx) return
    ctx.drawImage(video, 0, 0, canvas.width, canvas.height)
    const dataUrl = canvas.toDataURL("image/jpeg", 0.85)
    setPhotoData(dataUrl)
    stopCamera()
  }

  const retake = () => {
    setPhotoData("")
    startCamera()
  }

  const onSubmit = () => {
    if (!photoData) {
      setError("Silakan ambil foto terlebih dahulu.")
      return
    }
    setError("")
    startTransition(async () => {
      const formData = new FormData()
      formData.set("userId", userId)
      formData.set("type", type)
      formData.set("note", note)
      formData.set("photoData", photoData)
      await action(formData)
      toast.success("Absensi terkirim")
    })
  }

  return (
    <div className="space-y-3 rounded-xl border border-border bg-card p-4 shadow-sm text-foreground">
      <div className="flex items-center justify-between gap-2">
        <div>
          <p className="text-sm font-semibold">
            {type === "IN" ? "Absen Masuk" : "Absen Keluar"}
          </p>
          <p className="text-xs text-muted-foreground">Ambil foto dari kamera, lalu kirim.</p>
        </div>
        <BadgeType type={type} />
      </div>

      <div className="grid gap-3 sm:grid-cols-[2fr_1fr] sm:items-start">
        <div className="space-y-2">
          <div className="relative aspect-video overflow-hidden rounded-lg border border-border bg-muted">
            {!photoData && (
              <video ref={videoRef} className="h-full w-full object-cover" muted playsInline />
            )}
            {photoData && (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={photoData}
                alt="Foto absensi"
                className="h-full w-full object-cover"
              />
            )}
            <canvas ref={canvasRef} className="hidden" />
            {!stream && !photoData && (
              <div className="absolute inset-0 flex items-center justify-center text-muted-foreground text-sm">
                Kamera belum aktif
              </div>
            )}
          </div>
          <div className="flex flex-wrap gap-2">
            <Button
              type="button"
              size="sm"
              variant="outline"
              onClick={startCamera}
              disabled={isPending}
              className="gap-2"
            >
              <Camera className="h-4 w-4" />
              Nyalakan Kamera
            </Button>
            <Button
              type="button"
              size="sm"
              variant="secondary"
              onClick={capture}
              disabled={isPending || !stream}
              className="gap-2"
            >
              <CheckCircle2 className="h-4 w-4" />
              Ambil Foto
            </Button>
            <Button
              type="button"
              size="sm"
              variant="ghost"
              onClick={retake}
              disabled={isPending || (!photoData && !stream)}
              className="gap-2 text-foreground"
            >
              <RefreshCw className="h-4 w-4" />
              Ulangi
            </Button>
          </div>
          {error && <p className="text-xs text-red-600">{error}</p>}
        </div>

        <div className="space-y-2">
          <label className="text-sm font-medium text-foreground">Catatan (opsional)</label>
          <Input
            name="note"
            placeholder="Catatan tambahan"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            disabled={isPending}
          />
          <Button
            type="button"
            className="w-full"
            onClick={onSubmit}
            disabled={isPending || !photoData}
          >
            {isPending ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Mengirim...
              </>
            ) : (
              "Kirim Absen"
            )}
          </Button>
        </div>
      </div>
    </div>
  )
}

function BadgeType({ type }: { type: "IN" | "OUT" }) {
  const style =
    type === "IN"
      ? "border-green-200 text-green-700 bg-green-50 dark:border-green-800 dark:text-green-300 dark:bg-green-950"
      : "border-border text-muted-foreground bg-muted"
  return (
    <span
      className={`rounded-full border px-2 py-0.5 text-xs font-semibold uppercase ${style}`}
    >
      {type === "IN" ? "Masuk" : "Keluar"}
    </span>
  )
}

