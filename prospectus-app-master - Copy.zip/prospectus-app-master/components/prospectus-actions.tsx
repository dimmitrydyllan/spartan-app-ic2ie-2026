"use client"

import { useState } from "react"
import { Edit, Trash2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { EditProspectusForm } from "@/components/edit-prospectus-form"
import { DeleteConfirmDialog } from "@/components/delete-confirm-dialog"

type Props = {
  activity: {
    id: string
    brokerName: string | null
    title: string
    clientPhone: string | null
    description: string | null
    status: string
    photoUrls: string[]
  }
  userId: string
  updateAction: (formData: FormData) => Promise<{ success: boolean; error?: string } | void>
  deleteAction: (formData: FormData) => Promise<{ success: boolean; error?: string } | void>
}

export function ProspectusActions({ activity, userId, updateAction, deleteAction }: Props) {
  const [editOpen, setEditOpen] = useState(false)

  return (
    <>
      <div className="flex items-center gap-2">
        <Button
          type="button"
          variant="ghost"
          size="sm"
          className="h-8 w-8 p-0"
          onClick={() => setEditOpen(true)}
        >
          <Edit className="h-4 w-4" />
        </Button>
        <DeleteConfirmDialog
          title="Hapus Aktivitas"
          description={`Apakah Anda yakin ingin menghapus aktivitas "${activity.title}"? Tindakan ini tidak dapat dibatalkan.`}
          action={deleteAction}
          id={activity.id}
          variant="ghost"
          size="sm"
          successMessage="Aktivitas berhasil dihapus"
          errorMessage="Gagal menghapus aktivitas"
        />
      </div>
      <EditProspectusForm
        activity={activity}
        userId={userId}
        action={updateAction}
        open={editOpen}
        onOpenChange={setEditOpen}
      />
    </>
  )
}


