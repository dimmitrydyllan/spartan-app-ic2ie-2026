"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { Info } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip"
import { SalesMultiSelect } from "@/components/sales-multi-select"

type SalesUser = {
  id: string
  name: string
  email: string
}

type Props = {
  salesUsers: SalesUser[]
  defaultStart: string
  defaultEnd: string
  defaultSelectedSales: string[]
}

export function SupervisorFilterForm({
  salesUsers,
  defaultStart,
  defaultEnd,
  defaultSelectedSales,
}: Props) {
  const router = useRouter()
  const [isPending, startTransition] = useTransition()
  const [start, setStart] = useState(defaultStart)
  const [end, setEnd] = useState(defaultEnd)
  const [selectedSales, setSelectedSales] = useState<string[]>(defaultSelectedSales)

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    startTransition(() => {
      const params = new URLSearchParams()
      if (start) params.set("start", start)
      if (end) params.set("end", end)
      if (selectedSales.length > 0) {
        params.set("sales", selectedSales.join(","))
      }
      router.push(`/supervisor?${params.toString()}`)
    })
  }

  return (
    <form onSubmit={handleSubmit} className="grid gap-3 sm:grid-cols-[1fr_1fr_1fr_auto] sm:items-end">
      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700 block">Dari</label>
        <input
          type="date"
          value={start}
          onChange={(e) => setStart(e.target.value)}
          className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
          disabled={isPending}
        />
      </div>
      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700 block">Sampai</label>
        <input
          type="date"
          value={end}
          onChange={(e) => setEnd(e.target.value)}
          className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
          disabled={isPending}
        />
      </div>
      <div className="space-y-2">
        <div className="flex items-center gap-1.5">
          <label className="text-sm font-medium text-slate-700 block">SBC (opsional)</label>
          <Tooltip>
            <TooltipTrigger asChild>
              <button
                type="button"
                className="inline-flex items-center justify-center rounded-full hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-slate-400 focus:ring-offset-2"
                aria-label="Info"
              >
                <Info className="h-4 w-4 text-slate-500" />
              </button>
            </TooltipTrigger>
            <TooltipContent>
              <p>Bisa pilih lebih dari satu. Kosongkan untuk semua.</p>
            </TooltipContent>
          </Tooltip>
        </div>
        <SalesMultiSelect
          salesUsers={salesUsers}
          selectedIds={selectedSales}
          onSelectionChange={setSelectedSales}
        />
      </div>
      <div className="flex flex-col sm:flex-row gap-2">
        <Button type="submit" className="w-full sm:w-auto h-10" disabled={isPending}>
          {isPending ? "Memproses..." : "Terapkan"}
        </Button>
        <Button
          type="button"
          variant="ghost"
          className="w-full sm:w-auto h-10"
          disabled={isPending}
          onClick={() => {
            setStart(defaultStart)
            setEnd(defaultEnd)
            setSelectedSales([])
            router.push("/supervisor")
          }}
        >
          Reset
        </Button>
      </div>
    </form>
  )
}

