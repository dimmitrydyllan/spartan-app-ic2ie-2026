"use client"

import { useRef, useState, useTransition, type ChangeEvent } from "react"
import { Camera, ImageOff, ImageUp, Loader2, Upload, X } from "lucide-react"
import { toast } from "sonner"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"

type Props = {
  userId: string
  action: (formData: FormData) => Promise<void | { success: boolean }>
}

const STATUS_OPTIONS: Array<{ value: string; label: string }> = [
  { value: "PROSPECT", label: "Prospect" },
  { value: "FOLLOW_UP", label: "Follow Up" },
  { value: "PROJECTION", label: "Projection" },
  { value: "REJECTED", label: "Rejected" },
  { value: "CANCELED", label: "Canceled" },
]

export function ProspectusForm({ userId, action }: Props) {
  const captureInputRef = useRef<HTMLInputElement | null>(null)
  const uploadInputRef = useRef<HTMLInputElement | null>(null)
  const [brokerName, setBrokerName] = useState("")
  const [title, setTitle] = useState("")
  const [clientPhone, setClientPhone] = useState("")
  const [description, setDescription] = useState("")
  const [status, setStatus] = useState("PROSPECT")
  const [photoDatas, setPhotoDatas] = useState<string[]>([])
  const [isPending, startTransition] = useTransition()
  const router = useRouter()

  const handleFileChange = (files?: FileList | null) => {
    if (!files?.length) return
    
    const list = Array.from(files)
    let loadedCount = 0
    let errorCount = 0
    
    list.forEach((file) => {
      // Validasi tipe file
      if (!file.type.startsWith('image/')) {
        errorCount++
        toast.error(`File ${file.name} bukan gambar`)
        return
      }
      
      const reader = new FileReader()
      reader.onload = () => {
        const result = reader.result?.toString() ?? ""
        if (result) {
          setPhotoDatas((prev) => [...prev, result])
          loadedCount++
          
          // Tampilkan toast setelah semua file selesai
          if (loadedCount + errorCount === list.length) {
            if (loadedCount > 0) {
              toast.success(`${loadedCount} foto terlampir`)
            }
          }
        }
      }
      reader.onerror = () => {
        errorCount++
        toast.error(`Gagal membaca file ${file.name}`)
      }
      reader.readAsDataURL(file)
    })
  }

  const onSubmit = () => {
    if (!title.trim()) {
      toast.error("Judul wajib diisi")
      return
    }

    startTransition(async () => {
      try {
        const fd = new FormData()
        fd.set("userId", userId)
        fd.set("brokerName", brokerName.trim())
        fd.set("title", title.trim())
        fd.set("clientPhone", clientPhone.trim())
        fd.set("description", description.trim())
        fd.set("status", status)
        if (photoDatas.length) fd.set("photos", JSON.stringify(photoDatas))

        await action(fd)
        toast.success("Aktivitas dicatat")
        router.refresh()

        // Reset
        setBrokerName("")
        setTitle("")
        setClientPhone("")
        setDescription("")
        setStatus("PROSPECT")
        setPhotoDatas([])
      } catch (error: any) {
        if (error?.message === "INVALID") {
          toast.error("Data tidak valid")
          return
        }
        console.error(error)
        toast.error("Gagal menyimpan aktivitas")
      }
    })
  }

  return (
    <div className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-2">
          <label className="text-sm font-medium">Nama Broker (Business Consultant)</label>
          <Input
            value={brokerName}
            onChange={(e) => setBrokerName(e.target.value)}
            placeholder="Contoh: John Doe"
            disabled={isPending}
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Nama Client</label>
          <Input
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="Contoh: Follow up client A"
            disabled={isPending}
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Nomor Telepon Client</label>
          <Input
            value={clientPhone}
            onChange={(e) => setClientPhone(e.target.value)}
            placeholder="Contoh: 0812xxxxxxx"
            disabled={isPending}
          />
        </div>
        <div className="space-y-2">
          <label className="text-sm font-medium">Status</label>
          <Select value={status} onValueChange={setStatus} disabled={isPending}>
            <SelectTrigger>
              <SelectValue placeholder="Pilih status" />
            </SelectTrigger>
            <SelectContent>
              {STATUS_OPTIONS.map((opt) => (
                <SelectItem key={opt.value} value={opt.value}>
                  {opt.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium">Deskripsi</label>
        <Textarea
          value={description}
          onChange={(e: ChangeEvent<HTMLTextAreaElement>) => setDescription(e.target.value)}
          placeholder="Detail aktivitas, rencana tindak lanjut, dsb."
          rows={3}
          disabled={isPending}
        />
      </div>

      <div className="space-y-2">
        <label className="text-sm font-medium">Lampirkan foto</label>
        <div className="flex flex-wrap items-center gap-3">
          <input
            ref={captureInputRef}
            type="file"
            accept="image/*"
            capture="environment"
            multiple
            className="hidden"
            onChange={(e) => {
              const files = e.target.files
              if (files && files.length > 0) {
                handleFileChange(files)
                // Reset input untuk memastikan onChange bisa terpicu lagi
                if (captureInputRef.current) {
                  captureInputRef.current.value = ''
                }
              }
            }}
          />
          <input
            ref={uploadInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={(e) => {
              const files = e.target.files
              if (files && files.length > 0) {
                handleFileChange(files)
                // Reset input untuk memastikan onChange bisa terpicu lagi
                if (uploadInputRef.current) {
                  uploadInputRef.current.value = ''
                }
              }
            }}
          />
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="gap-2"
            disabled={isPending}
            onClick={() => captureInputRef.current?.click()}
          >
            <Camera className="h-4 w-4" />
            Ambil Foto
          </Button>
          <Button
            type="button"
            variant="outline"
            size="sm"
            className="gap-2"
            disabled={isPending}
            onClick={() => uploadInputRef.current?.click()}
          >
            <ImageUp className="h-4 w-4" />
            Upload dari Album
          </Button>
          {photoDatas.length ? (
            <div className="flex flex-wrap gap-2">
              {photoDatas.map((photo, idx) => (
                <div key={idx} className="relative h-14 w-14 overflow-hidden rounded border border-slate-200">
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={photo} alt={`Lampiran ${idx + 1}`} className="h-full w-full object-cover" />
                  <button
                    type="button"
                    onClick={() =>
                      setPhotoDatas((prev) => prev.filter((_, i) => i !== idx))
                    }
                    className="absolute -right-1 -top-1 rounded-full bg-white shadow p-0.5 text-slate-600 hover:text-slate-900"
                    aria-label="Hapus foto"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </div>
              ))}
              <Button
                type="button"
                variant="ghost"
                size="sm"
                className="gap-1 text-slate-700"
                onClick={() => setPhotoDatas([])}
              >
                <ImageOff className="h-4 w-4" />
                Hapus semua
              </Button>
            </div>
          ) : (
            <span className="text-xs text-slate-500">Opsional, gunakan kamera atau galeri (boleh multiple).</span>
          )}
        </div>
      </div>

      <div>
        <Button type="button" onClick={onSubmit} disabled={isPending} className="w-full sm:w-auto">
          {isPending ? (
            <>
              <Loader2 className="h-4 w-4 animate-spin" />
              Menyimpan...
            </>
          ) : (
            <>
              <Upload className="h-4 w-4" />
              Simpan Aktivitas
            </>
          )}
        </Button>
      </div>
    </div>
  )
}

