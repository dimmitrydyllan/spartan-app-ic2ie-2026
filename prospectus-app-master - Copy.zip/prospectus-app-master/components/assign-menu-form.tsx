"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Shield, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type Menu = {
  id: string;
  name: string;
  path: string;
};

type Role = {
  id: string;
  code: string;
  name: string;
};

export function AssignMenuForm({
  menus,
  roles,
  action,
}: {
  menus: Menu[];
  roles: Role[];
  action: (formData: FormData) => Promise<{ success: boolean; error?: string } | void>;
}) {
  const [open, setOpen] = useState(false);
  const [selectedRole, setSelectedRole] = useState<string>("");
  const [selectedMenu, setSelectedMenu] = useState<string>("");
  const [permissions, setPermissions] = useState({
    canView: true,
    canCreate: false,
    canUpdate: false,
    canDelete: false,
  });
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  const handleSubmit = async (formData: FormData) => {
    if (!selectedRole || !selectedMenu) return;

    formData.set("roleId", selectedRole);
    formData.set("menuId", selectedMenu);
    formData.set("canView", permissions.canView ? "true" : "false");
    formData.set("canCreate", permissions.canCreate ? "true" : "false");
    formData.set("canUpdate", permissions.canUpdate ? "true" : "false");
    formData.set("canDelete", permissions.canDelete ? "true" : "false");

    startTransition(async () => {
      try {
        const result = await action(formData);
        if (result && typeof result === "object") {
          if (result.success) {
            toast.success("Menu berhasil di-assign");
            setOpen(false);
            setSelectedRole("");
            setSelectedMenu("");
            setPermissions({
              canView: true,
              canCreate: false,
              canUpdate: false,
              canDelete: false,
            });
            router.refresh();
          } else {
            const errorMsg =
              result.error === "invalid" ? "Data tidak valid" :
              result.error === "failed" ? "Gagal memproses data" :
              "Terjadi kesalahan";
            toast.error(errorMsg);
          }
        } else {
          router.refresh();
        }
      } catch (error: any) {
        if (error?.digest?.startsWith("NEXT_REDIRECT") || error?.message?.includes("NEXT_REDIRECT")) {
          return;
        }
        console.error("Error assigning menu:", error);
        toast.error("Gagal memproses data");
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" className="gap-2 w-full sm:w-auto">
          <Shield className="h-4 w-4" />
          <span className="hidden sm:inline">Assign Menu</span>
          <span className="sm:hidden">Assign</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="w-[95vw] sm:max-w-md max-h-[90vh] overflow-y-auto mx-4 sm:mx-auto">
        <form action={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Assign Menu ke Role</DialogTitle>
            <DialogDescription>
              Pilih role dan menu, lalu set izin akses yang diizinkan.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="roleId">Pilih Role</Label>
              <Select
                value={selectedRole}
                onValueChange={setSelectedRole}
                required
              >
                <SelectTrigger id="roleId">
                  <SelectValue placeholder="Pilih role..." />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((role) => (
                    <SelectItem key={role.id} value={role.id}>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-semibold text-primary">
                          {role.code}
                        </span>
                        <span className="text-slate-500">-</span>
                        <span>{role.name}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <input type="hidden" name="roleId" value={selectedRole} />
            </div>
            <div className="space-y-2">
              <Label htmlFor="menuId">Pilih Menu</Label>
              <Select
                value={selectedMenu}
                onValueChange={setSelectedMenu}
                required
              >
                <SelectTrigger id="menuId">
                  <SelectValue placeholder="Pilih menu..." />
                </SelectTrigger>
                <SelectContent>
                  {menus.map((menu) => (
                    <SelectItem key={menu.id} value={menu.id}>
                      <div className="flex flex-col">
                        <span className="font-medium">{menu.name}</span>
                        <span className="text-xs text-slate-500">
                          {menu.path}
                        </span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <input type="hidden" name="menuId" value={selectedMenu} />
            </div>
            <div className="space-y-3 border-t pt-3">
              <Label>Izin Akses</Label>
              <div className="space-y-2">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={permissions.canView}
                    onChange={(e) =>
                      setPermissions({ ...permissions, canView: e.target.checked })
                    }
                    className="rounded border-slate-300"
                  />
                  <span className="text-sm">View - Melihat menu</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={permissions.canCreate}
                    onChange={(e) =>
                      setPermissions({ ...permissions, canCreate: e.target.checked })
                    }
                    className="rounded border-slate-300"
                  />
                  <span className="text-sm">Create - Membuat data baru</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={permissions.canUpdate}
                    onChange={(e) =>
                      setPermissions({ ...permissions, canUpdate: e.target.checked })
                    }
                    className="rounded border-slate-300"
                  />
                  <span className="text-sm">Update - Mengubah data</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={permissions.canDelete}
                    onChange={(e) =>
                      setPermissions({ ...permissions, canDelete: e.target.checked })
                    }
                    className="rounded border-slate-300"
                  />
                  <span className="text-sm">Delete - Menghapus data</span>
                </label>
              </div>
            </div>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              disabled={isPending}
              className="w-full sm:w-auto"
            >
              Batal
            </Button>
            <Button
              type="submit"
              disabled={isPending || !selectedRole || !selectedMenu}
              className="w-full sm:w-auto"
            >
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Memproses...
                </>
              ) : (
                "Simpan"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

