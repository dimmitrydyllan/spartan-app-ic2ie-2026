"use client"

import { useState } from "react"
import { Check, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

type SalesUser = {
  id: string
  name: string
  email: string
}

type Props = {
  salesUsers: SalesUser[]
  selectedIds: string[]
  onSelectionChange: (ids: string[]) => void
}

export function SalesMultiSelect({ salesUsers, selectedIds, onSelectionChange }: Props) {
  const [open, setOpen] = useState(false)

  const handleToggle = (userId: string, e?: React.MouseEvent) => {
    if (e) {
      e.preventDefault()
      e.stopPropagation()
    }
    if (selectedIds.includes(userId)) {
      onSelectionChange(selectedIds.filter((id) => id !== userId))
    } else {
      onSelectionChange([...selectedIds, userId])
    }
  }

  const handleClear = (e: React.MouseEvent) => {
    e.preventDefault()
    e.stopPropagation()
    onSelectionChange([])
  }

  const displayText =
    selectedIds.length === 0
      ? "Pilih Sales"
      : selectedIds.length === 1
      ? salesUsers.find((u) => u.id === selectedIds[0])?.name || "Pilih Sales"
      : `${selectedIds.length} Sales dipilih`

  return (
    <div className="space-y-2">
      <Select open={open} onOpenChange={setOpen}>
        <SelectTrigger className="h-10 w-full">
          <SelectValue placeholder="Pilih Sales">
            {displayText}
          </SelectValue>
        </SelectTrigger>
        <SelectContent className="max-h-[300px]">
          <SelectGroup>
            <div className="flex items-center justify-between px-2 py-1.5 border-b">
              <SelectLabel>Sales</SelectLabel>
              {selectedIds.length > 0 && (
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  className="h-6 px-2 text-xs"
                  onClick={handleClear}
                >
                  Hapus semua
                </Button>
              )}
            </div>
            {salesUsers.length === 0 ? (
              <div className="px-2 py-1.5 text-sm text-slate-500">
                Tidak ada sales
              </div>
            ) : (
              <div className="p-1">
                {salesUsers.map((user) => {
                  const isSelected = selectedIds.includes(user.id)
                  return (
                    <div
                      key={user.id}
                      onClick={(e) => handleToggle(user.id, e)}
                      className="flex items-center gap-2 w-full px-2 py-1.5 rounded-sm hover:bg-accent cursor-pointer"
                    >
                      <div
                        className={`flex h-4 w-4 items-center justify-center rounded border shrink-0 ${
                          isSelected
                            ? "bg-primary border-primary text-primary-foreground"
                            : "border-input"
                        }`}
                      >
                        {isSelected && <Check className="h-3 w-3" />}
                      </div>
                      <div className="flex flex-col flex-1 min-w-0">
                        <span className="text-sm font-medium truncate">{user.name}</span>
                        <span className="text-xs text-slate-500 truncate">{user.email}</span>
                      </div>
                    </div>
                  )
                })}
              </div>
            )}
          </SelectGroup>
        </SelectContent>
      </Select>
    </div>
  )
}

