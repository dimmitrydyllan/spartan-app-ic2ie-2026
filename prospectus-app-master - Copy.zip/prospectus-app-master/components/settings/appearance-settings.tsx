"use client"

import { useState, useTransition, useEffect } from "react"
import { Loader2, Save, Palette, Moon, Sun, Monitor } from "lucide-react"
import { toast } from "sonner"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { saveAppearanceSettings, getAppearanceSettings } from "@/app/settings/actions"
import { useTheme } from "@/components/theme-provider"

export function AppearanceSettings() {
  const [isPending, startTransition] = useTransition()
  const router = useRouter()
  const { theme: currentTheme, setTheme: setCurrentTheme } = useTheme()
  const [settings, setSettings] = useState({
    theme: currentTheme,
    fontSize: "medium",
    compactMode: false,
  })

  useEffect(() => {
    // Load settings from database only on mount
    let mounted = true
    getAppearanceSettings().then((data) => {
      if (mounted && data) {
        const themeValue = (data.theme as "light" | "dark" | "system") || "system"
        setSettings({
          theme: themeValue,
          fontSize: data.fontSize || "medium",
          compactMode: data.compactMode || false,
        })
        setCurrentTheme(themeValue)
        // Apply font size and compact mode immediately
        document.documentElement.setAttribute("data-font-size", data.fontSize || "medium")
        document.documentElement.setAttribute("data-compact", (data.compactMode || false).toString())
      }
    })
    return () => {
      mounted = false
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []) // Only run on mount

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData()
    Object.entries(settings).forEach(([key, value]) => {
      formData.set(key, value.toString())
    })

    startTransition(async () => {
      try {
        const result = await saveAppearanceSettings(formData)
        if (result && result.success) {
          setCurrentTheme(settings.theme as "light" | "dark" | "system")
          // Apply font size and compact mode
          document.documentElement.setAttribute("data-font-size", settings.fontSize)
          document.documentElement.setAttribute("data-compact", settings.compactMode.toString())
          toast.success("Pengaturan tampilan berhasil disimpan")
          router.refresh()
        } else {
          toast.error(result?.error || "Gagal menyimpan pengaturan")
        }
      } catch (error: any) {
        if (error?.digest?.startsWith("NEXT_REDIRECT") || error?.message?.includes("NEXT_REDIRECT")) {
          return
        }
        console.error("Error saving appearance settings:", error)
        toast.error("Gagal menyimpan pengaturan")
      }
    })
  }

  const handleThemeChange = (value: string) => {
    const newTheme = value as "light" | "dark" | "system"
    const updated = { ...settings, theme: newTheme }

    // Update state for immediate UI feedback
    setSettings(updated)
    // Apply theme immediately to ThemeProvider
    setCurrentTheme(newTheme)

    // Auto-save theme immediately (outside render phase)
    startTransition(async () => {
      try {
        const formData = new FormData()
        formData.set("theme", newTheme)
        formData.set("fontSize", updated.fontSize)
        formData.set("compactMode", updated.compactMode.toString())

        const result = await saveAppearanceSettings(formData)
        if (result && result.success) {
          // Theme already applied via setCurrentTheme above
          // No need to show toast for auto-save
        } else {
          console.error("Failed to auto-save theme:", result?.error)
        }
      } catch (error: any) {
        console.error("Error auto-saving theme:", error)
      }
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Palette className="h-5 w-5" />
          Pengaturan Tampilan
        </CardTitle>
        <CardDescription>
          Sesuaikan tampilan aplikasi sesuai preferensi Anda
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="theme" className="flex items-center gap-2">
              Tema
            </Label>
            <Select
              value={settings.theme}
              onValueChange={handleThemeChange}
              disabled={isPending}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="light">
                  <div className="flex items-center gap-2">
                    <Sun className="h-4 w-4" />
                    Terang
                  </div>
                </SelectItem>
                <SelectItem value="dark">
                  <div className="flex items-center gap-2">
                    <Moon className="h-4 w-4" />
                    Gelap
                  </div>
                </SelectItem>
                <SelectItem value="system">
                  <div className="flex items-center gap-2">
                    <Monitor className="h-4 w-4" />
                    Mengikuti Sistem
                  </div>
                </SelectItem>
              </SelectContent>
            </Select>
            <p className="text-xs text-slate-500">
              Pilih tema tampilan aplikasi
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="fontSize">Ukuran Font</Label>
            <Select
              value={settings.fontSize}
              onValueChange={(value) => setSettings({ ...settings, fontSize: value })}
              disabled={isPending}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="small">Kecil</SelectItem>
                <SelectItem value="medium">Sedang</SelectItem>
                <SelectItem value="large">Besar</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label>Mode Kompak</Label>
              <p className="text-sm text-slate-500">
                Tampilkan lebih banyak konten dalam satu layar
              </p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={settings.compactMode}
                onChange={(e) =>
                  setSettings({ ...settings, compactMode: e.target.checked })
                }
                className="sr-only peer"
                disabled={isPending}
              />
              <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-slate-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
            </label>
          </div>

          <div className="flex justify-end">
            <Button type="submit" disabled={isPending}>
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Menyimpan...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Simpan Pengaturan
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

