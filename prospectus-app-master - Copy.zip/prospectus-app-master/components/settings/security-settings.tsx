"use client"

import { useState, useTransition } from "react"
import { Loader2, Save, Shield, Lock, Key } from "lucide-react"
import { toast } from "sonner"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { changePassword } from "@/app/settings/actions"
import { SessionManager } from "@/components/settings/session-manager"
import { PasswordInput } from "@/components/password-input"

export function SecuritySettings() {
  const [isPending, startTransition] = useTransition()
  const router = useRouter()
  const [passwordForm, setPasswordForm] = useState({
    currentPassword: "",
    newPassword: "",
    confirmPassword: "",
  })

  const handlePasswordChange = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData()
    formData.set("currentPassword", passwordForm.currentPassword)
    formData.set("newPassword", passwordForm.newPassword)
    formData.set("confirmPassword", passwordForm.confirmPassword)

    startTransition(async () => {
      try {
        const result = await changePassword(formData)
        if (result.success) {
          toast.success("Password berhasil diubah")
          setPasswordForm({
            currentPassword: "",
            newPassword: "",
            confirmPassword: "",
          })
          router.refresh()
        } else {
          toast.error(result.error || "Gagal mengubah password")
        }
      } catch (error) {
        toast.error("Gagal mengubah password")
      }
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5" />
          Pengaturan Keamanan
        </CardTitle>
        <CardDescription>
          Kelola keamanan akun dan kata sandi Anda
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <form onSubmit={handlePasswordChange} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="currentPassword" className="flex items-center gap-2">
              <Lock className="h-4 w-4" />
              Password Saat Ini
            </Label>
            <PasswordInput
              id="currentPassword"
              value={passwordForm.currentPassword}
              onChange={(e) =>
                setPasswordForm({ ...passwordForm, currentPassword: e.target.value })
              }
              placeholder="Masukkan password saat ini"
              required
              disabled={isPending}
            />
          </div>

          <Separator />

          <div className="space-y-2">
            <Label htmlFor="newPassword" className="flex items-center gap-2">
              <Key className="h-4 w-4" />
              Password Baru
            </Label>
            <PasswordInput
              id="newPassword"
              value={passwordForm.newPassword}
              onChange={(e) =>
                setPasswordForm({ ...passwordForm, newPassword: e.target.value })
              }
              placeholder="Masukkan password baru (min. 6 karakter)"
              required
              disabled={isPending}
            />
            <p className="text-xs text-slate-500">
              Password minimal 6 karakter
            </p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="confirmPassword">Konfirmasi Password Baru</Label>
            <PasswordInput
              id="confirmPassword"
              value={passwordForm.confirmPassword}
              onChange={(e) =>
                setPasswordForm({ ...passwordForm, confirmPassword: e.target.value })
              }
              placeholder="Konfirmasi password baru"
              required
              disabled={isPending}
            />
          </div>

          <div className="flex justify-end">
            <Button type="submit" disabled={isPending}>
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Mengubah...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Ubah Password
                </>
              )}
            </Button>
          </div>
        </form>

        <Separator />

        <SessionManager />
      </CardContent>
    </Card>
  )
}

