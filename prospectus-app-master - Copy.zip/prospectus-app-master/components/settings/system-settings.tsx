"use client"

import { useState, useTransition } from "react"
import { Loader2, Save, Database, Trash2, Download, RefreshCw } from "lucide-react"
import { toast } from "sonner"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { clearCache, exportData } from "@/app/settings/actions"

export function SystemSettings() {
  const [isPending, startTransition] = useTransition()
  const router = useRouter()

  const handleClearCache = () => {
    startTransition(async () => {
      try {
        const result = await clearCache()
        if (result.success) {
          toast.success("Cache berhasil dibersihkan")
          router.refresh()
        }
      } catch (error) {
        toast.error("Gagal membersihkan cache")
      }
    })
  }

  const handleExportData = () => {
    startTransition(async () => {
      try {
        const result = await exportData()
        if (result.success) {
          toast.success("Data berhasil diekspor")
        }
      } catch (error) {
        toast.error("Gagal mengekspor data")
      }
    })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          Pengaturan Sistem
        </CardTitle>
        <CardDescription>
          Kelola pengaturan sistem dan data aplikasi
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-4">
          <div>
            <h3 className="text-sm font-semibold mb-2">Cache & Performa</h3>
            <p className="text-sm text-slate-600 mb-4">
              Bersihkan cache untuk meningkatkan performa aplikasi
            </p>
            <Button
              variant="outline"
              onClick={handleClearCache}
              disabled={isPending}
              className="gap-2"
            >
              <RefreshCw className="h-4 w-4" />
              Bersihkan Cache
            </Button>
          </div>

          <Separator />

          <div>
            <h3 className="text-sm font-semibold mb-2">Ekspor Data</h3>
            <p className="text-sm text-slate-600 mb-4">
              Unduh data aplikasi dalam format JSON
            </p>
            <Button
              variant="outline"
              onClick={handleExportData}
              disabled={isPending}
              className="gap-2"
            >
              <Download className="h-4 w-4" />
              Ekspor Data
            </Button>
          </div>

          <Separator />

          <div>
            <h3 className="text-sm font-semibold mb-2 text-red-600">
              Zona Berbahaya
            </h3>
            <p className="text-sm text-slate-600 mb-4">
              Tindakan ini tidak dapat dibatalkan. Hati-hati!
            </p>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="destructive" className="gap-2">
                  <Trash2 className="h-4 w-4" />
                  Reset Semua Data
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Apakah Anda yakin?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Tindakan ini akan menghapus semua data aplikasi dan tidak dapat
                    dibatalkan. Pastikan Anda sudah melakukan backup data sebelum
                    melanjutkan.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Batal</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => toast.error("Fitur belum diimplementasi")}
                    className="bg-red-600 hover:bg-red-700"
                  >
                    Ya, Hapus Semua
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

