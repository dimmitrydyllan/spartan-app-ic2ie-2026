"use client"

import { useState, useTransition } from "react"
import { Loader2, Save, Bell, Mail, MessageSquare } from "lucide-react"
import { toast } from "sonner"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Separator } from "@/components/ui/separator"
import { saveNotificationSettings } from "@/app/settings/actions"

export function NotificationSettings() {
  const [isPending, startTransition] = useTransition()
  const router = useRouter()
  const [settings, setSettings] = useState({
    emailNotifications: true,
    pushNotifications: false,
    activityReminders: true,
    prospectusUpdates: true,
    attendanceReminders: true,
    systemAlerts: true,
  })

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData()
    Object.entries(settings).forEach(([key, value]) => {
      formData.set(key, value.toString())
    })

    startTransition(async () => {
      try {
        const result = await saveNotificationSettings(formData)
        if (result && result.success) {
          toast.success("Pengaturan notifikasi berhasil disimpan")
          router.refresh()
        } else {
          toast.error(result?.error || "Gagal menyimpan pengaturan")
        }
      } catch (error: any) {
        if (error?.digest?.startsWith("NEXT_REDIRECT") || error?.message?.includes("NEXT_REDIRECT")) {
          return
        }
        console.error("Error saving notification settings:", error)
        toast.error("Gagal menyimpan pengaturan")
      }
    })
  }

  const toggleSetting = (key: keyof typeof settings) => {
    setSettings({ ...settings, [key]: !settings[key] })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Bell className="h-5 w-5" />
          Pengaturan Notifikasi
        </CardTitle>
        <CardDescription>
          Kelola preferensi notifikasi dan pengingat
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="emailNotifications" className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  Notifikasi Email
                </Label>
                <p className="text-sm text-slate-500">
                  Terima notifikasi melalui email
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.emailNotifications}
                  onChange={() => toggleSetting("emailNotifications")}
                  className="sr-only peer"
                  disabled={isPending}
                />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-slate-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
              </label>
            </div>

            <Separator />

            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="pushNotifications" className="flex items-center gap-2">
                  <MessageSquare className="h-4 w-4" />
                  Notifikasi Push
                </Label>
                <p className="text-sm text-slate-500">
                  Terima notifikasi push di browser
                </p>
              </div>
              <label className="relative inline-flex items-center cursor-pointer">
                <input
                  type="checkbox"
                  checked={settings.pushNotifications}
                  onChange={() => toggleSetting("pushNotifications")}
                  className="sr-only peer"
                  disabled={isPending}
                />
                <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-slate-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
              </label>
            </div>

            <Separator />

            <div className="space-y-3">
              <Label className="text-base font-semibold">Jenis Notifikasi</Label>

              <div className="space-y-3 pl-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label>Pengingat Aktivitas</Label>
                    <p className="text-sm text-slate-500">
                      Notifikasi untuk aktivitas prospectus
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.activityReminders}
                      onChange={() => toggleSetting("activityReminders")}
                      className="sr-only peer"
                      disabled={isPending}
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-slate-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Update Prospectus</Label>
                    <p className="text-sm text-slate-500">
                      Notifikasi saat ada update prospectus
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.prospectusUpdates}
                      onChange={() => toggleSetting("prospectusUpdates")}
                      className="sr-only peer"
                      disabled={isPending}
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-slate-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Pengingat Absensi</Label>
                    <p className="text-sm text-slate-500">
                      Notifikasi untuk absensi masuk/keluar
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.attendanceReminders}
                      onChange={() => toggleSetting("attendanceReminders")}
                      className="sr-only peer"
                      disabled={isPending}
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-slate-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                  </label>
                </div>

                <div className="flex items-center justify-between">
                  <div>
                    <Label>Alert Sistem</Label>
                    <p className="text-sm text-slate-500">
                      Notifikasi penting dari sistem
                    </p>
                  </div>
                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={settings.systemAlerts}
                      onChange={() => toggleSetting("systemAlerts")}
                      className="sr-only peer"
                      disabled={isPending}
                    />
                    <div className="w-11 h-6 bg-slate-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-slate-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
                  </label>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end">
            <Button type="submit" disabled={isPending}>
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Menyimpan...
                </>
              ) : (
                <>
                  <Save className="mr-2 h-4 w-4" />
                  Simpan Pengaturan
                </>
              )}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}

