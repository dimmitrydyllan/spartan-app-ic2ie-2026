"use client"

import { useState, useEffect } from "react"
import { LogOut, Monitor, Smartphone, Globe } from "lucide-react"
import { toast } from "sonner"
import { useRouter } from "next/navigation"

import { Button } from "@/components/ui/button"
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { logoutAllSessions } from "@/app/settings/session-actions"

type Session = {
  id: string
  device: string
  location: string
  lastActive: string
  current: boolean
}

export function SessionManager() {
  const router = useRouter()
  const [sessions, setSessions] = useState<Session[]>([])
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Simulate fetching sessions
    // In real app, this would fetch from API
    const mockSessions: Session[] = [
      {
        id: "1",
        device: "Windows - Chrome",
        location: "Jakarta, Indonesia",
        lastActive: new Date().toISOString(),
        current: true,
      },
    ]
    setSessions(mockSessions)
    setIsLoading(false)
  }, [])

  const handleLogoutAll = async () => {
    try {
      const result = await logoutAllSessions()
      if (result.success) {
        toast.success("Semua sesi telah diakhiri")
        router.push("/login")
      } else {
        toast.error(result.error || "Gagal mengakhiri sesi")
      }
    } catch (error) {
      toast.error("Gagal mengakhiri sesi")
    }
  }

  const handleLogoutSession = async (sessionId: string) => {
    if (sessionId === "1") {
      // Current session
      await handleLogoutAll()
    } else {
      toast.success("Sesi telah diakhiri")
      setSessions(sessions.filter((s) => s.id !== sessionId))
    }
  }

  const getDeviceIcon = (device: string) => {
    if (device.toLowerCase().includes("mobile") || device.toLowerCase().includes("android") || device.toLowerCase().includes("ios")) {
      return <Smartphone className="h-4 w-4" />
    }
    if (device.toLowerCase().includes("tablet")) {
      return <Monitor className="h-4 w-4" />
    }
    return <Monitor className="h-4 w-4" />
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diff = now.getTime() - date.getTime()
    const minutes = Math.floor(diff / 60000)
    const hours = Math.floor(diff / 3600000)
    const days = Math.floor(diff / 86400000)

    if (minutes < 1) return "Baru saja"
    if (minutes < 60) return `${minutes} menit yang lalu`
    if (hours < 24) return `${hours} jam yang lalu`
    return `${days} hari yang lalu`
  }

  if (isLoading) {
    return <div className="text-sm text-slate-500">Memuat sesi...</div>
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3 rounded-lg bg-muted/50 px-3 py-2">
        <div>
          <h3 className="text-sm font-semibold">Sesi Aktif</h3>
          <p className="text-sm text-muted-foreground">
            Kelola sesi yang sedang aktif di perangkat Anda
          </p>
        </div>
        {sessions.length > 1 && (
          <Button variant="outline" size="sm" onClick={handleLogoutAll}>
            <LogOut className="mr-2 h-4 w-4" />
            Akhiri Semua Sesi
          </Button>
        )}
      </div>

      <div className="space-y-3">
        {sessions.map((session) => (
          <Card key={session.id} className={session.current ? "border-primary" : ""}>
            <CardContent className="pt-4">
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3 flex-1">
                  <div className="mt-1">
                    {getDeviceIcon(session.device)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm font-medium">{session.device}</p>
                      {session.current && (
                        <Badge variant="outline" className="text-xs">
                          Sesi Saat Ini
                        </Badge>
                      )}
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-500">
                      <Globe className="h-3 w-3" />
                      <span>{session.location}</span>
                    </div>
                    <p className="text-xs text-slate-500 mt-1">
                      Aktif {formatDate(session.lastActive)}
                    </p>
                  </div>
                </div>
                {!session.current && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleLogoutSession(session.id)}
                    className="text-red-600 hover:text-red-700 hover:bg-red-50"
                  >
                    <LogOut className="h-4 w-4" />
                  </Button>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {sessions.length === 0 && (
        <p className="text-sm text-slate-500 text-center py-4">
          Tidak ada sesi aktif
        </p>
      )}
    </div>
  )
}

