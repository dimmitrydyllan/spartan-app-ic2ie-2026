"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { PasswordInput } from "@/components/password-input"

type Props = {
  action: (formData: FormData) => Promise<void>
}

export function RegisterForm({ action }: Props) {
  const [isPending, startTransition] = useTransition()
  const router = useRouter()
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [passwordError, setPasswordError] = useState("")

  const handlePasswordChange = (value: string) => {
    setPassword(value)
    if (confirmPassword && value !== confirmPassword) {
      setPasswordError("Password tidak cocok")
    } else {
      setPasswordError("")
    }
  }

  const handleConfirmPasswordChange = (value: string) => {
    setConfirmPassword(value)
    if (password && value !== password) {
      setPasswordError("Password tidak cocok")
    } else {
      setPasswordError("")
    }
  }

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()

    if (password !== confirmPassword) {
      setPasswordError("Password tidak cocok")
      toast.error("Password tidak cocok")
      return
    }

    if (password.length < 6) {
      setPasswordError("Password minimal 6 karakter")
      toast.error("Password minimal 6 karakter")
      return
    }

    const formData = new FormData(e.currentTarget)

    startTransition(async () => {
      try {
        await action(formData)
        // Redirect will happen from server action
      } catch (error: any) {
        // Handle redirect error from server action
        if (error?.digest?.startsWith("NEXT_REDIRECT")) {
          return
        }
        const errorMessage = error?.message || "Gagal mendaftar. Silakan coba lagi."
        toast.error(errorMessage)
      }
    })
  }

  return (
    <form className="space-y-6" onSubmit={handleSubmit}>
      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700" htmlFor="name">
          Nama lengkap
        </label>
        <Input
          id="name"
          name="name"
          placeholder="Nama Anda"
          required
          disabled={isPending}
        />
      </div>
      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700" htmlFor="email">
          Email kerja
        </label>
        <Input
          id="email"
          name="email"
          type="email"
          placeholder="nama@perusahaan.com"
          required
          disabled={isPending}
        />
      </div>
      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700" htmlFor="password">
          Kata sandi
        </label>
        <PasswordInput
          id="password"
          name="password"
          placeholder="Minimal 6 karakter"
          required
          disabled={isPending}
          value={password}
          onChange={(e) => handlePasswordChange(e.target.value)}
        />
        <p className="text-xs text-slate-500">Password minimal 6 karakter</p>
      </div>
      <div className="space-y-2">
        <label
          className="text-sm font-medium text-slate-700"
          htmlFor="confirmPassword"
        >
          Konfirmasi Kata sandi
        </label>
        <PasswordInput
          id="confirmPassword"
          name="confirmPassword"
          placeholder="Ulangi kata sandi"
          required
          disabled={isPending}
          value={confirmPassword}
          onChange={(e) => handleConfirmPasswordChange(e.target.value)}
        />
        {passwordError && (
          <p className="text-xs text-red-600">{passwordError}</p>
        )}
      </div>
      <Button type="submit" className="w-full" disabled={isPending || !!passwordError}>
        {isPending ? "Memproses..." : "Daftar"}
      </Button>
      <p className="text-sm text-slate-600">
        Sudah punya akun?{" "}
        <Link href="/login" className="text-primary hover:underline">
          Masuk di sini
        </Link>
      </p>
    </form>
  )
}

