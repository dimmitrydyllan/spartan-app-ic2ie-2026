"use client"

import { useTransition } from "react"
import { useRouter } from "next/navigation"
import Link from "next/link"
import { toast } from "sonner"

import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { PasswordInput } from "@/components/password-input"

type Props = {
  action: (formData: FormData) => Promise<void>
}

export function LoginForm({ action }: Props) {
  const [isPending, startTransition] = useTransition()
  const router = useRouter()

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    const formData = new FormData(e.currentTarget)

    startTransition(async () => {
      try {
        await action(formData)
        // Redirect will happen from server action
      } catch (error: any) {
        // Handle redirect error from server action
        if (error?.digest?.startsWith("NEXT_REDIRECT")) {
          return
        }
        const errorMessage = error?.message || "Email atau password salah"
        toast.error(errorMessage)
      }
    })
  }

  return (
    <form className="space-y-6" onSubmit={handleSubmit}>
      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700" htmlFor="email">
          Email
        </label>
        <Input
          id="email"
          name="email"
          type="email"
          placeholder="nama@perusahaan.com"
          required
          disabled={isPending}
        />
      </div>
      <div className="space-y-2">
        <label className="text-sm font-medium text-slate-700" htmlFor="password">
          Kata sandi
        </label>
        <PasswordInput
          id="password"
          name="password"
          placeholder="••••••••"
          required
          disabled={isPending}
        />
      </div>
      <Button type="submit" className="w-full" disabled={isPending}>
        {isPending ? "Memproses..." : "Masuk"}
      </Button>
      <p className="text-sm text-slate-600">
        Belum punya akun?{" "}
        <Link href="/register" className="text-primary hover:underline">
          Daftar di sini
        </Link>
      </p>
    </form>
  )
}

