import Image from "next/image";
import Link from "next/link";
import { redirect } from "next/navigation";
import {
  CalendarClock,
  Home,
  LogOut,
  Menu,
  Settings,
  ShieldCheck,
  User,
  UserRoundCheck,
  Zap,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarInset,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarProvider,
  SidebarRail,
  SidebarTrigger,
} from "@/components/ui/sidebar";
import { getSession } from "@/lib/auth";
import { getMenusForUser, type MenuNode } from "@/lib/menu";
import { prisma } from "@/lib/prisma";

function resolveIcon(name?: string | null) {
  const map: Record<string, React.ComponentType<{ className?: string }>> = {
    home: Home,
    calendar: CalendarClock,
    clock: CalendarClock,
    log: LogOut,
    menu: Menu,
    settings: Settings,
    shield: ShieldCheck,
    usercheck: UserRoundCheck,
    user: UserRoundCheck,
    zap: Zap,
  };
  const key = (name ?? "").toLowerCase();
  return map[key] ?? Home;
}

function renderMenu(nodes: MenuNode[]) {
  return nodes.map((item) => {
    const Icon = resolveIcon(item.icon);
    return (
      <SidebarMenuItem key={item.id}>
        <SidebarMenuButton asChild>
          <Link href={item.path}>
            <Icon className="h-4 w-4" />
            <span>{item.name}</span>
          </Link>
        </SidebarMenuButton>
        {item.children.length > 0 && (
          <div className="ml-4 border-l border-border pl-3">
            {renderMenu(item.children)}
          </div>
        )}
      </SidebarMenuItem>
    );
  });
}

export async function DashboardLayout({
  children,
  title,
}: {
  children: React.ReactNode;
  title?: string;
}) {
  const session = await getSession();

  if (!session) {
    redirect("/login");
  }

  const [menus, user] = await Promise.all([
    getMenusForUser(session.userId ?? ""),
    session.userId
      ? prisma.user.findUnique({
          where: { id: session.userId },
          select: { photoUrl: true },
        })
      : null,
  ]);

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-background text-foreground">
        <Sidebar className="border-r border-border">
          <SidebarHeader className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-semibold py-2">
              <Image
                src="/logo/spartan-removebg.png"
                alt="Spartan"
                width={28}
                height={28}
                className="h-7 w-7"
                priority
              />
              <span>Spartan</span>
            </div>
          </SidebarHeader>

          <SidebarContent>
            <SidebarGroup>
              <SidebarGroupLabel>Menu</SidebarGroupLabel>
              <SidebarGroupContent>
                <SidebarMenu>
                  {menus.length ? (
                    renderMenu(menus)
                  ) : (
                    <SidebarMenuItem>
                      <SidebarMenuButton aria-disabled>
                        <span>Belum ada menu untuk role Anda</span>
                      </SidebarMenuButton>
                    </SidebarMenuItem>
                  )}
                </SidebarMenu>
              </SidebarGroupContent>
            </SidebarGroup>
          </SidebarContent>

          <SidebarFooter className="border-t border-border">
            <form action="/logout" method="post" className="w-full">
              <Button
                type="submit"
                variant="ghost"
                className="w-full justify-start gap-2 text-red-600 hover:text-red-700 dark:text-red-400 dark:hover:text-red-300"
              >
                <LogOut className="h-4 w-4" />
                Keluar
              </Button>
            </form>
          </SidebarFooter>

          <SidebarRail />
        </Sidebar>

        <SidebarInset>
          <header className="flex h-14 items-center justify-between border-b border-border bg-card px-4 sm:px-6 shadow-sm lg:px-8">
            <div className="flex items-center gap-2 sm:gap-3 min-w-0 flex-1">
              <SidebarTrigger
                className="hover:bg-accent hover:text-accent-foreground shrink-0"
                aria-label="Toggle sidebar"
              >
                <Menu className="h-4 w-4" />
              </SidebarTrigger>
              <div className="h-6 sm:h-8 w-px bg-border mx-1 sm:mx-2 shrink-0" />
              <div className="min-w-0 flex-1">
                <p className="text-xs text-muted-foreground hidden sm:block">
                  Spartan Dashboard
                </p>
                <h1 className="text-base sm:text-lg font-semibold truncate">
                  {title || `Halo, ${session?.name ?? "User"}`}
                </h1>
              </div>
            </div>
            <Link
              href="/profile"
              className="shrink-0 hidden sm:flex items-center justify-center h-8 w-8 rounded-full border border-border bg-card hover:bg-accent transition-colors overflow-hidden"
              title={session?.name || "Profile"}
            >
              {user?.photoUrl ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={user.photoUrl}
                  alt={session?.name || "User"}
                  className="h-full w-full object-cover"
                />
              ) : (
                <User className="h-4 w-4 text-muted-foreground" />
              )}
            </Link>
          </header>

          <main className="flex-1 space-y-4 sm:space-y-6 bg-background p-4 sm:p-6 w-full lg:p-8">
            {children}
          </main>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}

