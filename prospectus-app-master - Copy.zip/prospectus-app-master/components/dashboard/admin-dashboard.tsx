import Link from "next/link";
import {
  Activity,
  Calendar,
  CheckCircle2,
  Clock,
  FileText,
  LogIn,
  LogOut,
  TrendingUp,
  Users,
  BarChart3,
} from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { DashboardLayout } from "@/components/dashboard-layout";
import { prisma } from "@/lib/prisma";

function formatDate(value: Date) {
  try {
    return new Intl.DateTimeFormat("id-ID", {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(value);
  } catch {
    return value.toISOString();
  }
}

export async function AdminDashboard({ userId }: { userId: string }) {
  const now = new Date();
  const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
  const startOfWeek = new Date(now);
  startOfWeek.setDate(now.getDate() - now.getDay());
  startOfWeek.setHours(0, 0, 0, 0);
  const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

  // Fetch statistics for admin (all users data)
  const [
    totalUsers,
    totalActivities,
    activitiesByStatus,
    todayActivities,
    weekActivities,
    monthActivities,
    totalAttendances,
    todayAttendances,
    todayCheckIn,
    todayCheckOut,
    recentActivities,
    recentAttendances,
    salesUsers,
  ] = await Promise.all([
    // Users
    prisma.user.count(),
    // Prospectus Activities (all users)
    prisma.prospectusActivity.count(),
    prisma.prospectusActivity.groupBy({
      by: ["status"],
      _count: true,
    }),
    prisma.prospectusActivity.count({
      where: {
        activityDate: { gte: startOfToday },
      },
    }),
    prisma.prospectusActivity.count({
      where: {
        activityDate: { gte: startOfWeek },
      },
    }),
    prisma.prospectusActivity.count({
      where: {
        activityDate: { gte: startOfMonth },
      },
    }),
    // Attendances (all users)
    prisma.attendance.count(),
    prisma.attendance.count({
      where: {
        timestamp: { gte: startOfToday },
      },
    }),
    prisma.attendance.count({
      where: {
        type: "IN",
        timestamp: { gte: startOfToday },
      },
    }),
    prisma.attendance.count({
      where: {
        type: "OUT",
        timestamp: { gte: startOfToday },
      },
    }),
    // Recent data (all users)
    prisma.prospectusActivity.findMany({
      orderBy: { activityDate: "desc" },
      take: 5,
      include: {
        user: { select: { name: true } },
      },
    }),
    prisma.attendance.findMany({
      orderBy: { timestamp: "desc" },
      take: 5,
      include: {
        user: { select: { name: true } },
      },
    }),
    // Sales users count
    prisma.userRole.findMany({
      where: {
        role: {
          code: { equals: "SALES", mode: "insensitive" },
        },
      },
      select: { userId: true },
      distinct: ["userId"],
    }),
  ]);

  const statusCounts = {
    PROSPECT: 0,
    FOLLOW_UP: 0,
    PROJECTION: 0,
    REJECTED: 0,
    CANCELED: 0,
  };

  activitiesByStatus.forEach((item) => {
    statusCounts[item.status as keyof typeof statusCounts] = item._count;
  });

  const STATUS_LABEL: Record<string, string> = {
    PROSPECT: "Prospect",
    FOLLOW_UP: "Follow Up",
    PROJECTION: "Projection",
    REJECTED: "Rejected",
    CANCELED: "Canceled",
  };

  const STATUS_BADGE: Record<string, string> = {
    PROSPECT: "border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-800 dark:bg-blue-950 dark:text-blue-300",
    FOLLOW_UP: "border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-800 dark:bg-amber-950 dark:text-amber-300",
    PROJECTION: "border-green-200 bg-green-50 text-green-700 dark:border-green-800 dark:bg-green-950 dark:text-green-300",
    REJECTED: "border-red-200 bg-red-50 text-red-700 dark:border-red-800 dark:bg-red-950 dark:text-red-300",
    CANCELED: "border-border bg-muted text-muted-foreground",
  };

  const completionRate =
    totalActivities > 0
      ? Math.round((statusCounts.PROJECTION / totalActivities) * 100)
      : 0;

  return (
    <DashboardLayout title="Dashboard Admin">
      <div className="mx-auto max-w-7xl space-y-6">
        {/* Welcome Section */}
        <div className="rounded-xl border border-border bg-gradient-to-r from-indigo-50 to-purple-50 dark:from-indigo-950 dark:to-purple-950 p-6">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-foreground">Dashboard Administrator</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Overview lengkap sistem - Monitor semua aktivitas dan performa tim
              </p>
            </div>
            <BarChart3 className="h-12 w-12 text-indigo-600 dark:text-indigo-400 opacity-50" />
          </div>
        </div>

        {/* Statistik Cards - System Wide */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <Card className="border-indigo-200 bg-indigo-50/50 dark:border-indigo-800 dark:bg-indigo-950/50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Pengguna</CardTitle>
              <Users className="h-4 w-4 text-indigo-600 dark:text-indigo-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-indigo-900 dark:text-indigo-300">{totalUsers}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {salesUsers.length} sales aktif
              </p>
            </CardContent>
          </Card>

          <Card className="border-blue-200 bg-blue-50/50 dark:border-blue-800 dark:bg-blue-950/50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Aktivitas</CardTitle>
              <Activity className="h-4 w-4 text-blue-600 dark:text-blue-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-blue-900 dark:text-blue-300">{totalActivities}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {monthActivities} aktivitas bulan ini
              </p>
            </CardContent>
          </Card>

          <Card className="border-green-200 bg-green-50/50 dark:border-green-800 dark:bg-green-950/50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tingkat Penyelesaian</CardTitle>
              <CheckCircle2 className="h-4 w-4 text-green-600 dark:text-green-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-green-900 dark:text-green-300">{completionRate}%</div>
              <p className="text-xs text-muted-foreground mt-1">
                {statusCounts.PROJECTION} aktivitas projection
              </p>
            </CardContent>
          </Card>

          <Card className="border-amber-200 bg-amber-50/50 dark:border-amber-800 dark:bg-amber-950/50">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Absensi</CardTitle>
              <Clock className="h-4 w-4 text-amber-600 dark:text-amber-400" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-amber-900 dark:text-amber-300">{totalAttendances}</div>
              <p className="text-xs text-muted-foreground mt-1">
                {todayAttendances} absensi hari ini
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Statistik Detail */}
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {/* Status Prospectus */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Status Prospectus (Semua)</CardTitle>
              <CardDescription>Distribusi aktivitas berdasarkan status</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              {Object.entries(statusCounts).map(([status, count]) => (
                <div key={status} className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Badge
                      variant="outline"
                      className={STATUS_BADGE[status] || "border-border text-muted-foreground"}
                    >
                      {STATUS_LABEL[status] || status}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-semibold">{count}</span>
                    {totalActivities > 0 && (
                      <span className="text-xs text-muted-foreground">
                        ({Math.round((count / totalActivities) * 100)}%)
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Absensi Hari Ini */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Absensi Hari Ini (Semua)</CardTitle>
              <CardDescription>Rincian absensi masuk dan keluar</CardDescription>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <LogIn className="h-4 w-4 text-green-600" />
                  <span className="text-sm">Masuk</span>
                </div>
                <span className="text-lg font-semibold">{todayCheckIn}</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <LogOut className="h-4 w-4 text-muted-foreground" />
                  <span className="text-sm">Keluar</span>
                </div>
                <span className="text-lg font-semibold">{todayCheckOut}</span>
              </div>
              <div className="pt-2 border-t">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Total</span>
                  <span className="text-lg font-bold">{todayAttendances}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Aksi Cepat</CardTitle>
              <CardDescription>Akses cepat ke fitur utama</CardDescription>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="default" asChild className="w-full justify-start">
                <Link href="/supervisor">
                  <BarChart3 className="mr-2 h-4 w-4" />
                  Supervisor Analytics
                </Link>
              </Button>
              <Button variant="outline" asChild className="w-full justify-start">
                <Link href="/roles">
                  <Users className="mr-2 h-4 w-4" />
                  Kelola Role & User
                </Link>
              </Button>
              <Button variant="outline" asChild className="w-full justify-start">
                <Link href="/menus">
                  <FileText className="mr-2 h-4 w-4" />
                  Kelola Menu
                </Link>
              </Button>
              <Button variant="outline" asChild className="w-full justify-start">
                <Link href="/settings">
                  <TrendingUp className="mr-2 h-4 w-4" />
                  Pengaturan
                </Link>
              </Button>
            </CardContent>
          </Card>
        </div>

        {/* Aktivitas Terbaru */}
        <div className="grid gap-4 sm:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Aktivitas Prospectus Terbaru (Semua)</CardTitle>
              <CardDescription>5 aktivitas terakhir dari semua user</CardDescription>
            </CardHeader>
            <CardContent>
              {recentActivities.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  Belum ada aktivitas
                </div>
              ) : (
                <div className="space-y-3">
                  {recentActivities.map((activity) => (
                    <div
                      key={activity.id}
                      className="flex items-start justify-between gap-3 p-3 rounded-lg border border-border bg-muted hover:bg-muted/80 transition-colors"
                    >
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium text-sm truncate">{activity.title}</h4>
                          <Badge
                            variant="outline"
                            className={
                              STATUS_BADGE[activity.status] ||
                              "border-border text-muted-foreground"
                            }
                          >
                            {STATUS_LABEL[activity.status] || activity.status}
                          </Badge>
                        </div>
                        <div className="flex items-center gap-2">
                          <p className="text-xs text-muted-foreground">
                            {formatDate(activity.activityDate)}
                          </p>
                          <span className="text-xs text-muted-foreground">•</span>
                          <p className="text-xs text-muted-foreground">{activity.user.name}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              <div className="mt-4">
                <Button variant="outline" asChild className="w-full">
                  <Link href="/supervisor">Lihat Analytics Lengkap</Link>
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Absensi Terbaru (Semua)</CardTitle>
              <CardDescription>5 absensi terakhir dari semua user</CardDescription>
            </CardHeader>
            <CardContent>
              {recentAttendances.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground text-sm">
                  Belum ada absensi
                </div>
              ) : (
                <div className="space-y-3">
                  {recentAttendances.map((attendance) => (
                    <div
                      key={attendance.id}
                      className="flex items-center justify-between gap-3 p-3 rounded-lg border border-border bg-muted hover:bg-muted/80 transition-colors"
                    >
                      <div className="flex items-center gap-3 flex-1">
                        {attendance.type === "IN" ? (
                          <LogIn className="h-4 w-4 text-green-600 dark:text-green-400" />
                        ) : (
                          <LogOut className="h-4 w-4 text-muted-foreground" />
                        )}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-sm">
                              {attendance.type === "IN" ? "Masuk" : "Keluar"}
                            </span>
                            <Badge
                              variant="outline"
                              className={
                                attendance.type === "IN"
                                  ? "border-green-200 bg-green-50 text-green-700 dark:border-green-800 dark:bg-green-950 dark:text-green-300"
                                  : "border-border bg-muted text-muted-foreground"
                              }
                            >
                              {attendance.type}
                            </Badge>
                          </div>
                          <div className="flex items-center gap-2 mt-1">
                            <p className="text-xs text-muted-foreground">
                              {formatDate(attendance.timestamp)}
                            </p>
                            <span className="text-xs text-muted-foreground">•</span>
                            <p className="text-xs text-muted-foreground truncate">
                              {attendance.user.name}
                            </p>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
              <div className="mt-4">
                <Button variant="outline" asChild className="w-full">
                  <Link href="/supervisor">Lihat Analytics Lengkap</Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}

