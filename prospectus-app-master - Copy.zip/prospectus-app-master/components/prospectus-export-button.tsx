"use client"

import { useState } from "react"
import { Download, Printer } from "lucide-react"

import { Button } from "@/components/ui/button"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

export function ProspectusExportButton() {
  const [format, setFormat] = useState("excel")

  const handleExport = () => {
    window.location.href = `/api/prospectus/export?format=${format}`
  }

  const handlePrint = () => {
    window.open("/prospectus/print", "_blank")
  }

  return (
    <div className="flex items-center gap-2">
      <Select value={format} onValueChange={setFormat}>
        <SelectTrigger className="w-[140px]">
          <SelectValue placeholder="Format Export" />
        </SelectTrigger>
        <SelectContent>
          <SelectItem value="excel">Excel (.xlsx)</SelectItem>
          <SelectItem value="csv">CSV (.csv)</SelectItem>
        </SelectContent>
      </Select>
      <Button variant="outline" size="sm" onClick={handleExport}>
        <Download className="h-4 w-4 mr-2" />
        Export
      </Button>
      <Button variant="outline" size="sm" onClick={handlePrint}>
        <Printer className="h-4 w-4 mr-2" />
        Print
      </Button>
    </div>
  )
}

