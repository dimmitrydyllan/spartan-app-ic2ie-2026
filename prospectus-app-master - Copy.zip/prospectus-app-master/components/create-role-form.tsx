"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { Plus, Loader2 } from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";

type Props = {
  action: (formData: FormData) => Promise<{ success: boolean; error?: string } | void>;
};

export function CreateRoleForm({ action }: Props) {
  const [open, setOpen] = useState(false);
  const [isPending, startTransition] = useTransition();
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);

    startTransition(async () => {
      try {
        const result = await action(formData);
        if (result && typeof result === "object") {
          if (result.success) {
            toast.success("Role berhasil dibuat");
            setOpen(false);
            e.currentTarget.reset();
            router.refresh();
          } else {
            const errorMsg =
              result.error === "invalid" ? "Data tidak valid" :
              result.error === "duplicate" ? "Role code sudah ada" :
              result.error === "failed" ? "Gagal memproses data" :
              "Terjadi kesalahan";
            toast.error(errorMsg);
          }
        } else {
          router.refresh();
        }
      } catch (error: any) {
        if (error?.digest?.startsWith("NEXT_REDIRECT") || error?.message?.includes("NEXT_REDIRECT")) {
          return;
        }
        console.error("Error creating role:", error);
        toast.error("Gagal memproses data");
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" className="w-full sm:w-auto">
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">Tambah Role</span>
          <span className="sm:hidden">Tambah</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Tambah Role Baru</DialogTitle>
            <DialogDescription>
              Buat role baru untuk sistem. Code role harus unik.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="code">Code Role</Label>
              <Input
                id="code"
                name="code"
                placeholder="ADMIN"
                required
                pattern="[A-Z0-9_]+"
                title="Hanya huruf besar, angka, dan underscore"
                className="uppercase"
                disabled={isPending}
              />
              <p className="text-xs text-slate-500">
                Format: Huruf besar, angka, underscore (contoh: ADMIN, SALES_01)
              </p>
            </div>
            <div className="space-y-2">
              <Label htmlFor="name">Nama Role</Label>
              <Input
                id="name"
                name="name"
                placeholder="Administrator"
                required
                disabled={isPending}
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => setOpen(false)}
              disabled={isPending}
              className="w-full sm:w-auto"
            >
              Batal
            </Button>
            <Button type="submit" disabled={isPending} className="w-full sm:w-auto">
              {isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Memproses...
                </>
              ) : (
                "Simpan"
              )}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

