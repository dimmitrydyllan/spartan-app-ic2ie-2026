import { NextResponse, type NextRequest } from "next/server"

const authRoutes = ["/login", "/register"]
const protectedPrefixes = [
  "/dashboard",
  "/roles",
  "/menus",
  "/role-menus",
  "/absensi",
  "/prospectus",
  "/api/absensi/photo",
  "/api/prospectus/photo",
  "/supervisor",
]
const AUTH_COOKIE = "auth_token"

export function proxy(req: NextRequest) {
  const { pathname } = req.nextUrl

  // Abaikan file statis, API routes, dan Next.js internal files
  // Check for file extensions first (most common case)
  if (pathname.includes(".")) {
    // Allow all files with extensions (images, fonts, CSS, JS, etc.)
    return NextResponse.next()
  }

  // Abaikan Next.js internal files
  if (
    pathname.startsWith("/_next") ||
    pathname.startsWith("/api") ||
    pathname.startsWith("/static") ||
    pathname.startsWith("/public") ||
    pathname === "/favicon.ico" ||
    pathname === "/robots.txt" ||
    pathname === "/sitemap.xml"
  ) {
    return NextResponse.next()
  }

  const isAuthRoute = authRoutes.includes(pathname)
  const isProtected = protectedPrefixes.some((prefix) =>
    pathname.startsWith(prefix)
  )

  const session = req.cookies.get(AUTH_COOKIE)?.value

  // Pastikan redirect menggunakan URL yang benar dari request (bukan localhost atau 0.0.0.0)
  // Gunakan Host header dari request untuk mendapatkan domain yang benar
  const getRedirectUrl = (pathname: string): URL => {
    // Prioritas 1: Gunakan NEXT_PUBLIC_BASE_URL jika tersedia
    if (process.env.NEXT_PUBLIC_BASE_URL) {
      return new URL(pathname, process.env.NEXT_PUBLIC_BASE_URL)
    }

    // Prioritas 2: Gunakan Host header dari request (dari Nginx proxy)
    const host = req.headers.get("host") || req.headers.get("x-forwarded-host")
    const protocol = req.headers.get("x-forwarded-proto") || (req.nextUrl.protocol === "https:" ? "https" : "http")
    
    if (host && !host.includes("0.0.0.0") && !host.includes("localhost")) {
      return new URL(pathname, `${protocol}://${host}`)
    }

    // Prioritas 3: Clone dari req.nextUrl (fallback)
    const url = req.nextUrl.clone()
    url.pathname = pathname
    return url
  }

  // Jika sudah login, blok akses ke login/register.
  if (session && isAuthRoute) {
    return NextResponse.redirect(getRedirectUrl("/dashboard"))
  }

  // Jika belum login dan mengakses halaman terlindungi.
  if (!session && isProtected) {
    return NextResponse.redirect(getRedirectUrl("/login"))
  }

  return NextResponse.next()
}

export const config = {
  matcher: [
    /*
     * Match all request paths except for the ones starting with:
     * - api (API routes)
     * - _next (Next.js internal files)
     * - static (static files)
     * - public (public files)
     * - files with extensions (images, fonts, CSS, JS, etc.)
     */
    "/((?!api|_next|static|public|.*\\..*).*)",
  ],
}

