import { prisma } from "./prisma";

export type Permission = {
  canView: boolean;
  canCreate: boolean;
  canUpdate: boolean;
  canDelete: boolean;
};

/**
 * Get user permissions for a specific menu path
 */
export async function getUserMenuPermission(
  userId: string,
  menuPath: string
): Promise<Permission> {
  const userRoles = await prisma.userRole.findMany({
    where: { userId },
    select: { roleId: true },
  });

  if (userRoles.length === 0) {
    return {
      canView: false,
      canCreate: false,
      canUpdate: false,
      canDelete: false,
    };
  }

  const roleIds = userRoles.map((r) => r.roleId);

  // Find menu by path
  const menu = await prisma.menu.findUnique({
    where: { path: menuPath },
    select: { id: true },
  });

  if (!menu) {
    return {
      canView: false,
      canCreate: false,
      canUpdate: false,
      canDelete: false,
    };
  }

  // Get all permissions for this menu across user's roles
  const roleMenus = await prisma.roleMenu.findMany({
    where: {
      roleId: { in: roleIds },
      menuId: menu.id,
    },
    select: {
      canView: true,
      canCreate: true,
      canUpdate: true,
      canDelete: true,
    },
  });

  // User has permission if ANY of their roles has it
  return {
    canView: roleMenus.some((rm) => rm.canView),
    canCreate: roleMenus.some((rm) => rm.canCreate),
    canUpdate: roleMenus.some((rm) => rm.canUpdate),
    canDelete: roleMenus.some((rm) => rm.canDelete),
  };
}

/**
 * Check if user has specific permission for a menu
 */
export async function hasPermission(
  userId: string,
  menuPath: string,
  permission: "view" | "create" | "update" | "delete"
): Promise<boolean> {
  const perms = await getUserMenuPermission(userId, menuPath);
  switch (permission) {
    case "view":
      return perms.canView;
    case "create":
      return perms.canCreate;
    case "update":
      return perms.canUpdate;
    case "delete":
      return perms.canDelete;
    default:
      return false;
  }
}

