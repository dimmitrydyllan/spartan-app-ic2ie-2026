import { prisma } from "./prisma"

type MenuNode = {
  id: string
  name: string
  path: string
  icon?: string | null
  order: number
  children: MenuNode[]
}

async function getMenusForUser(userId: string): Promise<MenuNode[]> {
  // Ambil semua role user, lalu menu yang diizinkan melalui RoleMenu.
  const userRoles = await prisma.userRole.findMany({
    where: { userId },
    select: { roleId: true },
  })
  if (userRoles.length === 0) return []

  const roleIds = userRoles.map((r) => r.roleId)

  const allowedMenus = await prisma.roleMenu.findMany({
    where: { roleId: { in: roleIds }, canView: true },
    select: {
      menu: {
        select: {
          id: true,
          name: true,
          path: true,
          icon: true,
          parentId: true,
          order: true,
          isActive: true,
        },
      },
    },
  })

  const menus = allowedMenus
    .map((rm) => rm.menu)
    .filter((m) => m.isActive)

  const byId: Record<string, MenuNode> = {}
  menus.forEach((m) => {
    byId[m.id] = {
      id: m.id,
      name: m.name,
      path: m.path,
      icon: m.icon,
      order: m.order,
      children: [],
    }
  })

  const roots: MenuNode[] = []
  menus.forEach((m) => {
    const node = byId[m.id]
    if (m.parentId && byId[m.parentId]) {
      byId[m.parentId].children.push(node)
    } else {
      roots.push(node)
    }
  })

  const sortTree = (nodes: MenuNode[]) => {
    nodes.sort((a, b) => a.order - b.order || a.name.localeCompare(b.name))
    nodes.forEach((n) => sortTree(n.children))
  }
  sortTree(roots)

  return roots
}

export type { MenuNode }
export { getMenusForUser }

