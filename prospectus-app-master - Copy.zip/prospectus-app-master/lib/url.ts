/**
 * Utility untuk mendapatkan base URL aplikasi
 * 
 * Menggunakan NEXT_PUBLIC_BASE_URL jika tersedia,
 * atau fallback ke relative path untuk development
 */
export function getBaseUrl(): string {
  // Di server-side, gunakan environment variable atau infer dari request
  if (typeof window === "undefined") {
    // Server-side: gunakan NEXT_PUBLIC_BASE_URL jika ada
    return process.env.NEXT_PUBLIC_BASE_URL || ""
  }

  // Client-side: gunakan NEXT_PUBLIC_BASE_URL atau current origin
  return (
    process.env.NEXT_PUBLIC_BASE_URL ||
    window.location.origin
  )
}

/**
 * Membuat absolute URL dari path relatif
 * 
 * @param path - Path relatif (contoh: "/api/data")
 * @returns Absolute URL (contoh: "https://prospectus-app.site/api/data")
 */
export function getAbsoluteUrl(path: string): string {
  const baseUrl = getBaseUrl()
  
  // Jika baseUrl kosong, gunakan relative path (akan otomatis menggunakan current origin)
  if (!baseUrl) {
    return path
  }

  // Pastikan path dimulai dengan /
  const normalizedPath = path.startsWith("/") ? path : `/${path}`
  
  // Hapus trailing slash dari baseUrl
  const normalizedBase = baseUrl.replace(/\/$/, "")
  
  return `${normalizedBase}${normalizedPath}`
}

