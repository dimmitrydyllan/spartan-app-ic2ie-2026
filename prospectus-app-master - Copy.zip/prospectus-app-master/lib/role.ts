import { prisma } from "./prisma"

export async function getUserRoles(userId: string) {
  const userRoles = await prisma.userRole.findMany({
    where: { userId },
    include: { role: true },
  })
  return userRoles.map((ur) => ur.role)
}

export async function isSupervisorOrAdmin(userId: string): Promise<boolean> {
  const roles = await getUserRoles(userId)
  return roles.some(
    (r) =>
      r.code.toUpperCase() === "SUPERVISOR" || r.code.toUpperCase() === "ADMIN"
  )
}

export async function isSales(userId: string): Promise<boolean> {
  const roles = await getUserRoles(userId)
  return roles.some((r) => r.code.toUpperCase() === "SALES")
}

export async function getUserRoleCodes(userId: string): Promise<string[]> {
  const roles = await getUserRoles(userId)
  return roles.map((r) => r.code.toUpperCase())
}

