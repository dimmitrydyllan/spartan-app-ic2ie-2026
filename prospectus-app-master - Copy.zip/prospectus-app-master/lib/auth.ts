import { cookies } from "next/headers"

const AUTH_COOKIE = "auth_token"

type Session = {
  token: string
  email?: string
  userId?: string
  name?: string
}

async function getSession(): Promise<Session | null> {
  const store = await cookies()
  const cookie = store.get(AUTH_COOKIE)
  
  if (!cookie?.value) {
    // Debug: log jika cookie tidak ada (hanya di development)
    if (process.env.NODE_ENV === "development") {
      console.log("session undefined - cookie tidak ditemukan")
    }
    return null
  }
  
  try {
    const parsed = JSON.parse(cookie.value) as Session
    if (!parsed?.token) {
      if (process.env.NODE_ENV === "development") {
        console.log("session undefined - token tidak ada di parsed cookie")
      }
      return null
    }
    return parsed
  } catch (error) {
    // Fallback jika format tidak JSON.
    if (process.env.NODE_ENV === "development") {
      console.log("session fallback - error parsing cookie:", error)
    }
    return { token: cookie.value }
  }
}

async function createSession(session: Session) {
  const store = await cookies()
  
  // Di production dengan HTTPS, gunakan secure: true
  // Di development atau jika tidak yakin, gunakan secure: false
  // Tapi karena kita di belakang reverse proxy (Nginx) dengan SSL,
  // kita perlu secure: true di production
  const isProduction = process.env.NODE_ENV === "production"
  const isSecure = isProduction // Di production, selalu secure karena menggunakan HTTPS
  
  store.set(AUTH_COOKIE, JSON.stringify(session), {
    path: "/",
    httpOnly: true,
    secure: isSecure,
    sameSite: "lax", // "lax" untuk cross-site navigation yang aman
    maxAge: 60 * 60 * 24 * 7, // 7 hari
    // Jangan set domain secara eksplisit, biarkan browser handle domain
    // Ini memastikan cookie bekerja dengan baik di belakang reverse proxy
  })
}

async function destroySession() {
  const store = await cookies()
  store.delete(AUTH_COOKIE)
}

export { AUTH_COOKIE, createSession, destroySession, getSession }

