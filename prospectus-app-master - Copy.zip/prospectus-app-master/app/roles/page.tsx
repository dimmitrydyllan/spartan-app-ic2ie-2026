import Link from "next/link";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { AssignUserForm } from "@/components/assign-user-form";
import { CreateRoleForm } from "@/components/create-role-form";
import { EditRoleForm } from "@/components/edit-role-form";
import { DeleteConfirmDialog } from "@/components/delete-confirm-dialog";
import { DashboardLayout } from "@/components/dashboard-layout";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { hasPermission, getUserMenuPermission } from "@/lib/permission";

async function createRole(formData: FormData) {
  "use server";
  const session = await getSession();
  if (!session?.userId) {
    return { success: false, error: "unauthorized" };
  }

  // Check permission
  const canCreate = await hasPermission(session.userId, "/roles", "create");
  if (!canCreate) {
    return { success: false, error: "forbidden" };
  }

  const code = formData.get("code")?.toString().trim();
  const name = formData.get("name")?.toString().trim();

  if (!code || !name) {
    return { success: false, error: "invalid" };
  }

  try {
    await prisma.role.create({
      data: { code: code.toUpperCase(), name },
    });
    return { success: true };
  } catch (error: any) {
    return { success: false, error: error.code === "P2002" ? "duplicate" : "failed" };
  }
}

async function updateRole(formData: FormData) {
  "use server";
  const session = await getSession();
  if (!session?.userId) {
    return { success: false, error: "unauthorized" };
  }

  // Check permission
  const canUpdate = await hasPermission(session.userId, "/roles", "update");
  if (!canUpdate) {
    return { success: false, error: "forbidden" };
  }

  const id = formData.get("id")?.toString();
  const code = formData.get("code")?.toString().trim();
  const name = formData.get("name")?.toString().trim();

  if (!id || !code || !name) {
    return { success: false, error: "invalid" };
  }

  try {
    await prisma.role.update({
      where: { id },
      data: { code: code.toUpperCase(), name },
    });
    return { success: true };
  } catch (error: any) {
    if (error.code === "P2025") {
      return { success: false, error: "not_found" };
    }
    return { success: false, error: error.code === "P2002" ? "duplicate" : "failed" };
  }
}

async function deleteRole(formData: FormData) {
  "use server";
  const session = await getSession();
  if (!session?.userId) {
    return { success: false, error: "unauthorized" };
  }

  // Check permission
  const canDelete = await hasPermission(session.userId, "/roles", "delete");
  if (!canDelete) {
    return { success: false, error: "forbidden" };
  }

  const id = formData.get("id")?.toString();
  if (!id) return { success: false, error: "invalid" };

  try {
    await prisma.role.delete({ where: { id } });
    return { success: true };
  } catch {
    return { success: false, error: "delete_failed" };
  }
}

async function assignUserToRole(formData: FormData) {
  "use server";
  const userId = formData.get("userId")?.toString();
  const roleId = formData.get("roleId")?.toString();

  if (!userId || !roleId) {
    return { success: false, error: "invalid" };
  }

  try {
    await prisma.userRole.create({
      data: { userId, roleId },
    });
    return { success: true };
  } catch (error: any) {
    return { success: false, error: error.code === "P2002" ? "already_assigned" : "failed" };
  }
}

async function removeUserRole(formData: FormData) {
  "use server";
  const id = formData.get("id")?.toString();
  if (!id) return { success: false, error: "invalid" };

  try {
    await prisma.userRole.delete({ where: { id } });
    return { success: true };
  } catch {
    return { success: false, error: "remove_failed" };
  }
}

export default async function RolesPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const params = await searchParams;
  const rolePage = Number(params.rp ?? "1");
  const currentRolePage =
    Number.isFinite(rolePage) && rolePage > 0 ? rolePage : 1;
  const rolePageSize = 10;

  const userRolePage = Number(params.urp ?? "1");
  const currentUserRolePage =
    Number.isFinite(userRolePage) && userRolePage > 0 ? userRolePage : 1;
  const userRolePageSize = 10;

  const [
    [roles, totalRoles],
    rolesAll,
    [userRoles, totalUserRoles],
    users,
  ] = await Promise.all([
    Promise.all([
      prisma.role.findMany({
        orderBy: { code: "asc" },
        skip: (currentRolePage - 1) * rolePageSize,
        take: rolePageSize,
      }),
      prisma.role.count(),
    ]),
    prisma.role.findMany({ orderBy: { code: "asc" } }),
    Promise.all([
      prisma.userRole.findMany({
        include: {
          user: { select: { id: true, name: true, email: true } },
          role: { select: { id: true, code: true, name: true } },
        },
        orderBy: [{ role: { code: "asc" } }, { user: { name: "asc" } }],
        skip: (currentUserRolePage - 1) * userRolePageSize,
        take: userRolePageSize,
      }),
      prisma.userRole.count(),
    ]),
    prisma.user.findMany({
      select: { id: true, name: true, email: true },
      orderBy: { name: "asc" },
    }),
  ]);

  const roleTotalPages = Math.max(
    1,
    Math.ceil(totalRoles / rolePageSize)
  );
  const userRoleTotalPages = Math.max(
    1,
    Math.ceil(totalUserRoles / userRolePageSize)
  );
  const baseUrl = "/roles";

  // Get user permissions
  const session = await getSession();
  const permissions = session?.userId
    ? await getUserMenuPermission(session.userId, "/roles")
    : {
        canView: false,
        canCreate: false,
        canUpdate: false,
        canDelete: false,
      };

  return (
    <DashboardLayout title="Master Role & Assign User">
      <div className="mx-auto max-w-7xl space-y-4 sm:space-y-6">
        <div className="space-y-1">
          <h2 className="text-2xl sm:text-3xl font-bold">
            Master Role & Assign User
          </h2>
          <p className="text-sm sm:text-base text-slate-600">
            Kelola role dan assign user ke role tertentu
          </p>
        </div>

        {params.error && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-3 sm:p-4 text-sm sm:text-base text-red-800">
            {params.error === "duplicate" && "Role code sudah ada"}
            {params.error === "already_assigned" &&
              "User sudah memiliki role ini"}
            {params.error === "delete_failed" && "Gagal menghapus role"}
            {params.error === "remove_failed" && "Gagal menghapus assign"}
            {params.error === "invalid" && "Data tidak valid"}
            {params.error === "failed" && "Terjadi kesalahan"}
          </div>
        )}

        {params.success && (
          <div className="rounded-lg border border-green-200 bg-green-50 p-3 sm:p-4 text-sm sm:text-base text-green-800">
            {params.success === "created" && "Role berhasil dibuat"}
            {params.success === "deleted" && "Role berhasil dihapus"}
            {params.success === "assigned" && "User berhasil di-assign"}
            {params.success === "removed" && "Assign berhasil dihapus"}
          </div>
        )}

        <div className="grid gap-4 sm:gap-6 lg:grid-cols-2">
          {/* Master Role */}
          <Card>
            <CardHeader className="pb-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <CardTitle className="text-lg sm:text-xl">Master Role</CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Tambah dan kelola role akses
                  </CardDescription>
                </div>
                {permissions.canCreate && (
                  <CreateRoleForm action={createRole} />
                )}
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[100px]">Code</TableHead>
                      <TableHead className="min-w-[150px]">Nama</TableHead>
                      <TableHead className="w-[80px] sm:w-[100px]">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {roles.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={3} className="text-center text-slate-500 py-8">
                          Belum ada role
                        </TableCell>
                      </TableRow>
                    ) : (
                      roles.map((role) => (
                        <TableRow key={role.id}>
                          <TableCell>
                            <Badge variant="outline" className="font-mono text-xs">
                              {role.code}
                            </Badge>
                          </TableCell>
                          <TableCell className="font-medium">{role.name}</TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {permissions.canUpdate && (
                                <EditRoleForm
                                  role={role}
                                  action={updateRole}
                                />
                              )}
                              {permissions.canDelete && (
                                <DeleteConfirmDialog
                                  title="Hapus Role"
                                  description={`Apakah Anda yakin ingin menghapus role "${role.name}"? Tindakan ini tidak dapat dibatalkan.`}
                                  action={deleteRole}
                                  id={role.id}
                                  successMessage="Role berhasil dihapus"
                                  errorMessage="Gagal menghapus role"
                                />
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
              <div className="mt-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-sm text-slate-600">
                <span>
                  Menampilkan {roles.length} dari {totalRoles} role (halaman {currentRolePage} /{" "}
                  {roleTotalPages})
                </span>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" disabled={currentRolePage <= 1}>
                    <Link href={`${baseUrl}?rp=${currentRolePage - 1}&urp=${currentUserRolePage}`} prefetch>
                      Sebelumnya
                    </Link>
                  </Button>
                  <Button variant="outline" size="sm" disabled={currentRolePage >= roleTotalPages}>
                    <Link href={`${baseUrl}?rp=${currentRolePage + 1}&urp=${currentUserRolePage}`} prefetch>
                      Berikutnya
                    </Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Assign User ke Role */}
          <Card>
            <CardHeader className="pb-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <CardTitle className="text-lg sm:text-xl">
                    Assign User ke Role
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Berikan role kepada user tertentu
                  </CardDescription>
                </div>
                <AssignUserForm
                  users={users}
                  roles={roles}
                  action={assignUserToRole}
                />
              </div>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[200px]">User</TableHead>
                      <TableHead className="min-w-[150px]">Role</TableHead>
                      <TableHead className="w-[80px] sm:w-[100px]">Aksi</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {userRoles.length === 0 ? (
                      <TableRow>
                        <TableCell
                          colSpan={3}
                          className="text-center text-slate-500 py-8"
                        >
                          Belum ada user yang di-assign
                        </TableCell>
                      </TableRow>
                    ) : (
                      userRoles.map((ur) => (
                        <TableRow key={ur.id}>
                          <TableCell>
                            <div className="flex flex-col">
                              <span className="font-medium">{ur.user.name}</span>
                              <span className="text-xs text-slate-500">
                                {ur.user.email}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-col gap-1">
                              <Badge variant="outline" className="font-mono text-xs w-fit">
                                {ur.role.code}
                              </Badge>
                              <span className="text-sm text-slate-600">
                                {ur.role.name}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <DeleteConfirmDialog
                              title="Hapus Assign Role"
                              description={`Apakah Anda yakin ingin menghapus role "${ur.role.name}" dari user "${ur.user.name}"?`}
                              action={removeUserRole}
                              id={ur.id}
                              successMessage="Assign berhasil dihapus"
                              errorMessage="Gagal menghapus assign"
                            />
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
              <div className="mt-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-sm text-slate-600">
                <span>
                  Menampilkan {userRoles.length} dari {totalUserRoles} assign
                  (halaman {currentUserRolePage} / {userRoleTotalPages})
                </span>
                <div className="flex items-center gap-2">
                  <Button variant="outline" size="sm" disabled={currentUserRolePage <= 1}>
                    <Link href={`${baseUrl}?rp=${currentRolePage}&urp=${currentUserRolePage - 1}`} prefetch>
                      Sebelumnya
                    </Link>
                  </Button>
                  <Button variant="outline" size="sm" disabled={currentUserRolePage >= userRoleTotalPages}>
                    <Link href={`${baseUrl}?rp=${currentRolePage}&urp=${currentUserRolePage + 1}`} prefetch>
                      Berikutnya
                    </Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}

