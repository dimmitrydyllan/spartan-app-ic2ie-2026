import { promises as fs } from "fs"
import path from "path"
import crypto from "crypto"
import Link from "next/link"
import { redirect } from "next/navigation"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { DashboardLayout } from "@/components/dashboard-layout"
import { prisma } from "@/lib/prisma"
import { getSession } from "@/lib/auth"
import { ProspectusForm } from "@/components/prospectus-form"
import { ProspectusToast } from "@/components/prospectus-toast"
import { FollowUpForm } from "@/components/follow-up-form"
import { ProspectusExportButton } from "@/components/prospectus-export-button"
import { ProspectusActions } from "@/components/prospectus-actions"

const STATUS_LABEL: Record<string, string> = {
  PROSPECT: "Prospect",
  FOLLOW_UP: "Follow Up",
  PROJECTION: "Projection",
  REJECTED: "Rejected",
  CANCELED: "Canceled",
}

const STATUS_BADGE: Record<string, string> = {
  PROSPECT: "border-blue-200 bg-blue-50 text-blue-700",
  FOLLOW_UP: "border-amber-200 bg-amber-50 text-amber-700",
  PROJECTION: "border-purple-200 bg-purple-50 text-purple-700",
  REJECTED: "border-red-200 bg-red-50 text-red-700",
  CANCELED: "border-slate-200 bg-slate-50 text-slate-700",
}

async function createActivity(formData: FormData) {
  "use server"
  const session = await getSession()
  if (!session?.userId) {
    redirect("/login")
  }

  const userId = formData.get("userId")?.toString()
  const brokerName = formData.get("brokerName")?.toString().trim() || null
  const title = formData.get("title")?.toString().trim()
  const clientPhone = formData.get("clientPhone")?.toString().trim() || null
  const description = formData.get("description")?.toString().trim() || null
  const statusRaw = formData.get("status")?.toString()
  const photosRaw = formData.get("photos")?.toString()

  const allowedStatus = ["PROSPECT", "FOLLOW_UP", "PROJECTION", "REJECTED", "CANCELED"]
  const status = allowedStatus.includes(statusRaw || "") ? (statusRaw as any) : "PROSPECT"

  if (!userId || userId !== session.userId || !title) {
    throw new Error("INVALID")
  }

  try {
    const photoUrls = await persistPhotos(photosRaw)
    await prisma.prospectusActivity.create({
      data: {
        userId: session.userId,
        brokerName,
        title,
        clientPhone,
        description,
        status,
        activityDate: new Date(),
        photoUrls,
      } as any,
    })
    return { success: true }
  } catch (error) {
    console.error("Failed to create prospectus activity", error)
    throw error
  }
}

async function persistPhotos(photosRaw?: string | null): Promise<string[]> {
  if (!photosRaw) return []
  let photos: string[] = []
  try {
    photos = JSON.parse(photosRaw)
    if (!Array.isArray(photos)) return []
  } catch {
    return []
  }

  const uploadDir = path.join(process.cwd(), "uploads", "prospectus")
  await fs.mkdir(uploadDir, { recursive: true })

  const urls: string[] = []

  for (const dataUrl of photos) {
    const parsed = /^data:(.+);base64,(.+)$/.exec(dataUrl)
    if (!parsed) continue
    const mime = parsed[1]
    const base64 = parsed[2]
    const buffer = Buffer.from(base64, "base64")

    const isJpeg = mime === "image/jpeg" || mime === "image/jpg" || mime === "image/pjpeg"
    const ext = mime === "image/png" ? "png" : isJpeg ? "jpg" : "bin"
    const filename = `${Date.now()}-${crypto.randomUUID()}.${ext}`
    const filePath = path.join(uploadDir, filename)
    await fs.writeFile(filePath, buffer)
    urls.push(`/api/prospectus/photo/${encodeURIComponent(filename)}`)
  }

  return urls
}

async function updateFollowUp(formData: FormData) {
  "use server"
  const session = await getSession()
  if (!session?.userId) {
    redirect("/login")
  }

  const id = formData.get("id")?.toString()
  const statusRaw = formData.get("status")?.toString()
  const followUpNote = formData.get("followUpNote")?.toString().trim() || null

  const allowedStatus = ["PROSPECT", "FOLLOW_UP", "PROJECTION", "REJECTED", "CANCELED"]
  const status = allowedStatus.includes(statusRaw || "") ? (statusRaw as any) : "FOLLOW_UP"

  if (!id) {
    return { success: false, error: "invalid" }
  }

  const existing = await prisma.prospectusActivity.findUnique({ where: { id } })
  if (!existing || existing.userId !== session.userId) {
    return { success: false, error: "unauthorized" }
  }

  try {
    await prisma.prospectusActivity.update({
      where: { id },
      data: {
        status,
        followUpNote,
        followUpAt: new Date(),
      } as any,
    })
    return { success: true }
  } catch (error) {
    console.error("Failed to update follow up", error)
    return { success: false, error: "failed" }
  }
}

async function updateActivity(formData: FormData) {
  "use server"
  const session = await getSession()
  if (!session?.userId) {
    redirect("/login")
  }

  const id = formData.get("id")?.toString()
  const userId = formData.get("userId")?.toString()
  const brokerName = formData.get("brokerName")?.toString().trim() || null
  const title = formData.get("title")?.toString().trim()
  const clientPhone = formData.get("clientPhone")?.toString().trim() || null
  const description = formData.get("description")?.toString().trim() || null
  const statusRaw = formData.get("status")?.toString()
  const photosRaw = formData.get("photos")?.toString()

  const allowedStatus = ["PROSPECT", "FOLLOW_UP", "PROJECTION", "REJECTED", "CANCELED"]
  const status = allowedStatus.includes(statusRaw || "") ? (statusRaw as any) : "PROSPECT"

  if (!id || !userId || userId !== session.userId || !title) {
    return { success: false, error: "invalid" }
  }

  const existing = await prisma.prospectusActivity.findUnique({ where: { id } })
  if (!existing || existing.userId !== session.userId) {
    return { success: false, error: "unauthorized" }
  }

  try {
    let photoUrls: string[] = []
    
    if (photosRaw) {
      try {
        const photosData = JSON.parse(photosRaw)
        // Jika format baru: { existing: [...], new: [...] }
        if (photosData.existing && Array.isArray(photosData.existing)) {
          // Foto yang sudah ada (URL) - yang tidak dihapus oleh user
          photoUrls = [...photosData.existing]
          // Proses foto baru (base64)
          if (photosData.new && Array.isArray(photosData.new) && photosData.new.length > 0) {
            const newPhotoUrls = await persistPhotos(JSON.stringify(photosData.new))
            photoUrls = [...photoUrls, ...newPhotoUrls]
          }
        } else if (Array.isArray(photosData)) {
          // Format lama: array langsung (untuk backward compatibility dengan create)
          const newPhotoUrls = await persistPhotos(photosRaw)
          photoUrls = newPhotoUrls
        }
      } catch {
        // Jika parsing gagal, coba format lama
        const newPhotoUrls = await persistPhotos(photosRaw)
        photoUrls = newPhotoUrls
      }
    }
    // Jika photosRaw tidak ada, tetap gunakan array kosong (tidak mempertahankan foto lama)
    // Ini memastikan bahwa jika user menghapus semua foto, foto benar-benar dihapus

    await prisma.prospectusActivity.update({
      where: { id },
      data: {
        brokerName,
        title,
        clientPhone,
        description,
        status,
        photoUrls,
      } as any,
    })
    return { success: true }
  } catch (error) {
    console.error("Failed to update activity", error)
    return { success: false, error: "failed" }
  }
}

async function deleteActivity(formData: FormData) {
  "use server"
  const session = await getSession()
  if (!session?.userId) {
    redirect("/login")
  }

  const id = formData.get("id")?.toString()

  if (!id) {
    return { success: false, error: "invalid" }
  }

  const existing = await prisma.prospectusActivity.findUnique({ where: { id } })
  if (!existing || existing.userId !== session.userId) {
    return { success: false, error: "unauthorized" }
  }

  try {
    await prisma.prospectusActivity.delete({
      where: { id },
    })
    return { success: true }
  } catch (error) {
    console.error("Failed to delete activity", error)
    return { success: false, error: "failed" }
  }
}

function formatDate(value: Date) {
  try {
    return new Intl.DateTimeFormat("id-ID", {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(value)
  } catch {
    return value.toISOString()
  }
}

function formatInputDate(value: Date) {
  const year = value.getFullYear()
  const month = `${value.getMonth() + 1}`.padStart(2, "0")
  const day = `${value.getDate()}`.padStart(2, "0")
  return `${year}-${month}-${day}`
}

export default async function ProspectusPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>
}) {
  const params = await searchParams
  const session = await getSession()
  if (!session?.userId) {
    redirect("/login")
  }

  const page = Number(params.page ?? "1")
  const currentPage = Number.isFinite(page) && page > 0 ? page : 1
  const pageSize = 10

  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const defaultStart = today
  const defaultEnd = new Date(today)
  defaultEnd.setHours(23, 59, 59, 999)

  const startParam = params.start
  const endParam = params.end
  const parsedStart = startParam ? new Date(startParam) : defaultStart
  const parsedEnd = endParam ? new Date(endParam) : defaultEnd
  const startDate = isNaN(parsedStart.getTime()) ? defaultStart : parsedStart
  const endDate = isNaN(parsedEnd.getTime()) ? defaultEnd : parsedEnd
  endDate.setHours(23, 59, 59, 999)

  const [[activities, total]] = await Promise.all([
    Promise.all([
      prisma.prospectusActivity.findMany({
        where: {
          userId: session.userId,
          activityDate: {
            gte: startDate,
            lte: endDate,
          },
        },
        orderBy: { activityDate: "desc" },
        skip: (currentPage - 1) * pageSize,
        take: pageSize,
      }),
      prisma.prospectusActivity.count({
        where: {
          userId: session.userId,
          activityDate: {
            gte: startDate,
            lte: endDate,
          },
        },
      }),
    ]),
  ])

  const totalPages = Math.max(1, Math.ceil(total / pageSize))
  const baseUrl = "/prospectus"

  return (
    <DashboardLayout title="Prospectus">
      <div className="mx-auto max-w-6xl space-y-6">
        <ProspectusToast
          success={
            params.success === "recorded"
              ? "Aktivitas berhasil dicatat"
              : params.success === "updated"
              ? "Follow up diperbarui"
              : params.success === "edited"
              ? "Aktivitas berhasil diperbarui"
              : params.success === "deleted"
              ? "Aktivitas berhasil dihapus"
              : undefined
          }
          error={
            params.error === "invalid"
              ? "Data tidak valid"
              : params.error === "unauthorized"
              ? "Tidak diizinkan"
              : params.error === "failed"
              ? "Gagal memproses data"
              : undefined
          }
        />

        <div className="flex flex-col gap-1">
          <h2 className="text-2xl sm:text-3xl font-bold">Prospectus</h2>
          <p className="text-sm sm:text-base text-slate-600">
            Catat aktivitas prospectus, lampirkan foto, dan lakukan follow up.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg sm:text-xl">Tambah Aktivitas</CardTitle>
          </CardHeader>
          <CardContent>
            <ProspectusForm userId={session.userId} action={createActivity} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg sm:text-xl">Filter Riwayat</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Dari tanggal</label>
                <input
                  type="date"
                  name="start"
                  defaultValue={formatInputDate(startDate)}
                  className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Sampai tanggal</label>
                <input
                  type="date"
                  name="end"
                  defaultValue={formatInputDate(endDate)}
                  className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                />
              </div>
              <div className="flex gap-2 sm:justify-end">
                <Button type="submit" className="w-full sm:w-auto">
                  Terapkan
                </Button>
                <Button variant="ghost" asChild className="w-full sm:w-auto">
                  <a href={baseUrl}>Reset</a>
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
            <CardTitle className="text-lg sm:text-xl">Daftar Aktivitas</CardTitle>
            <ProspectusExportButton />
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table className="table-auto w-full">
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[180px]">Nama Broker</TableHead>
                    <TableHead className="min-w-[180px]">Nama Client</TableHead>
                    <TableHead className="min-w-[140px]">Nomor Telepon</TableHead>
                    <TableHead className="min-w-[120px]">Status</TableHead>
                    <TableHead className="min-w-[140px]">Tanggal</TableHead>
                    <TableHead className="min-w-[140px]">Foto</TableHead>
                    <TableHead className="min-w-[200px]">Deskripsi</TableHead>
                    <TableHead className="min-w-[220px]">Follow Up</TableHead>
                    <TableHead className="min-w-[100px]">Aksi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {activities.length === 0 ? (
                    <TableRow>
                      <TableCell colSpan={9} className="text-center text-muted-foreground py-8">
                        Belum ada aktivitas
                      </TableCell>
                    </TableRow>
                  ) : (
                    activities.map((act) => (
                      <TableRow key={act.id} className="align-middle">
                        <TableCell className="whitespace-normal break-words align-middle text-sm text-muted-foreground">
                          {(act as any).brokerName || <span className="text-muted-foreground/70">-</span>}
                        </TableCell>
                        <TableCell className="whitespace-normal break-words align-middle">
                          <div className="font-medium">{act.title}</div>
                        </TableCell>
                        <TableCell className="whitespace-normal break-words align-middle text-sm text-muted-foreground">
                          {(act as any).clientPhone || <span className="text-muted-foreground/70">-</span>}
                        </TableCell>
                        <TableCell className="align-middle">
                          <Badge
                            variant="outline"
                            className={STATUS_BADGE[act.status] || "border-border text-muted-foreground"}
                          >
                            {STATUS_LABEL[act.status] || act.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground align-middle">
                          {formatDate(act.activityDate)}
                        </TableCell>
                        <TableCell className="min-w-[140px] align-middle">
                          {(act as any).photoUrls?.length ? (
                            <div className="flex flex-wrap justify-center gap-2">
                              {(act as any).photoUrls.map((url: string, idx: number) => (
                                // eslint-disable-next-line @next/next/no-img-element
                                <img
                                  key={idx}
                                  src={url}
                                  alt={`Lampiran ${idx + 1}`}
                                  className="h-14 w-14 rounded-md object-cover border border-border bg-muted"
                                />
                              ))}
                            </div>
                          ) : (
                            <span className="text-xs text-muted-foreground">Tidak ada foto</span>
                          )}
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground whitespace-pre-wrap break-words align-middle">
                          {act.description || <span className="text-muted-foreground/70">-</span>}
                        </TableCell>
                        <TableCell className="min-w-[220px] align-middle">
                          <FollowUpForm
                            id={act.id}
                            currentStatus={act.status}
                            currentFollowUpNote={(act as any).followUpNote}
                            action={updateFollowUp}
                          />
                        </TableCell>
                        <TableCell className="align-middle">
                          <ProspectusActions
                            activity={{
                              id: act.id,
                              brokerName: (act as any).brokerName,
                              title: act.title,
                              clientPhone: (act as any).clientPhone,
                              description: act.description,
                              status: act.status,
                              photoUrls: (act as any).photoUrls || [],
                            }}
                            userId={session.userId!}
                            updateAction={updateActivity}
                            deleteAction={deleteActivity}
                          />
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>

            <div className="mt-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-sm text-muted-foreground">
              <span>
                Menampilkan {activities.length} dari {total} data (halaman {currentPage} /{" "}
                {totalPages})
              </span>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage <= 1}
                >
                  <Link
                    href={`${baseUrl}?page=${currentPage - 1}${startParam ? `&start=${startParam}` : ""}${endParam ? `&end=${endParam}` : ""}`}
                    prefetch
                  >
                    Sebelumnya
                  </Link>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage >= totalPages}
                >
                  <Link
                    href={`${baseUrl}?page=${currentPage + 1}${startParam ? `&start=${startParam}` : ""}${endParam ? `&end=${endParam}` : ""}`}
                    prefetch
                  >
                    Berikutnya
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

