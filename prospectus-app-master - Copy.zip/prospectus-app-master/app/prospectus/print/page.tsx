import { redirect } from "next/navigation"

import { prisma } from "@/lib/prisma"
import { getSession } from "@/lib/auth"
import { ProspectusPrintView } from "@/components/prospectus-print-view"

export default async function ProspectusPrintPage() {
  const session = await getSession()

  if (!session?.userId) {
    redirect("/login")
  }

  const activities = await prisma.prospectusActivity.findMany({
    where: { userId: session.userId },
    orderBy: { activityDate: "desc" },
  })

  return <ProspectusPrintView activities={activities as any[]} userName={session.name ?? null} />
}


