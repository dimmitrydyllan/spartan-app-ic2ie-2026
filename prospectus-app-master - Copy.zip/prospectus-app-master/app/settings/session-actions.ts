"use server"

import { getSession, destroySession } from "@/lib/auth"
import { redirect } from "next/navigation"

export async function logoutAllSessions() {
  const session = await getSession()
  if (!session?.userId) {
    redirect("/login")
  }

  try {
    await destroySession()
    return { success: true }
  } catch (error) {
    console.error("Failed to logout all sessions", error)
    return { success: false, error: "Gagal mengakhiri sesi" }
  }
}
