"use server"

import { getSession } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { redirect } from "next/navigation"
import * as bcrypt from "bcryptjs"

export async function saveGeneralSettings(formData: FormData) {
  const session = await getSession()
  if (!session?.userId) {
    return { success: false, error: "unauthorized" }
  }

  try {
    // Simpan pengaturan umum
    // TODO: Bisa dikembangkan untuk menyimpan ke database atau file konfigurasi
    // Untuk sekarang, hanya return success karena ini adalah preferensi user
    // yang bisa disimpan di localStorage atau database di masa depan
    return { success: true }
  } catch (error) {
    console.error("Failed to save general settings", error)
    return { success: false, error: "Gagal menyimpan pengaturan" }
  }
}

export async function saveNotificationSettings(formData: FormData) {
  const session = await getSession()
  if (!session?.userId) {
    return { success: false, error: "unauthorized" }
  }

  try {
    // Simpan pengaturan notifikasi
    // TODO: Bisa dikembangkan untuk menyimpan ke database
    // Untuk sekarang, hanya return success karena ini adalah preferensi user
    // yang bisa disimpan di localStorage atau database di masa depan
    return { success: true }
  } catch (error) {
    console.error("Failed to save notification settings", error)
    return { success: false, error: "Gagal menyimpan pengaturan" }
  }
}

export async function changePassword(formData: FormData) {
  const session = await getSession()
  if (!session?.userId) {
    redirect("/login")
  }

  const currentPassword = formData.get("currentPassword")?.toString()
  const newPassword = formData.get("newPassword")?.toString()
  const confirmPassword = formData.get("confirmPassword")?.toString()

  if (!currentPassword || !newPassword || !confirmPassword) {
    return { success: false, error: "Semua field wajib diisi" }
  }

  if (newPassword !== confirmPassword) {
    return { success: false, error: "Password baru tidak cocok" }
  }

  if (newPassword.length < 6) {
    return { success: false, error: "Password minimal 6 karakter" }
  }

  try {
    // Get current user
    const user = await prisma.user.findUnique({
      where: { id: session.userId },
      select: { password: true },
    })

    if (!user) {
      return { success: false, error: "User tidak ditemukan" }
    }

    // Verify current password
    const isValidPassword = await bcrypt.compare(currentPassword, user.password)
    if (!isValidPassword) {
      return { success: false, error: "Password saat ini salah" }
    }

    // Hash new password
    const hashedPassword = await bcrypt.hash(newPassword, 10)

    // Update password
    await prisma.user.update({
      where: { id: session.userId },
      data: { password: hashedPassword },
    })

    return { success: true }
  } catch (error) {
    console.error("Failed to change password", error)
    return { success: false, error: "Gagal mengubah password" }
  }
}

export async function saveAppearanceSettings(formData: FormData) {
  const session = await getSession()
  if (!session?.userId) {
    return { success: false, error: "unauthorized" }
  }

  // Normalisasi input
  const themeRaw = formData.get("theme")?.toString() || "system"
  const theme =
    themeRaw === "light" || themeRaw === "dark" || themeRaw === "system"
      ? themeRaw
      : "system"
  const fontSizeRaw = formData.get("fontSize")?.toString() || "medium"
  const fontSize =
    fontSizeRaw === "small" || fontSizeRaw === "large" ? fontSizeRaw : "medium"
  const compactMode = formData.get("compactMode")?.toString() === "true"

  try {
    await prisma.user.update({
      where: { id: session.userId },
      data: {
        theme,
        fontSize,
        compactMode,
      },
    })

    return { success: true }
  } catch (error) {
    console.error("Failed to save appearance settings", error)
    return { success: false, error: "Gagal menyimpan pengaturan" }
  }
}

export async function getAppearanceSettings() {
  const session = await getSession()
  if (!session?.userId) {
    return null
  }

  try {
    const user = await prisma.user.findUnique({
      where: { id: session.userId },
      select: {
        theme: true,
        fontSize: true,
        compactMode: true,
      },
    })

    return user
  } catch (error) {
    console.error("Failed to get appearance settings", error)
    return null
  }
}

export async function clearCache() {
  const session = await getSession()
  if (!session?.userId) {
    redirect("/login")
  }

  // TODO: Implementasi clear cache
  return { success: true }
}

export async function exportData() {
  const session = await getSession()
  if (!session?.userId) {
    redirect("/login")
  }

  // TODO: Implementasi export data
  return { success: true }
}

