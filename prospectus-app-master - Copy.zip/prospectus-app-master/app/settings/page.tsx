import { redirect } from "next/navigation"
import { Settings as SettingsIcon, Bell, Shield, Globe, Palette, Database } from "lucide-react"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { DashboardLayout } from "@/components/dashboard-layout"
import { getSession } from "@/lib/auth"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { GeneralSettings } from "@/components/settings/general-settings"
import { GeneralSettingsSales } from "@/components/settings/general-settings-sales"
import { NotificationSettings } from "@/components/settings/notification-settings"
import { SecuritySettings } from "@/components/settings/security-settings"
import { AppearanceSettings } from "@/components/settings/appearance-settings"
import { SystemSettings } from "@/components/settings/system-settings"
import { isSales, isSupervisorOrAdmin } from "@/lib/role"

export default async function SettingsPage() {
  const session = await getSession()

  if (!session?.userId) {
    redirect("/login")
  }

  // Check user role
  const [isSalesUser, isAdminUser] = await Promise.all([
    isSales(session.userId),
    isSupervisorOrAdmin(session.userId),
  ])

  return (
    <DashboardLayout title="Pengaturan">
      <div className="mx-auto max-w-4xl space-y-6">
        <div className="space-y-1">
          <h2 className="text-2xl sm:text-3xl font-bold flex items-center gap-2">
            <SettingsIcon className="h-6 w-6 sm:h-8 sm:w-8" />
            Pengaturan
          </h2>
          <p className="text-sm sm:text-base text-muted-foreground">
            Kelola pengaturan aplikasi dan preferensi Anda
          </p>
        </div>

        <Tabs defaultValue="general" className="w-full">
          <TabsList className={`grid w-full ${isSalesUser && !isAdminUser ? 'grid-cols-2 sm:grid-cols-4' : 'grid-cols-2 sm:grid-cols-3 lg:grid-cols-5'} mb-6 h-auto`}>
            <TabsTrigger value="general" className="flex items-center justify-center gap-1 sm:gap-2 text-xs sm:text-sm py-2">
              <Globe className="h-3 w-3 sm:h-4 sm:w-4" />
              <span>Umum</span>
            </TabsTrigger>
            <TabsTrigger value="notifications" className="flex items-center justify-center gap-1 sm:gap-2 text-xs sm:text-sm py-2">
              <Bell className="h-3 w-3 sm:h-4 sm:w-4" />
              <span className="hidden xs:inline">Notifikasi</span>
              <span className="xs:hidden">Notif</span>
            </TabsTrigger>
            <TabsTrigger value="security" className="flex items-center justify-center gap-1 sm:gap-2 text-xs sm:text-sm py-2">
              <Shield className="h-3 w-3 sm:h-4 sm:w-4" />
              <span>Keamanan</span>
            </TabsTrigger>
            <TabsTrigger value="appearance" className="flex items-center justify-center gap-1 sm:gap-2 text-xs sm:text-sm py-2">
              <Palette className="h-3 w-3 sm:h-4 sm:w-4" />
              <span>Tampilan</span>
            </TabsTrigger>
            {!isSalesUser || isAdminUser ? (
              <TabsTrigger value="system" className="flex items-center justify-center gap-1 sm:gap-2 text-xs sm:text-sm py-2">
                <Database className="h-3 w-3 sm:h-4 sm:w-4" />
                <span>Sistem</span>
              </TabsTrigger>
            ) : null}
          </TabsList>

          <TabsContent value="general">
            {isSalesUser && !isAdminUser ? (
              <GeneralSettingsSales />
            ) : (
              <GeneralSettings />
            )}
          </TabsContent>

          <TabsContent value="notifications">
            <NotificationSettings />
          </TabsContent>

          <TabsContent value="security">
            <SecuritySettings />
          </TabsContent>

          <TabsContent value="appearance">
            <AppearanceSettings />
          </TabsContent>

          {!isSalesUser || isAdminUser ? (
            <TabsContent value="system">
              <SystemSettings />
            </TabsContent>
          ) : null}
        </Tabs>
      </div>
    </DashboardLayout>
  )
}

