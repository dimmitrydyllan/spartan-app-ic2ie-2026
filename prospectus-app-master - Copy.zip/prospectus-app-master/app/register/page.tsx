import Link from "next/link"
import { redirect } from "next/navigation"
import bcrypt from "bcryptjs"

import { Input } from "@/components/ui/input"
import { createSession, getSession } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { RegisterForm } from "@/components/register-form"

async function handleRegister(formData: FormData) {
  "use server"
  const name = formData.get("name")?.toString().trim()
  const email = formData.get("email")?.toString().trim()
  const password = formData.get("password")?.toString()
  const confirmPassword = formData.get("confirmPassword")?.toString()

  if (!name || !email || !password || !confirmPassword) {
    throw new Error("Semua field wajib diisi")
  }

  if (password !== confirmPassword) {
    throw new Error("Password tidak cocok")
  }

  if (password.length < 6) {
    throw new Error("Password minimal 6 karakter")
  }

  const existing = await prisma.user.findUnique({
    where: { email },
  })

  if (existing) {
    throw new Error("Email sudah terdaftar")
  }

  const hashed = await bcrypt.hash(password, 10)

  const user = await prisma.user.create({
    data: {
      name,
      email,
      password: hashed,
    },
  })

  await createSession({
    token: crypto.randomUUID(),
    email: user.email,
    userId: user.id,
    name: user.name,
  })

  redirect("/dashboard")
}

export default async function RegisterPage() {
  const session = await getSession()
  if (session) {
    redirect("/dashboard")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-muted text-foreground">
      <div className="mx-auto flex min-h-screen max-w-4xl flex-col justify-center px-6 py-12">
        <div className="mb-10">
          <Link href="/" className="text-sm text-primary hover:underline">
            ← Kembali ke landing
          </Link>
        </div>
        <div className="grid gap-10 rounded-2xl border border-border bg-card p-8 shadow-sm lg:grid-cols-2">
          <div className="space-y-4">
            <p className="text-sm font-semibold text-primary">Spartan</p>
            <h1 className="text-3xl font-bold leading-tight">
              Buat akun baru
            </h1>
            <p className="text-muted-foreground">
              Siapkan tim untuk mengelola prospectus, absensi, dan akses menu
              per role. Gratis untuk mulai.
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• Atur role & akses menu</li>
              <li>• Pantau aktivitas sales</li>
              <li>• Rekap absensi harian</li>
            </ul>
          </div>

          <RegisterForm action={handleRegister} />
        </div>
      </div>
    </div>
  )
}

