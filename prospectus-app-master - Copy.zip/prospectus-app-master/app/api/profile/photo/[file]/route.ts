import { promises as fs } from "fs"
import path from "path"
import { type NextRequest, NextResponse } from "next/server"

import { AUTH_COOKIE } from "@/lib/auth"

export const dynamic = "force-dynamic"
export const revalidate = 0

export async function GET(
  req: NextRequest,
  { params }: { params: Promise<{ file: string }> },
) {
  const cookieHeader = req.headers.get("cookie") || ""
  const hasAuthCookie = cookieHeader
    .split(";")
    .map((c) => c.trim().toLowerCase())
    .some((c) => c.startsWith(`${AUTH_COOKIE.toLowerCase()}=`))

  if (!hasAuthCookie) {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  }

  const resolvedParams = await params
  const fileName = safeFileName(resolvedParams?.file)
  if (!fileName) {
    return NextResponse.json({ error: "Not found" }, { status: 404 })
  }

  const filePath = path.join(process.cwd(), "uploads", "profile", fileName)
  try {
    const data = await fs.readFile(filePath)
    const ext = path.extname(fileName).toLowerCase()
    const contentType =
      ext === ".png"
        ? "image/png"
        : ext === ".jpg" || ext === ".jpeg"
        ? "image/jpeg"
        : "application/octet-stream"

    const headers = new Headers({
      "Content-Type": contentType,
      "Cache-Control": "private, max-age=31536000",
      "Content-Disposition": `inline; filename="${fileName}"`,
      Vary: "Cookie",
    })

    return new NextResponse(data, { status: 200, headers })
  } catch (error) {
    console.error("Profile photo not found", { fileName, filePath, error })
    return NextResponse.json({ error: "Not found" }, { status: 404 })
  }
}

function safeFileName(raw: string | undefined): string | null {
  if (!raw) return null
  try {
    const decoded = decodeURIComponent(raw)
    if (decoded.includes("..") || decoded.includes("/") || decoded.includes("\\")) return null
    return decoded
  } catch {
    return null
  }
}

