import { NextRequest } from "next/server"
import * as XLSX from "xlsx"
import PDFDocument from "pdfkit"

import { getSession } from "@/lib/auth"
import { prisma } from "@/lib/prisma"

export const runtime = "nodejs"
export const dynamic = "force-dynamic"

function escapeCsv(value: string | null | undefined): string {
  if (!value) return ""
  const needsQuote = /[",\n;]/.test(value)
  const escaped = value.replace(/"/g, '""')
  return needsQuote ? `"${escaped}"` : escaped
}

function formatDate(value: Date | null | undefined): string {
  if (!value) return ""
  try {
    return new Intl.DateTimeFormat("id-ID", {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(new Date(value))
  } catch {
    return new Date(value).toISOString()
  }
}

export async function GET(req: NextRequest) {
  const session = await getSession()
  if (!session?.userId) {
    return new Response("Unauthorized", { status: 401 })
  }

  const activities = await prisma.prospectusActivity.findMany({
    where: { userId: session.userId },
    orderBy: { activityDate: "desc" },
  })

  // Get format from query parameter, default to 'excel'
  const searchParams = req.nextUrl.searchParams
  const format = searchParams.get("format") || "excel"

  const header = [
    "No.",
    "Nama Broker",
    "Nama Client",
    "Nomor Telepon",
    "Status",
    "Tanggal Aktivitas",
    "Deskripsi",
    "Catatan Follow Up",
    "Waktu Follow Up",
    "Link Foto",
  ]

  const baseFilename = `prospectus-${new Date().toISOString().slice(0, 10)}`

  // Export to Excel
  if (format === "excel" || format === "xlsx") {
    const worksheetData = [
      header,
      ...(activities as any[]).map((act, index) => {
        const photoLinks = Array.isArray(act.photoUrls) ? act.photoUrls.join(", ") : ""
        return [
          index + 1,
          act.brokerName || "",
          act.title || "",
          act.clientPhone || "",
          act.status || "",
          formatDate(act.activityDate),
          act.description || "",
          act.followUpNote || "",
          formatDate(act.followUpAt),
          photoLinks,
        ]
      }),
    ]

    const worksheet = XLSX.utils.aoa_to_sheet(worksheetData)
    const workbook = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(workbook, worksheet, "Prospectus")

    // Set column widths
    const colWidths = [
      { wch: 5 },  // No.
      { wch: 30 }, // Nama Broker
      { wch: 30 }, // Nama Client
      { wch: 20 }, // Nomor Telepon
      { wch: 15 }, // Status
      { wch: 20 }, // Tanggal Aktivitas
      { wch: 40 }, // Deskripsi
      { wch: 40 }, // Catatan Follow Up
      { wch: 20 }, // Waktu Follow Up
      { wch: 50 }, // Link Foto
    ]
    worksheet["!cols"] = colWidths

    const excelBuffer = XLSX.write(workbook, { type: "buffer", bookType: "xlsx" })

    return new Response(excelBuffer, {
      status: 200,
      headers: {
        "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename="${baseFilename}.xlsx"`,
        "Cache-Control": "no-store",
      },
    })
  }

  // Export to PDF
  if (format === "pdf") {
    try {
      const doc = new PDFDocument({ margin: 50, size: "A4" })
      const chunks: Buffer[] = []

      doc.on("data", (chunk) => chunks.push(chunk as Buffer))
      doc.on("end", () => {})

      // Title
      doc.fontSize(18).font("Helvetica-Bold").text("Data Prospectus", { align: "center" })
      doc.moveDown()

      // Table header
      doc.fontSize(10).font("Helvetica-Bold")
      const tableTop = doc.y
      const colWidths = [30, 100, 100, 80, 70, 90, 120, 100, 90, 120]
      let x = 50

      header.forEach((col, idx) => {
        const align = idx === 0 ? "center" : "left"
        doc.text(col, x, tableTop, { width: colWidths[idx], align })
        x += colWidths[idx]
      })

      doc.moveDown(0.5)
      doc.moveTo(50, doc.y).lineTo(50 + colWidths.reduce((a, b) => a + b, 0), doc.y).stroke()
      doc.moveDown(0.5)

      // Table rows
      doc.font("Helvetica")
      ;(activities as any[]).forEach((act, idx) => {
        const photoLinks = Array.isArray(act.photoUrls) ? act.photoUrls.join(", ") : ""
        const rowData = [
          String(idx + 1),
          act.brokerName || "",
          act.title || "",
          act.clientPhone || "",
          act.status || "",
          formatDate(act.activityDate),
          (act.description || "").substring(0, 50) + (act.description?.length > 50 ? "..." : ""),
          (act.followUpNote || "").substring(0, 40) + (act.followUpNote?.length > 40 ? "..." : ""),
          formatDate(act.followUpAt),
          photoLinks.substring(0, 60) + (photoLinks.length > 60 ? "..." : ""),
        ]

        x = 50
        rowData.forEach((cell, cellIdx) => {
          const align = cellIdx === 0 ? "center" : "left"
          doc.fontSize(8).text(cell, x, doc.y, { width: colWidths[cellIdx], align })
          x += colWidths[cellIdx]
        })

        doc.moveDown(1.2)

        // Add new page if needed
        if (doc.y > 750 && idx < activities.length - 1) {
          doc.addPage()
          doc.fontSize(10).font("Helvetica-Bold")
          x = 50
          header.forEach((col, colIdx) => {
            const align = colIdx === 0 ? "center" : "left"
            doc.text(col, x, doc.y, { width: colWidths[colIdx], align })
            x += colWidths[colIdx]
          })
          doc.moveDown(0.5)
          doc.moveTo(50, doc.y).lineTo(50 + colWidths.reduce((a, b) => a + b, 0), doc.y).stroke()
          doc.moveDown(0.5)
          doc.font("Helvetica")
        }
      })

      doc.end()

      // Wait for PDF to finish
      await new Promise<void>((resolve) => {
        doc.on("end", resolve)
      })

      const pdfBuffer = Buffer.concat(chunks)

      return new Response(pdfBuffer, {
        status: 200,
        headers: {
          "Content-Type": "application/pdf",
          "Content-Disposition": `attachment; filename="${baseFilename}.pdf"`,
          "Cache-Control": "no-store",
        },
      })
    } catch (error) {
      console.error("Failed to generate PDF export", error)
      return new Response("Gagal membuat PDF. Silakan gunakan export Excel atau CSV.", {
        status: 500,
      })
    }
  }

  // Export to CSV (default fallback)
  const rows: string[] = []
  rows.push(header.map(escapeCsv).join(";"))

  ;(activities as any[]).forEach((act, index) => {
    const photoLinks = Array.isArray(act.photoUrls) ? act.photoUrls.join(", ") : ""
    const activityDate = act.activityDate ? formatDate(act.activityDate) : ""
    const followUpAt = act.followUpAt ? formatDate(act.followUpAt) : ""

    const row = [
      index + 1,
      escapeCsv(act.brokerName),
      escapeCsv(act.title),
      escapeCsv(act.clientPhone),
      escapeCsv(act.status),
      escapeCsv(activityDate),
      escapeCsv(act.description),
      escapeCsv(act.followUpNote),
      escapeCsv(followUpAt),
      escapeCsv(photoLinks),
    ].join(";")

    rows.push(row)
  })

  const csvContent = rows.join("\n")

  return new Response(csvContent, {
    status: 200,
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="${baseFilename}.csv"`,
      "Cache-Control": "no-store",
    },
  })
}
