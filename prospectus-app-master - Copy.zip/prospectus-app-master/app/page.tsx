import Image from "next/image"
import Link from "next/link"
import { BarChart3, CheckCircle2, Clock3, Shield, Users, Zap } from "lucide-react"

import { Button } from "@/components/ui/button"

const features = [
  {
    title: "Multi Role",
    desc: "Atur role (admin, supervisor, sales) dan akses menu granular.",
    icon: Users,
  },
  {
    title: "Kontrol Menu",
    desc: "Assign menu berdasarkan role dengan izin view/create/update/delete.",
    icon: Shield,
  },
  {
    title: "Absensi Masuk/Keluar",
    desc: "Catat waktu hadir dengan cepat, siap untuk rekap harian.",
    icon: Clock3,
  },
  {
    title: "Prospektus & Aktivitas",
    desc: "Input aktivitas sales, pantau status pipeline, dan progres tim.",
    icon: BarChart3,
  },
];

const steps = [
  "Buat role dan assign menu yang dibutuhkan.",
  "Undang user dan berikan role yang sesuai.",
  "Tim sales input aktivitas & absensi; supervisor pantau progres.",
];

export default function Home() {
  return (
    <div className="bg-gradient-to-b from-background via-background to-muted text-foreground">
      <header className="sticky top-0 z-20 bg-background/80 backdrop-blur border-b border-border">
        <div className="flex w-full items-center justify-between px-6 py-4 lg:px-10">
          <div className="flex items-center gap-2 font-semibold">
            <Image
              src="/logo/spartan-removebg.png"
              alt="Spartan"
              width={28}
              height={28}
              className="h-7 w-7"
              priority
            />
            <span>Spartan</span>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" asChild>
              <Link href="/login">Masuk</Link>
            </Button>
            <Button asChild>
              <Link href="/register">Daftar</Link>
            </Button>
          </div>
        </div>
      </header>

      <main className="flex min-h-screen w-full flex-col gap-16 px-6 pb-24 pt-12 lg:px-10">
        <section className="grid gap-10 lg:grid-cols-2 lg:items-center">
          <div className="space-y-6">
            <div className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1 text-xs font-medium text-primary shadow-sm">
              Solusi prospectus terpadu
            </div>
            <h1 className="text-4xl font-bold leading-tight sm:text-5xl">
              Kelola prospectus, absensi, dan akses menu dalam satu tempat bersama Spartan.
            </h1>
            <p className="text-lg text-muted-foreground">
              Bangun alur kerja yang rapi untuk tim sales: role yang jelas,
              menu yang terkontrol, catatan absensi harian, dan monitoring
              aktivitas prospek tanpa ribet.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button asChild size="lg">
                <Link href="/register">Coba sekarang</Link>
              </Button>
              <Button asChild variant="outline" size="lg">
                <Link href="/login">Saya sudah punya akun</Link>
              </Button>
            </div>
            <div className="flex flex-wrap gap-6 text-sm text-muted-foreground">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                Role & menu dinamis
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                Absensi masuk/keluar
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="h-4 w-4 text-primary" />
                Aktivitas prospectus
              </div>
            </div>
          </div>
          <div className="rounded-2xl border border-border bg-card/70 p-6 shadow-sm">
            <div className="grid gap-4 sm:grid-cols-2">
              {features.map((feature) => (
                <div
                  key={feature.title}
                  className="rounded-xl border border-border bg-muted/70 p-4"
                >
                  <div className="flex items-center gap-3">
                    <feature.icon className="h-5 w-5 text-primary" />
                    <h3 className="font-semibold">{feature.title}</h3>
                  </div>
                  <p className="mt-2 text-sm text-muted-foreground">{feature.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="rounded-2xl border border-border bg-card p-8 shadow-sm">
          <div className="flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h2 className="text-2xl font-bold">
                Langkah implementasi cepat
              </h2>
              <p className="text-muted-foreground">
                Mulai dengan konfigurasi role, lanjut onboarding user, lalu
                aktifkan alur prospectus dan absensi.
          </p>
        </div>
            <div className="flex gap-3">
              <Button asChild>
                <Link href="/register">Daftar tim</Link>
              </Button>
              <Button variant="outline" asChild>
                <Link href="/login">Masuk dashboard</Link>
              </Button>
            </div>
          </div>
          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {steps.map((step, idx) => (
              <div
                key={step}
                className="rounded-xl border border-border bg-muted/70 p-4"
          >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 text-sm font-semibold text-primary">
                    0{idx + 1}
                  </div>
                  <p className="font-medium">{step}</p>
                </div>
              </div>
            ))}
        </div>
        </section>
      </main>
    </div>
  );
}
