import Link from "next/link";
import { redirect } from "next/navigation";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { DashboardLayout } from "@/components/dashboard-layout";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { SupervisorFilterForm } from "@/components/supervisor-filter-form";

type Summary = {
  userId: string;
  name: string;
  email: string;
  roles: string[];
  attIn: number;
  attOut: number;
  prospectTotal: number;
  prospectProspect: number;
  prospectFollowUp: number;
  prospectProjection: number;
  prospectRejected: number;
  prospectCanceled: number;
};

type FilterableUser = {
  id: string;
  name: string;
};

type AttendanceRow = {
  id: string;
  user: { name: string; email: string };
  type: "IN" | "OUT";
  timestamp: Date;
  note: string | null;
  photoUrl: string;
};

type ProspectRow = {
  id: string;
  user: { name: string; email: string };
  title: string;
  status: string;
  activityDate: Date;
  photoUrls: string[];
  description: string | null;
};

function formatInputDate(value: Date) {
  const year = value.getFullYear();
  const month = `${value.getMonth() + 1}`.padStart(2, "0");
  const day = `${value.getDate()}`.padStart(2, "0");
  return `${year}-${month}-${day}`;
}

export default async function SupervisorPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const params = await searchParams;
  const session = await getSession();
  if (!session?.userId) {
    redirect("/login");
  }

  // Cek role supervisor
  const myRoles = await prisma.userRole.findMany({
    where: { userId: session.userId },
    include: { role: true },
  });
  const isSupervisor = myRoles.some(
    (r) =>
      r.role.code.toUpperCase() === "SUPERVISOR" ||
      r.role.code.toUpperCase() === "ADMIN"
  );
  if (!isSupervisor) {
    redirect("/dashboard");
  }

  // Range tanggal (default: hari ini)
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const defaultStart = today;
  const defaultEnd = new Date(today);
  defaultEnd.setHours(23, 59, 59, 999);

  const startParam = params.start;
  const endParam = params.end;
  const salesParam = params.sales;
  const selectedSalesIds = salesParam
    ? salesParam.split(",").filter(Boolean)
    : [];
  const parsedStart = startParam ? new Date(startParam) : defaultStart;
  const parsedEnd = endParam ? new Date(endParam) : defaultEnd;
  const startDate = isNaN(parsedStart.getTime()) ? defaultStart : parsedStart;
  const endDate = isNaN(parsedEnd.getTime()) ? defaultEnd : parsedEnd;
  endDate.setHours(23, 59, 59, 999);

  // Ambil semua user beserta semua roles mereka
  const allUsers = await prisma.user.findMany({
    select: {
      id: true,
      name: true,
      email: true,
      roles: {
        select: {
          role: { select: { code: true, name: true } },
        },
      },
    },
    orderBy: { name: "asc" },
  });

  // Filter user yang tidak memiliki role ADMIN atau SUPERVISOR
  const salesUsers = allUsers.filter((user) => {
    const userRoleCodes = user.roles.map((r) => r.role.code.toUpperCase());
    return (
      !userRoleCodes.includes("ADMIN") && !userRoleCodes.includes("SUPERVISOR")
    );
  });

  // Filter userId jika ada pilihan sales
  const userFilter = selectedSalesIds.length
    ? { in: selectedSalesIds }
    : undefined;

  // Aggregasi attendance
  const attAgg = await prisma.attendance.groupBy({
    by: ["userId", "type"],
    where: {
      ...(userFilter ? { userId: userFilter } : {}),
      timestamp: { gte: startDate, lte: endDate },
    },
    _count: true,
  });

  // Aggregasi prospectus
  const prospectAgg = await prisma.prospectusActivity.groupBy({
    by: ["userId", "status"],
    where: {
      ...(userFilter ? { userId: userFilter } : {}),
      activityDate: { gte: startDate, lte: endDate },
    },
    _count: true,
  });

  const attMap = new Map<string, { IN: number; OUT: number }>();
  attAgg.forEach((row) => {
    const curr = attMap.get(row.userId) || { IN: 0, OUT: 0 };
    if (row.type === "IN") curr.IN = row._count;
    if (row.type === "OUT") curr.OUT = row._count;
    attMap.set(row.userId, curr);
  });

  const prospectMap = new Map<
    string,
    { PROSPECT: number; FOLLOW_UP: number; PROJECTION: number; REJECTED: number; CANCELED: number }
  >();
  prospectAgg.forEach((row) => {
    const curr = prospectMap.get(row.userId) || {
      PROSPECT: 0,
      FOLLOW_UP: 0,
      PROJECTION: 0,
      REJECTED: 0,
      CANCELED: 0,
    };
    if (row.status === "PROSPECT") curr.PROSPECT = row._count;
    if (row.status === "FOLLOW_UP") curr.FOLLOW_UP = row._count;
    if (row.status === "PROJECTION") curr.PROJECTION = row._count;
    if (row.status === "REJECTED") curr.REJECTED = row._count;
    if (row.status === "CANCELED") curr.CANCELED = row._count;
    prospectMap.set(row.userId, curr);
  });

  const filteredUsers = selectedSalesIds.length
    ? salesUsers.filter((u) => selectedSalesIds.includes(u.id))
    : salesUsers;

  const summaries: Summary[] = filteredUsers.map((u) => {
    const att = attMap.get(u.id) || { IN: 0, OUT: 0 };
    const pr = prospectMap.get(u.id) || {
      PROSPECT: 0,
      FOLLOW_UP: 0,
      PROJECTION: 0,
      REJECTED: 0,
      CANCELED: 0,
    };
    const prospectTotal = pr.PROSPECT + pr.FOLLOW_UP + pr.PROJECTION + pr.REJECTED + pr.CANCELED;
    return {
      userId: u.id,
      name: u.name,
      email: u.email,
      roles: u.roles.map((r) => r.role.code),
      attIn: att.IN,
      attOut: att.OUT,
      prospectTotal,
      prospectProspect: pr.PROSPECT,
      prospectFollowUp: pr.FOLLOW_UP,
      prospectProjection: pr.PROJECTION,
      prospectRejected: pr.REJECTED,
      prospectCanceled: pr.CANCELED,
    };
  });

  // Detail data (dengan foto)
  const [attDetail, prospectDetail] = await Promise.all([
    prisma.attendance.findMany({
      where: {
        ...(userFilter ? { userId: userFilter } : {}),
        timestamp: { gte: startDate, lte: endDate },
      },
      include: {
        user: { select: { name: true, email: true } },
      },
      orderBy: { timestamp: "desc" },
      take: 100,
    }),
    prisma.prospectusActivity.findMany({
      where: {
        ...(userFilter ? { userId: userFilter } : {}),
        activityDate: { gte: startDate, lte: endDate },
      },
      include: {
        user: { select: { name: true, email: true } },
      },
      orderBy: { activityDate: "desc" },
      take: 100,
    }),
  ]);

  return (
    <DashboardLayout title="Supervisor Analytics">
      <div className="mx-auto max-w-6xl space-y-6">
        <div className="flex flex-col gap-1">
          <h2 className="text-2xl sm:text-3xl font-bold">
            Analisa Absensi & Prospectus
          </h2>
          <p className="text-sm sm:text-base text-slate-600">
            Ringkasan performa absensi dan aktivitas prospectus per SBC, hanya
            untuk supervisor.
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg sm:text-xl">Filter Tanggal</CardTitle>
          </CardHeader>
          <CardContent>
            <SupervisorFilterForm
              salesUsers={salesUsers}
              defaultStart={formatInputDate(startDate)}
              defaultEnd={formatInputDate(endDate)}
              defaultSelectedSales={selectedSalesIds}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg sm:text-xl">
              Ringkasan Per SBC
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[180px]">SBC</TableHead>
                    <TableHead className="min-w-[120px]">Role</TableHead>
                    <TableHead className="min-w-[90px]">IN</TableHead>
                    <TableHead className="min-w-[90px]">OUT</TableHead>
                    <TableHead className="min-w-[90px]">Prospect</TableHead>
                    <TableHead className="min-w-[180px]">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {summaries.length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={6}
                        className="text-center text-slate-500 py-8"
                      >
                        Tidak ada data
                      </TableCell>
                    </TableRow>
                  ) : (
                    summaries.map((s) => (
                      <TableRow key={s.userId}>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-semibold text-slate-800">
                              {s.name}
                            </span>
                            <span className="text-xs text-slate-500">
                              {s.email}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {s.roles.map((r) => (
                              <Badge
                                key={r}
                                variant="outline"
                                className="text-xs font-mono"
                              >
                                {r}
                              </Badge>
                            ))}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className="text-xs bg-green-50 text-green-700 border-green-200"
                          >
                            IN {s.attIn}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className="text-xs bg-slate-50 text-slate-700 border-slate-200"
                          >
                            OUT {s.attOut}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className="text-xs bg-blue-50 text-blue-700 border-blue-200"
                          >
                            Total {s.prospectTotal}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1.5">
                            {s.prospectProspect > 0 && (
                              <Badge
                                variant="outline"
                                className="text-[11px] bg-blue-50 text-blue-700 border-blue-200"
                              >
                                Prospect {s.prospectProspect}
                              </Badge>
                            )}
                            {s.prospectFollowUp > 0 && (
                              <Badge
                                variant="outline"
                                className="text-[11px] bg-amber-50 text-amber-700 border-amber-200"
                              >
                                Follow Up {s.prospectFollowUp}
                              </Badge>
                            )}
                            {s.prospectProjection > 0 && (
                              <Badge
                                variant="outline"
                                className="text-[11px] bg-green-50 text-green-700 border-green-200"
                              >
                                Projection {s.prospectProjection}
                              </Badge>
                            )}
                            {s.prospectRejected > 0 && (
                              <Badge
                                variant="outline"
                                className="text-[11px] bg-red-50 text-red-700 border-red-200"
                              >
                                Rejected {s.prospectRejected}
                              </Badge>
                            )}
                            {s.prospectCanceled > 0 && (
                              <Badge
                                variant="outline"
                                className="text-[11px] bg-rose-50 text-rose-700 border-rose-200"
                              >
                                Cancel {s.prospectCanceled}
                              </Badge>
                            )}
                            {s.prospectTotal === 0 && (
                              <span className="text-xs text-slate-400">
                                Belum ada aktivitas
                              </span>
                            )}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg sm:text-xl">
              Detail Absensi (dengan foto)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[200px]">SBC</TableHead>
                    <TableHead className="min-w-[100px]">Tipe</TableHead>
                    <TableHead className="min-w-[160px]">Waktu</TableHead>
                    <TableHead className="min-w-[120px]">Foto</TableHead>
                    <TableHead className="min-w-[180px]">Catatan</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {attDetail.length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={5}
                        className="text-center text-slate-500 py-8"
                      >
                        Tidak ada data
                      </TableCell>
                    </TableRow>
                  ) : (
                    attDetail.map((row) => (
                      <TableRow key={row.id}>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-semibold text-slate-800">
                              {row.user.name}
                            </span>
                            <span className="text-xs text-slate-500">
                              {row.user.email}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge
                            variant="outline"
                            className={
                              row.type === "IN"
                                ? "text-xs bg-green-50 text-green-700 border-green-200"
                                : "text-xs bg-slate-50 text-slate-700 border-slate-200"
                            }
                          >
                            {row.type}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-slate-700">
                          {new Intl.DateTimeFormat("id-ID", {
                            dateStyle: "medium",
                            timeStyle: "short",
                          }).format(row.timestamp)}
                        </TableCell>
                        <TableCell>
                          {row.photoUrl ? (
                            // eslint-disable-next-line @next/next/no-img-element
                            <img
                              src={row.photoUrl}
                              alt="Absensi"
                              className="h-16 w-16 rounded-md object-cover border border-slate-200 bg-slate-50"
                            />
                          ) : (
                            <span className="text-xs text-slate-400">
                              Tidak ada foto
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="text-sm text-slate-700">
                          {row.note || (
                            <span className="text-slate-400">-</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg sm:text-xl">
              Detail Prospectus (dengan foto)
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[200px]">SBC</TableHead>
                    <TableHead className="min-w-[200px]">Judul</TableHead>
                    <TableHead className="min-w-[140px]">Status</TableHead>
                    <TableHead className="min-w-[160px]">Tanggal</TableHead>
                    <TableHead className="min-w-[180px]">Foto</TableHead>
                    <TableHead className="min-w-[220px]">Deskripsi</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {prospectDetail.length === 0 ? (
                    <TableRow>
                      <TableCell
                        colSpan={6}
                        className="text-center text-slate-500 py-8"
                      >
                        Tidak ada data
                      </TableCell>
                    </TableRow>
                  ) : (
                    prospectDetail.map((row) => (
                      <TableRow key={row.id}>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-semibold text-slate-800">
                              {row.user.name}
                            </span>
                            <span className="text-xs text-slate-500">
                              {row.user.email}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="font-semibold text-slate-800">
                            {row.title}
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="outline" className="text-xs">
                            {row.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-slate-700">
                          {new Intl.DateTimeFormat("id-ID", {
                            dateStyle: "medium",
                            timeStyle: "short",
                          }).format(row.activityDate)}
                        </TableCell>
                        <TableCell>
                          {row.photoUrls?.length ? (
                            <div className="flex flex-wrap gap-2">
                              {row.photoUrls.map((url, idx) => (
                                // eslint-disable-next-line @next/next/no-img-element
                                <img
                                  key={idx}
                                  src={url}
                                  alt={`Lampiran ${idx + 1}`}
                                  className="h-16 w-16 rounded-md object-cover border border-slate-200 bg-slate-50"
                                />
                              ))}
                            </div>
                          ) : (
                            <span className="text-xs text-slate-400">
                              Tidak ada foto
                            </span>
                          )}
                        </TableCell>
                        <TableCell className="text-sm text-slate-700">
                          {row.description || (
                            <span className="text-slate-400">-</span>
                          )}
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  );
}
