import { cookies } from "next/headers"
import { NextRequest, NextResponse } from "next/server"

import { AUTH_COOKIE } from "@/lib/auth"

function buildRedirectUrl(request: NextRequest, pathname: string) {
  const host = request.headers.get("host") || request.headers.get("x-forwarded-host")
  const protocol = request.headers.get("x-forwarded-proto") || (request.nextUrl.protocol === "https:" ? "https" : "http")
  const baseUrl = process.env.NEXT_PUBLIC_BASE_URL

  if (baseUrl) return new URL(pathname, baseUrl)
  if (host) return new URL(pathname, `${protocol}://${host}`)
  const fallback = request.nextUrl.clone()
  fallback.pathname = pathname
  return fallback
}

// GET: jangan hapus cookie (hindari prefetch router yang memanggil GET)
export async function GET(request: NextRequest) {
  return NextResponse.redirect(buildRedirectUrl(request, "/login"))
}

// POST: aksi logout sesungguhnya, hapus cookie lalu redirect ke login
export async function POST(request: NextRequest) {
  const store = await cookies()
  store.delete(AUTH_COOKIE)
  return NextResponse.redirect(buildRedirectUrl(request, "/login"))
}

