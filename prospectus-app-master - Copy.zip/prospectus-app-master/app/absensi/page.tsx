import { promises as fs } from "fs"
import path from "path"
import crypto from "crypto"
import Link from "next/link"
import { redirect } from "next/navigation"

import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { DashboardLayout } from "@/components/dashboard-layout"
import { prisma } from "@/lib/prisma"
import { getSession } from "@/lib/auth"
import { AttendanceCapture } from "@/components/attendance-capture"
import { AbsensiToast } from "@/components/absensi-toast"

async function createAttendance(formData: FormData) {
  "use server"
  const type = formData.get("type")?.toString() as "IN" | "OUT" | undefined
  const note = formData.get("note")?.toString().trim() || null
  const userId = formData.get("userId")?.toString()
  const photoData = formData.get("photoData")?.toString()

  if (!userId || (type !== "IN" && type !== "OUT") || !photoData) {
    redirect("/absensi?error=invalid")
  }

  try {
    const photoUrl = await persistPhoto(photoData)

    await prisma.attendance.create({
      data: {
        userId,
        type,
        note,
        // prisma client belum di-generate ulang, cast sementara
        photoUrl,
      } as any,
    })
    redirect("/absensi?success=recorded")
  } catch (error) {
    // Biarkan redirect bawaan Next tetap melempar
    if ((error as any)?.digest?.toString().startsWith("NEXT_REDIRECT")) {
      throw error
    }
    console.error("Failed to create attendance", error)
    redirect("/absensi?error=failed")
  }
}

async function persistPhoto(dataUrl: string): Promise<string> {
  const parsed = /^data:(.+);base64,(.+)$/.exec(dataUrl)
  if (!parsed) {
    throw new Error("Invalid photo data")
  }
  const mime = parsed[1]
  const base64 = parsed[2]
  const buffer = Buffer.from(base64, "base64")

  const isJpeg = mime === "image/jpeg" || mime === "image/jpg" || mime === "image/pjpeg"
  const ext = mime === "image/png" ? "png" : isJpeg ? "jpg" : "bin"
  const filename = `${Date.now()}-${crypto.randomUUID()}.${ext}`
  const uploadDir = path.join(process.cwd(), "uploads", "attendance")
  await fs.mkdir(uploadDir, { recursive: true })
  const filePath = path.join(uploadDir, filename)
  await fs.writeFile(filePath, buffer)

  return `/api/absensi/photo/${encodeURIComponent(filename)}`
}

function formatDate(value: Date) {
  try {
    return new Intl.DateTimeFormat("id-ID", {
      dateStyle: "medium",
      timeStyle: "short",
    }).format(value)
  } catch {
    return value.toISOString()
  }
}

function formatInputDate(value: Date) {
  const year = value.getFullYear()
  const month = `${value.getMonth() + 1}`.padStart(2, "0")
  const day = `${value.getDate()}`.padStart(2, "0")
  return `${year}-${month}-${day}`
}

export default async function AbsensiPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>
}) {
  const params = await searchParams
  const session = await getSession()
  if (!session?.userId) {
    redirect("/login")
  }

  const page = Number(params.page ?? "1")
  const currentPage = Number.isFinite(page) && page > 0 ? page : 1
  const pageSize = 10

  const today = new Date()
  today.setHours(0, 0, 0, 0)
  const defaultStart = today
  const defaultEnd = new Date(today)
  defaultEnd.setHours(23, 59, 59, 999)

  const startParam = params.start
  const endParam = params.end
  const parsedStart = startParam ? new Date(startParam) : defaultStart
  const parsedEnd = endParam ? new Date(endParam) : defaultEnd
  const startDate = isNaN(parsedStart.getTime()) ? defaultStart : parsedStart
  const endDate = isNaN(parsedEnd.getTime()) ? defaultEnd : parsedEnd
  endDate.setHours(23, 59, 59, 999)

  const [[attendances, total]] = await Promise.all([
    Promise.all([
      prisma.attendance.findMany({
        where: {
          userId: session.userId,
          timestamp: {
            gte: startDate,
            lte: endDate,
          },
        },
        orderBy: { timestamp: "desc" },
        skip: (currentPage - 1) * pageSize,
        take: pageSize,
        include: {
          user: { select: { name: true, email: true } },
        },
      }),
      prisma.attendance.count({
        where: {
          userId: session.userId,
          timestamp: {
            gte: startDate,
            lte: endDate,
          },
        },
      }),
    ]),
  ])

  const totalPages = Math.max(1, Math.ceil(total / pageSize))
  const baseUrl = "/absensi"

  return (
    <DashboardLayout title="Absensi">
      <div className="mx-auto max-w-5xl space-y-6">
        <AbsensiToast
          success={
            params.success === "recorded" ? "Absensi berhasil dicatat" : undefined
          }
          error={
            params.error === "invalid"
              ? "Data tidak valid"
              : params.error === "failed"
              ? "Gagal mencatat absensi"
              : undefined
          }
        />
        <div className="flex flex-col gap-1">
          <h2 className="text-2xl sm:text-3xl font-bold">Absensi</h2>
          <p className="text-sm sm:text-base text-slate-600">
            Catat absensi masuk/keluar dan lihat riwayat Anda.
          </p>
        </div>

        <div className="grid gap-4 sm:gap-6 lg:grid-cols-2">
          <AttendanceCapture userId={session.userId} type="IN" action={createAttendance} />
          <AttendanceCapture userId={session.userId} type="OUT" action={createAttendance} />
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg sm:text-xl">Filter Riwayat</CardTitle>
          </CardHeader>
          <CardContent>
            <form className="grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Dari tanggal</label>
                <input
                  type="date"
                  name="start"
                  defaultValue={formatInputDate(startDate)}
                  className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                />
              </div>
              <div className="space-y-2">
                <label className="text-sm font-medium text-slate-700">Sampai tanggal</label>
                <input
                  type="date"
                  name="end"
                  defaultValue={formatInputDate(endDate)}
                  className="h-10 w-full rounded-md border border-input bg-background px-3 text-sm"
                />
              </div>
              <div className="flex gap-2 sm:justify-end">
                <Button type="submit" className="w-full sm:w-auto">
                  Terapkan
                </Button>
                <Button variant="ghost" asChild className="w-full sm:w-auto">
                  <a href={baseUrl}>Reset</a>
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg sm:text-xl">Riwayat Absensi</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="min-w-[80px]">Tipe</TableHead>
                    <TableHead className="min-w-[180px]">Waktu</TableHead>
                      <TableHead>Foto</TableHead>
                      <TableHead>Catatan</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {attendances.length === 0 ? (
                    <TableRow>
                        <TableCell colSpan={4} className="text-center text-slate-500 py-8">
                        Belum ada data absensi
                      </TableCell>
                    </TableRow>
                  ) : (
                    attendances.map((a) => {
                      const photoUrl = (a as any).photoUrl as string | undefined
                      const hasPhoto = !!photoUrl
                      return (
                      <TableRow key={a.id}>
                        <TableCell>
                          <Badge
                            variant={a.type === "IN" ? "outline" : "secondary"}
                            className={
                              a.type === "IN"
                                ? "border-green-200 text-green-700 bg-green-50"
                                : "border-slate-200 text-slate-700 bg-slate-50"
                            }
                          >
                            {a.type === "IN" ? "Masuk" : "Keluar"}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-slate-700">
                          {formatDate(a.timestamp)}
                        </TableCell>
                        <TableCell>
                          {hasPhoto ? (
                            <img
                              src={photoUrl}
                              alt={`Absensi ${a.type}`}
                              className="h-14 w-14 rounded-md object-cover border border-slate-200 bg-slate-50"
                            />
                          ) : (
                            <span className="text-xs text-slate-400">Tidak ada foto</span>
                          )}
                          </TableCell>
                        <TableCell className="text-sm text-slate-600">
                          {a.note || <span className="text-slate-400">-</span>}
                        </TableCell>
                      </TableRow>
                      )
                    })
                  )}
                </TableBody>
              </Table>
            </div>
            <div className="mt-4 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-sm text-slate-600">
              <span>
                Menampilkan {attendances.length} dari {total} data (halaman {currentPage} /{" "}
                {totalPages})
              </span>
              <div className="flex items-center gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage <= 1}
                >
                  <Link href={`${baseUrl}?page=${currentPage - 1}`} prefetch>
                    Sebelumnya
                  </Link>
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  disabled={currentPage >= totalPages}
                >
                  <Link href={`${baseUrl}?page=${currentPage + 1}`} prefetch>
                    Berikutnya
                  </Link>
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

