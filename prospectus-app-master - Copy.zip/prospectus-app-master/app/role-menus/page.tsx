import { Shield, Search } from "lucide-react";

import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";
import { AssignMenuForm } from "@/components/assign-menu-form";
import { DeleteConfirmDialog } from "@/components/delete-confirm-dialog";
import { DashboardLayout } from "@/components/dashboard-layout";
import { prisma } from "@/lib/prisma";

async function assignMenuToRole(formData: FormData) {
  "use server";
  const roleId = formData.get("roleId")?.toString();
  const menuId = formData.get("menuId")?.toString();
  const canView = formData.get("canView") === "true";
  const canCreate = formData.get("canCreate") === "true";
  const canUpdate = formData.get("canUpdate") === "true";
  const canDelete = formData.get("canDelete") === "true";

  if (!roleId || !menuId) {
    return { success: false, error: "invalid" };
  }

  try {
    await prisma.roleMenu.upsert({
      where: {
        roleId_menuId: { roleId, menuId },
      },
      create: {
        roleId,
        menuId,
        canView,
        canCreate,
        canUpdate,
        canDelete,
      },
      update: {
        canView,
        canCreate,
        canUpdate,
        canDelete,
      },
    });
    return { success: true };
  } catch (error: any) {
    return { success: false, error: "failed" };
  }
}

async function removeRoleMenu(formData: FormData) {
  "use server";
  const id = formData.get("id")?.toString();
  if (!id) return { success: false, error: "invalid" };

  try {
    await prisma.roleMenu.delete({ where: { id } });
    return { success: true };
  } catch {
    return { success: false, error: "remove_failed" };
  }
}

export default async function RoleMenusPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; success?: string }>;
}) {
  const params = await searchParams;

  const [roles, menus, roleMenus] = await Promise.all([
    prisma.role.findMany({ orderBy: { code: "asc" } }),
    prisma.menu.findMany({
      orderBy: [{ order: "asc" }, { name: "asc" }],
      where: { isActive: true },
    }),
    prisma.roleMenu.findMany({
      include: {
        role: { select: { id: true, code: true, name: true } },
        menu: { select: { id: true, name: true, path: true, icon: true } },
      },
      orderBy: [
        { role: { code: "asc" } },
        { menu: { order: "asc" } },
      ],
    }),
  ]);

  // Group by role untuk tampilan yang lebih baik
  const roleMenusByRole = roleMenus.reduce(
    (acc, rm) => {
      const roleCode = rm.role.code;
      if (!acc[roleCode]) {
        acc[roleCode] = {
          role: rm.role,
          menus: [],
        };
      }
      acc[roleCode].menus.push(rm);
      return acc;
    },
    {} as Record<
      string,
      {
        role: { id: string; code: string; name: string };
        menus: typeof roleMenus;
      }
    >
  );

  return (
    <DashboardLayout title="Assign Menu ke Role">
      <div className="mx-auto max-w-7xl space-y-4 sm:space-y-6">
        <div className="space-y-1">
          <h2 className="text-2xl sm:text-3xl font-bold">
            Assign Menu ke Role
          </h2>
          <p className="text-sm sm:text-base text-slate-600">
            Kelola akses menu untuk setiap role dengan kontrol permission CRUD
          </p>
        </div>

        {params.error && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-3 sm:p-4 text-sm sm:text-base text-red-800">
            {params.error === "invalid" && "Data tidak valid"}
            {params.error === "remove_failed" && "Gagal menghapus assign"}
            {params.error === "failed" && "Terjadi kesalahan"}
          </div>
        )}

        {params.success && (
          <div className="rounded-lg border border-green-200 bg-green-50 p-3 sm:p-4 text-sm sm:text-base text-green-800">
            {params.success === "assigned" && "Menu berhasil di-assign"}
            {params.success === "removed" && "Assign berhasil dihapus"}
          </div>
        )}

        {/* Quick Assign Form */}
        <Card>
          <CardHeader className="pb-4">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
              <div>
                <CardTitle className="text-lg sm:text-xl">
                  Assign Menu Baru
                </CardTitle>
                <CardDescription className="text-xs sm:text-sm">
                  Pilih role dan menu, lalu set permission yang diizinkan
                </CardDescription>
              </div>
              <AssignMenuForm
                menus={menus.map((m) => ({
                  id: m.id,
                  name: m.name,
                  path: m.path,
                }))}
                roles={roles}
                action={assignMenuToRole}
              />
            </div>
          </CardHeader>
        </Card>

        {/* List Role Menus */}
        <div className="space-y-4">
          {Object.keys(roleMenusByRole).length === 0 ? (
            <Card>
              <CardContent className="py-12">
                <div className="text-center text-slate-500">
                  <Shield className="h-12 w-12 mx-auto mb-4 text-slate-300" />
                  <p className="text-lg font-medium mb-2">
                    Belum ada menu yang di-assign
                  </p>
                  <p className="text-sm">
                    Klik tombol "Assign Menu" di atas untuk mulai assign menu ke
                    role
                  </p>
                </div>
              </CardContent>
            </Card>
          ) : (
            Object.values(roleMenusByRole).map(({ role, menus: roleMenusList }) => (
              <Card key={role.id}>
                <CardHeader className="pb-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline" className="font-mono text-sm">
                        {role.code}
                      </Badge>
                      <div>
                        <CardTitle className="text-base sm:text-lg">
                          {role.name}
                        </CardTitle>
                        <CardDescription className="text-xs sm:text-sm">
                          {roleMenusList.length} menu di-assign
                        </CardDescription>
                      </div>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="min-w-[200px]">Menu</TableHead>
                          <TableHead className="min-w-[250px]">Path</TableHead>
                          <TableHead className="min-w-[200px]">Permissions</TableHead>
                          <TableHead className="w-[80px] sm:w-[100px]">Aksi</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {roleMenusList.map((rm) => (
                          <TableRow key={rm.id}>
                            <TableCell>
                              <div className="flex items-center gap-2">
                                {rm.menu.icon && (
                                  <Badge variant="outline" className="text-xs">
                                    {rm.menu.icon}
                                  </Badge>
                                )}
                                <span className="font-medium">{rm.menu.name}</span>
                              </div>
                            </TableCell>
                            <TableCell>
                              <code className="text-xs text-slate-600 bg-slate-50 px-2 py-1 rounded">
                                {rm.menu.path}
                              </code>
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-wrap gap-1.5">
                                {rm.canView && (
                                  <Badge
                                    variant="outline"
                                    className="text-xs bg-green-50 text-green-700 border-green-200"
                                  >
                                    View
                                  </Badge>
                                )}
                                {rm.canCreate && (
                                  <Badge
                                    variant="outline"
                                    className="text-xs bg-blue-50 text-blue-700 border-blue-200"
                                  >
                                    Create
                                  </Badge>
                                )}
                                {rm.canUpdate && (
                                  <Badge
                                    variant="outline"
                                    className="text-xs bg-yellow-50 text-yellow-700 border-yellow-200"
                                  >
                                    Update
                                  </Badge>
                                )}
                                {rm.canDelete && (
                                  <Badge
                                    variant="outline"
                                    className="text-xs bg-red-50 text-red-700 border-red-200"
                                  >
                                    Delete
                                  </Badge>
                                )}
                                {!rm.canView &&
                                  !rm.canCreate &&
                                  !rm.canUpdate &&
                                  !rm.canDelete && (
                                    <span className="text-xs text-slate-400">
                                      Tidak ada permission
                                    </span>
                                  )}
                              </div>
                            </TableCell>
                            <TableCell>
                            <DeleteConfirmDialog
                              title="Hapus Assign Menu"
                              description={`Apakah Anda yakin ingin menghapus akses menu "${rm.menu.name}" dari role "${role.name}"?`}
                              action={removeRoleMenu}
                              id={rm.id}
                              successMessage="Assign berhasil dihapus"
                              errorMessage="Gagal menghapus assign"
                            />
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </DashboardLayout>
  );
}

