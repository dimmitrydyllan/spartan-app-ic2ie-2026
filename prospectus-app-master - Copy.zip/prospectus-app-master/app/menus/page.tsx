import Link from "next/link";
import { Badge } from "@/components/ui/badge";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { AssignMenuForm } from "@/components/assign-menu-form";
import { CreateMenuForm } from "@/components/create-menu-form";
import { EditMenuForm } from "@/components/edit-menu-form";
import { DeleteConfirmDialog } from "@/components/delete-confirm-dialog";
import { DashboardLayout } from "@/components/dashboard-layout";
import { prisma } from "@/lib/prisma";
import { getSession } from "@/lib/auth";
import { hasPermission, getUserMenuPermission } from "@/lib/permission";

async function createMenu(formData: FormData) {
  "use server";
  const session = await getSession();
  if (!session?.userId) {
    return { success: false, error: "unauthorized" };
  }

  // Check permission
  const canCreate = await hasPermission(session.userId, "/menus", "create");
  if (!canCreate) {
    return { success: false, error: "forbidden" };
  }

  const name = formData.get("name")?.toString().trim();
  const path = formData.get("path")?.toString().trim();
  const icon = formData.get("icon")?.toString().trim() || null;
  const parentIdRaw = formData.get("parentId")?.toString().trim();
  const parentId = parentIdRaw && parentIdRaw !== "none" ? parentIdRaw : null;
  const order = parseInt(formData.get("order")?.toString() || "0");

  if (!name || !path) {
    return { success: false, error: "invalid" };
  }

  try {
    await prisma.menu.create({
      data: {
        name,
        path,
        icon,
        parentId,
        order,
        isActive: true,
      },
    });
    return { success: true };
  } catch (error: any) {
    return {
      success: false,
      error: error.code === "P2002" ? "duplicate" : "failed",
    };
  }
}

async function updateMenu(formData: FormData) {
  "use server";
  const session = await getSession();
  if (!session?.userId) {
    return { success: false, error: "unauthorized" };
  }

  // Check permission
  const canUpdate = await hasPermission(session.userId, "/menus", "update");
  if (!canUpdate) {
    return { success: false, error: "forbidden" };
  }

  const id = formData.get("id")?.toString();
  const name = formData.get("name")?.toString().trim();
  const path = formData.get("path")?.toString().trim();
  const icon = formData.get("icon")?.toString().trim() || null;
  const parentIdRaw = formData.get("parentId")?.toString().trim();
  const parentId = parentIdRaw && parentIdRaw !== "none" ? parentIdRaw : null;
  const order = parseInt(formData.get("order")?.toString() || "0");

  if (!id || !name || !path) {
    return { success: false, error: "invalid" };
  }

  try {
    await prisma.menu.update({
      where: { id },
      data: {
        name,
        path,
        icon,
        parentId,
        order,
      },
    });
    return { success: true };
  } catch (error: any) {
    if (error.code === "P2025") {
      return { success: false, error: "not_found" };
    }
    return {
      success: false,
      error: error.code === "P2002" ? "duplicate" : "failed",
    };
  }
}

async function deleteMenu(formData: FormData) {
  "use server";
  const session = await getSession();
  if (!session?.userId) {
    return { success: false, error: "unauthorized" };
  }

  // Check permission
  const canDelete = await hasPermission(session.userId, "/menus", "delete");
  if (!canDelete) {
    return { success: false, error: "forbidden" };
  }

  const id = formData.get("id")?.toString();
  if (!id) return { success: false, error: "invalid" };

  try {
    // Check if menu exists and has children
    const menu = await prisma.menu.findUnique({
      where: { id },
      include: {
        children: { select: { id: true } },
      },
    });

    if (!menu) {
      return { success: false, error: "not_found" };
    }

    // Check if menu has children
    if (menu.children.length > 0) {
      return { success: false, error: "has_children" };
    }

    // Delete related RoleMenu entries first (if any)
    await prisma.roleMenu.deleteMany({
      where: { menuId: id },
    });

    // Delete the menu
    await prisma.menu.delete({ where: { id } });
    return { success: true };
  } catch (error: any) {
    console.error("Error deleting menu:", error);
    if (error.code === "P2025") {
      return { success: false, error: "not_found" };
    }
    return { success: false, error: "delete_failed" };
  }
}

async function assignMenuToRole(formData: FormData) {
  "use server";
  const roleId = formData.get("roleId")?.toString();
  const menuId = formData.get("menuId")?.toString();
  const canView = formData.get("canView") === "true";
  const canCreate = formData.get("canCreate") === "true";
  const canUpdate = formData.get("canUpdate") === "true";
  const canDelete = formData.get("canDelete") === "true";

  if (!roleId || !menuId) {
    return { success: false, error: "invalid" };
  }

  try {
    await prisma.roleMenu.upsert({
      where: {
        roleId_menuId: { roleId, menuId },
      },
      create: {
        roleId,
        menuId,
        canView,
        canCreate,
        canUpdate,
        canDelete,
      },
      update: {
        canView,
        canCreate,
        canUpdate,
        canDelete,
      },
    });
    return { success: true };
  } catch (error: any) {
    return { success: false, error: "failed" };
  }
}

async function removeRoleMenu(formData: FormData) {
  "use server";
  const id = formData.get("id")?.toString();
  if (!id) return { success: false, error: "invalid" };

  try {
    await prisma.roleMenu.delete({ where: { id } });
    return { success: true };
  } catch {
    return { success: false, error: "remove_failed" };
  }
}

export default async function MenusPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | undefined>>;
}) {
  const params = await searchParams;
  const page = Number(params.page ?? "1");
  const currentPage = Number.isFinite(page) && page > 0 ? page : 1;
  const pageSize = 10;

  const rmPageParam = Number(params.rmPage ?? "1");
  const rmCurrentPage =
    Number.isFinite(rmPageParam) && rmPageParam > 0 ? rmPageParam : 1;
  const rmPageSize = 10;

  const [[menus, totalMenus], roles, [roleMenus, totalRoleMenus]] =
    await Promise.all([
      Promise.all([
        prisma.menu.findMany({
          orderBy: [{ order: "asc" }, { name: "asc" }],
          skip: (currentPage - 1) * pageSize,
          take: pageSize,
          include: {
            parent: { select: { id: true, name: true } },
            children: { select: { id: true, name: true } },
          },
        }),
        prisma.menu.count(),
      ]),
      prisma.role.findMany({ orderBy: { code: "asc" } }),
      Promise.all([
        prisma.roleMenu.findMany({
          include: {
            role: { select: { id: true, code: true, name: true } },
            menu: { select: { id: true, name: true, path: true } },
          },
          orderBy: [
            { role: { code: "asc" } },
            { menu: { order: "asc" } },
            { menu: { name: "asc" } },
          ],
          skip: (rmCurrentPage - 1) * rmPageSize,
          take: rmPageSize,
        }),
        prisma.roleMenu.count(),
      ]),
    ]);

  const rootMenus = menus.filter((m) => !m.parentId);
  const totalPages = Math.max(1, Math.ceil(totalMenus / pageSize));
  const baseUrl = "/menus";
  const rmTotalPages = Math.max(1, Math.ceil(totalRoleMenus / rmPageSize));
  const rmBaseUrl = "/menus";

  // Get user permissions
  const session = await getSession();
  const permissions = session?.userId
    ? await getUserMenuPermission(session.userId, "/menus")
    : {
        canView: false,
        canCreate: false,
        canUpdate: false,
        canDelete: false,
      };

  return (
    <DashboardLayout title="Master Menu & Assign Menu">
      <div className="mx-auto max-w-7xl space-y-4 sm:space-y-6 px-4 sm:px-6">
        <div className="space-y-1">
          <h2 className="text-xl sm:text-2xl md:text-3xl font-bold">
            Master Menu & Assign Menu
          </h2>
          <p className="text-xs sm:text-sm md:text-base text-slate-600">
            Kelola menu dan assign menu ke role dengan kontrol akses
          </p>
        </div>

        {params.error && (
          <div className="rounded-lg border border-red-200 bg-red-50 p-3 sm:p-4 text-xs sm:text-sm md:text-base text-red-800">
            {params.error === "duplicate" && "Menu path sudah ada"}
            {params.error === "delete_failed" && "Gagal menghapus menu"}
            {params.error === "remove_failed" && "Gagal menghapus assign"}
            {params.error === "invalid" && "Data tidak valid"}
            {params.error === "failed" && "Terjadi kesalahan"}
          </div>
        )}

        {params.success && (
          <div className="rounded-lg border border-green-200 bg-green-50 p-3 sm:p-4 text-xs sm:text-sm md:text-base text-green-800">
            {params.success === "created" && "Menu berhasil dibuat"}
            {params.success === "deleted" && "Menu berhasil dihapus"}
            {params.success === "assigned" && "Menu berhasil di-assign"}
            {params.success === "removed" && "Assign berhasil dihapus"}
          </div>
        )}

        <div className="grid gap-4 sm:gap-6 lg:grid-cols-2">
          {/* Master Menu */}
          <Card>
            <CardHeader className="pb-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <CardTitle className="text-base sm:text-lg md:text-xl">
                    Master Menu
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Tambah dan kelola menu aplikasi
                  </CardDescription>
                </div>
                {permissions.canCreate && (
                  <CreateMenuForm rootMenus={rootMenus} action={createMenu} />
                )}
              </div>
            </CardHeader>
            <CardContent>
              {/* Desktop Table View */}
              <div className="hidden md:block overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[150px]">Nama</TableHead>
                      <TableHead className="min-w-[150px]">Path</TableHead>
                      <TableHead className="min-w-[80px]">Icon</TableHead>
                      <TableHead className="w-[80px] sm:w-[100px]">
                        Aksi
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {menus.length === 0 ? (
                      <TableRow>
                        <TableCell
                          colSpan={4}
                          className="text-center text-slate-500 py-8"
                        >
                          Belum ada menu
                        </TableCell>
                      </TableRow>
                    ) : (
                      menus.map((menu) => (
                        <TableRow key={menu.id}>
                          <TableCell className="font-medium">
                            {menu.parent && (
                              <span className="text-slate-400 mr-2">└─</span>
                            )}
                            {menu.name}
                          </TableCell>
                          <TableCell className="text-sm text-slate-600 font-mono">
                            {menu.path}
                          </TableCell>
                          <TableCell>
                            {menu.icon ? (
                              <Badge variant="outline" className="text-xs">
                                {menu.icon}
                              </Badge>
                            ) : (
                              <span className="text-slate-400">-</span>
                            )}
                          </TableCell>
                          <TableCell>
                            <div className="flex items-center gap-2">
                              {permissions.canUpdate && (
                                <EditMenuForm
                                  menu={menu}
                                  rootMenus={rootMenus}
                                  action={updateMenu}
                                />
                              )}
                              {permissions.canDelete && (
                                <div className="flex items-center gap-2">
                                  {permissions.canDelete && (
                                    <DeleteConfirmDialog
                                      title="Hapus Menu"
                                      description={`Apakah Anda yakin ingin menghapus menu "${menu.name}"? Tindakan ini tidak dapat dibatalkan.`}
                                      action={deleteMenu}
                                      id={menu.id}
                                      successMessage="Menu berhasil dihapus"
                                      errorMessage="Gagal menghapus menu"
                                    />
                                  )}
                                </div>
                              )}
                            </div>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
              {/* Mobile Card View */}
              <div className="md:hidden space-y-3">
                {menus.length === 0 ? (
                  <div className="text-center text-slate-500 py-8">
                    Belum ada menu
                  </div>
                ) : (
                  menus.map((menu) => (
                    <div
                      key={menu.id}
                      className="border rounded-lg p-3 space-y-2 bg-slate-50"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="font-medium text-sm flex items-center gap-1">
                            {menu.parent && (
                              <span className="text-slate-400">└─</span>
                            )}
                            <span className="truncate">{menu.name}</span>
                          </div>
                          <div className="text-xs text-slate-600 font-mono mt-1 break-all">
                            {menu.path}
                          </div>
                        </div>
                        <DeleteConfirmDialog
                          title="Hapus Menu"
                          description={`Apakah Anda yakin ingin menghapus menu "${menu.name}"? Tindakan ini tidak dapat dibatalkan.`}
                          action={deleteMenu}
                          id={menu.id}
                        />
                      </div>
                      {menu.icon && (
                        <div>
                          <Badge variant="outline" className="text-xs">
                            {menu.icon}
                          </Badge>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>
              <div className="mt-4 flex flex-col gap-3 text-xs sm:text-sm text-slate-600">
                <div className="text-center sm:text-left">
                  Menampilkan {menus.length} dari {totalMenus} menu (halaman{" "}
                  {currentPage} / {totalPages})
                </div>
                <div className="flex items-center justify-center sm:justify-end gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={currentPage <= 1}
                    asChild
                  >
                    <Link href={`${baseUrl}?page=${currentPage - 1}`} prefetch>
                      Sebelumnya
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={currentPage >= totalPages}
                    asChild
                  >
                    <Link href={`${baseUrl}?page=${currentPage + 1}`} prefetch>
                      Berikutnya
                    </Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Assign Menu ke Role */}
          <Card>
            <CardHeader className="pb-4">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
                <div>
                  <CardTitle className="text-base sm:text-lg md:text-xl">
                    Assign Menu ke Role
                  </CardTitle>
                  <CardDescription className="text-xs sm:text-sm">
                    Berikan akses menu kepada role dengan kontrol CRUD
                  </CardDescription>
                </div>
                <AssignMenuForm
                  menus={menus.map((m) => ({
                    id: m.id,
                    name: m.name,
                    path: m.path,
                  }))}
                  roles={roles}
                  action={assignMenuToRole}
                />
              </div>
            </CardHeader>
            <CardContent>
              {/* Desktop Table View */}
              <div className="hidden md:block overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead className="min-w-[150px]">Role</TableHead>
                      <TableHead className="min-w-[150px]">Menu</TableHead>
                      <TableHead className="min-w-[200px]">Izin</TableHead>
                      <TableHead className="w-[80px] sm:w-[100px]">
                        Aksi
                      </TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {roleMenus.length === 0 ? (
                      <TableRow>
                        <TableCell
                          colSpan={4}
                          className="text-center text-slate-500 py-8"
                        >
                          Belum ada menu yang di-assign
                        </TableCell>
                      </TableRow>
                    ) : (
                      roleMenus.map((rm) => (
                        <TableRow key={rm.id}>
                          <TableCell>
                            <div className="flex flex-col gap-1">
                              <Badge
                                variant="outline"
                                className="font-mono text-xs w-fit"
                              >
                                {rm.role.code}
                              </Badge>
                              <span className="text-sm text-slate-600">
                                {rm.role.name}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-col">
                              <span className="font-medium">
                                {rm.menu.name}
                              </span>
                              <span className="text-xs text-slate-500 font-mono">
                                {rm.menu.path}
                              </span>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="flex flex-wrap gap-1.5">
                              {rm.canView && (
                                <Badge
                                  variant="outline"
                                  className="text-xs bg-green-50 text-green-700 border-green-200"
                                >
                                  View
                                </Badge>
                              )}
                              {rm.canCreate && (
                                <Badge
                                  variant="outline"
                                  className="text-xs bg-blue-50 text-blue-700 border-blue-200"
                                >
                                  Create
                                </Badge>
                              )}
                              {rm.canUpdate && (
                                <Badge
                                  variant="outline"
                                  className="text-xs bg-yellow-50 text-yellow-700 border-yellow-200"
                                >
                                  Update
                                </Badge>
                              )}
                              {rm.canDelete && (
                                <Badge
                                  variant="outline"
                                  className="text-xs bg-red-50 text-red-700 border-red-200"
                                >
                                  Delete
                                </Badge>
                              )}
                            </div>
                          </TableCell>
                          <TableCell>
                            <DeleteConfirmDialog
                              title="Hapus Assign Menu"
                              description={`Apakah Anda yakin ingin menghapus akses menu "${rm.menu.name}" dari role "${rm.role.name}"?`}
                              action={removeRoleMenu}
                              id={rm.id}
                              successMessage="Assign berhasil dihapus"
                              errorMessage="Gagal menghapus assign"
                            />
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </div>
              {/* Mobile Card View */}
              <div className="md:hidden space-y-3">
                {roleMenus.length === 0 ? (
                  <div className="text-center text-slate-500 py-8">
                    Belum ada menu yang di-assign
                  </div>
                ) : (
                  roleMenus.map((rm) => (
                    <div
                      key={rm.id}
                      className="border rounded-lg p-3 space-y-2 bg-slate-50"
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex-1 min-w-0">
                          <div className="flex flex-col gap-1 mb-2">
                            <Badge
                              variant="outline"
                              className="font-mono text-xs w-fit"
                            >
                              {rm.role.code}
                            </Badge>
                            <span className="text-sm font-medium text-slate-700">
                              {rm.role.name}
                            </span>
                          </div>
                          <div className="flex flex-col gap-1">
                            <span className="font-medium text-sm">
                              {rm.menu.name}
                            </span>
                            <span className="text-xs text-slate-500 font-mono break-all">
                              {rm.menu.path}
                            </span>
                          </div>
                        </div>
                        <DeleteConfirmDialog
                          title="Hapus Assign Menu"
                          description={`Apakah Anda yakin ingin menghapus akses menu "${rm.menu.name}" dari role "${rm.role.name}"?`}
                          action={removeRoleMenu}
                          id={rm.id}
                        />
                      </div>
                      <div className="flex flex-wrap gap-1.5">
                        {rm.canView && (
                          <Badge
                            variant="outline"
                            className="text-xs bg-green-50 text-green-700 border-green-200"
                          >
                            View
                          </Badge>
                        )}
                        {rm.canCreate && (
                          <Badge
                            variant="outline"
                            className="text-xs bg-blue-50 text-blue-700 border-blue-200"
                          >
                            Create
                          </Badge>
                        )}
                        {rm.canUpdate && (
                          <Badge
                            variant="outline"
                            className="text-xs bg-yellow-50 text-yellow-700 border-yellow-200"
                          >
                            Update
                          </Badge>
                        )}
                        {rm.canDelete && (
                          <Badge
                            variant="outline"
                            className="text-xs bg-red-50 text-red-700 border-red-200"
                          >
                            Delete
                          </Badge>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
              <div className="mt-4 flex flex-col gap-3 text-xs sm:text-sm text-slate-600">
                <div className="text-center sm:text-left">
                  Menampilkan {roleMenus.length} dari {totalRoleMenus} assign
                  (halaman {rmCurrentPage} / {rmTotalPages})
                </div>
                <div className="flex items-center justify-center sm:justify-end gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={rmCurrentPage <= 1}
                    asChild
                  >
                    <Link
                      href={`${rmBaseUrl}?page=${currentPage}&rmPage=${
                        rmCurrentPage - 1
                      }`}
                      prefetch
                    >
                      Sebelumnya
                    </Link>
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    disabled={rmCurrentPage >= rmTotalPages}
                    asChild
                  >
                    <Link
                      href={`${rmBaseUrl}?page=${currentPage}&rmPage=${
                        rmCurrentPage + 1
                      }`}
                      prefetch
                    >
                      Berikutnya
                    </Link>
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardLayout>
  );
}
