import { promises as fs } from "fs"
import path from "path"
import crypto from "crypto"
import { redirect } from "next/navigation"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { DashboardLayout } from "@/components/dashboard-layout"
import { prisma } from "@/lib/prisma"
import { getSession } from "@/lib/auth"
import { ProfileForm } from "@/components/profile-form"

async function updateProfile(formData: FormData) {
  "use server"
  const session = await getSession()
  if (!session?.userId) {
    redirect("/login")
  }

  const name = formData.get("name")?.toString().trim()
  const photoDataUrl = formData.get("photo")?.toString()

  if (!name) {
    return { success: false, error: "Nama wajib diisi" }
  }

  try {
    let photoUrl: string | null = null

    // Handle photo upload if provided
    if (photoDataUrl) {
      const parsed = /^data:(.+);base64,(.+)$/.exec(photoDataUrl)
      if (parsed) {
        const mime = parsed[1]
        const base64 = parsed[2]
        const buffer = Buffer.from(base64, "base64")

        const isJpeg = mime === "image/jpeg" || mime === "image/jpg" || mime === "image/pjpeg"
        const ext = mime === "image/png" ? "png" : isJpeg ? "jpg" : "bin"

        const uploadDir = path.join(process.cwd(), "uploads", "profile")
        await fs.mkdir(uploadDir, { recursive: true })

        // Delete old photo if exists
        const existingUser = await prisma.user.findUnique({
          where: { id: session.userId },
          select: { photoUrl: true },
        })

        if (existingUser?.photoUrl) {
          try {
            const oldFileName = existingUser.photoUrl.split("/").pop()
            if (oldFileName) {
              const oldFilePath = path.join(uploadDir, decodeURIComponent(oldFileName))
              await fs.unlink(oldFilePath).catch(() => {
                // Ignore if file doesn't exist
              })
            }
          } catch {
            // Ignore errors when deleting old photo
          }
        }

        const filename = `${Date.now()}-${crypto.randomUUID()}.${ext}`
        const filePath = path.join(uploadDir, filename)
        await fs.writeFile(filePath, buffer)
        photoUrl = `/api/profile/photo/${encodeURIComponent(filename)}`
      }
    }

    // Update user
    await prisma.user.update({
      where: { id: session.userId },
      data: {
        name,
        ...(photoUrl && { photoUrl }),
      },
    })

    return { success: true }
  } catch (error) {
    console.error("Failed to update profile", error)
    return { success: false, error: "Gagal memperbarui profil" }
  }
}

export default async function ProfilePage() {
  const session = await getSession()
  if (!session?.userId) {
    redirect("/login")
  }

  const user = await prisma.user.findUnique({
    where: { id: session.userId },
    select: {
      id: true,
      email: true,
      name: true,
      photoUrl: true,
      createdAt: true,
    },
  })

  if (!user) {
    redirect("/login")
  }

  return (
    <DashboardLayout title="Profile">
      <div className="mx-auto max-w-2xl space-y-6">
        <div className="space-y-1">
          <h2 className="text-2xl sm:text-3xl font-bold">Profile Saya</h2>
          <p className="text-sm sm:text-base text-slate-600">
            Kelola informasi profil dan foto profil Anda
          </p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg sm:text-xl">Informasi Profil</CardTitle>
          </CardHeader>
          <CardContent>
            <ProfileForm user={user} action={updateProfile} />
          </CardContent>
        </Card>
      </div>
    </DashboardLayout>
  )
}

