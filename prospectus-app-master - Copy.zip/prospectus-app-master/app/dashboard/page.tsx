import { redirect } from "next/navigation";

import { getSession } from "@/lib/auth";
import { isSupervisorOrAdmin, isSales } from "@/lib/role";
import { SalesDashboard } from "@/components/dashboard/sales-dashboard";
import { AdminDashboard } from "@/components/dashboard/admin-dashboard";

export default async function DashboardPage() {
  const session = await getSession();
  console.log("session", session);
  if (!session?.userId) {
    redirect("/login");
  }

  // Check user role
  const [isAdmin, isSalesUser] = await Promise.all([
    isSupervisorOrAdmin(session.userId),
    isSales(session.userId),
  ]);

  // Render different dashboard based on role
  if (isAdmin) {
    return <AdminDashboard userId={session.userId} />;
  }

  if (isSalesUser) {
    return <SalesDashboard userId={session.userId} />;
  }

  // Default dashboard for other roles
  return <SalesDashboard userId={session.userId} />;
}
