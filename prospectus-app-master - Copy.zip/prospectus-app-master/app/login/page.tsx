import Link from "next/link"
import { redirect } from "next/navigation"
import bcrypt from "bcryptjs"

import { Input } from "@/components/ui/input"
import { createSession, getSession } from "@/lib/auth"
import { prisma } from "@/lib/prisma"
import { LoginForm } from "@/components/login-form"

async function handleLogin(formData: FormData) {
  "use server"
  const email = formData.get("email")?.toString().trim()
  const password = formData.get("password")?.toString()

  if (!email || !password) {
    throw new Error("Email dan password wajib diisi")
  }

  const user = await prisma.user.findUnique({
    where: { email },
  })

  if (!user) {
    throw new Error("Email atau password salah")
  }

  const isValid = await bcrypt.compare(password, user.password)
  if (!isValid) {
    throw new Error("Email atau password salah")
  }

  await createSession({
    token: crypto.randomUUID(),
    email: user.email,
    userId: user.id,
    name: user.name,
  })

  redirect("/dashboard")
}

export default async function LoginPage() {
  const session = await getSession()
  if (session) {
    redirect("/dashboard")
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-background via-background to-muted text-foreground">
      <div className="mx-auto flex min-h-screen max-w-4xl flex-col justify-center px-6 py-12">
        <div className="mb-10">
          <Link href="/" className="text-sm text-primary hover:underline">
            ← Kembali ke landing
          </Link>
        </div>
        <div className="grid gap-10 rounded-2xl border border-border bg-card p-8 shadow-sm lg:grid-cols-2">
          <div className="space-y-4">
            <p className="text-sm font-semibold text-primary">Spartan</p>
            <h1 className="text-3xl font-bold leading-tight">
              Masuk ke dashboard
            </h1>
            <p className="text-muted-foreground">
              Kelola prospectus, absensi, dan kontrol akses role dalam satu
              dashboard.
            </p>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li>• Role & menu dinamis</li>
              <li>• Absensi masuk/keluar</li>
              <li>• Aktivitas prospectus terpantau</li>
            </ul>
          </div>

          <LoginForm action={handleLogin} />
        </div>
      </div>
    </div>
  )
}

